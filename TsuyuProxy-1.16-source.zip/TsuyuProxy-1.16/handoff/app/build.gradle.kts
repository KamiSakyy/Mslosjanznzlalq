import java.security.KeyStore
import java.security.MessageDigest
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.tsuyu.stringfog")
}

// Один случайный ключ на конфигурацию сборки связывает шифрование литералов
// DEX с нативным декодером; в исходники и APK он не попадает открытым текстом.
val stringProtectionKey = extensions.extraProperties.get("tsuyuStringKey") as String

// Постоянная подпись: ключ живёт в handoff/signing вместе с исходником, поэтому
// сборка подписывается одним и тем же сертификатом и в CI, и локально.
val signingProps = Properties()
val signingPropsFile = file("${rootProject.projectDir}/signing/keystore.properties")
if (signingPropsFile.exists()) {
    signingPropsFile.inputStream().use { signingProps.load(it) }
}
val keystorePath = System.getenv("KEYSTORE_FILE")
    ?: file("${rootProject.projectDir}/signing/tsuyu-release.jks").takeIf { it.exists() }?.absolutePath
val keystorePass = System.getenv("KEYSTORE_PASSWORD") ?: signingProps.getProperty("storePassword")
val keystoreAlias = System.getenv("KEY_ALIAS") ?: signingProps.getProperty("keyAlias")
val keystoreKeyPass = System.getenv("KEY_PASSWORD") ?: signingProps.getProperty("keyPassword")
val signingReady = !keystorePath.isNullOrBlank() && !keystorePass.isNullOrBlank()
// Отпечаток сертификата нужен только build-time сборщику для отметки артефакта;
// в запущенном приложении проверки целостности/окружения не выполняются.
val releaseCert = releaseCertSha256(keystorePath, keystorePass)

fun releaseCertSha256(path: String?, password: String?): String {
    val fallback = "62cf573a0bd0f4ef2cf6e6868cc0c8559e1ff0d5e7583c1d50e1ac6c89c9d1a9"
    if (path.isNullOrBlank() || password.isNullOrBlank()) {
        return fallback
    }
    return try {
        val store = KeyStore.getInstance("PKCS12")
        file(path).inputStream().use { store.load(it, password.toCharArray()) }
        val alias = store.aliases().asSequence().first()
        val encoded = store.getCertificate(alias).encoded
        MessageDigest.getInstance("SHA-256").digest(encoded).joinToString("") { "%02x".format(it) }
    } catch (ignored: Exception) {
        fallback
    }
}

android {
    namespace = "com.tsuyu.proxy"
    compileSdk = 35
    ndkVersion = "27.2.12479018"

    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        applicationId = "com.tsuyu.proxy"
        minSdk = 23
        targetSdk = 35
        versionCode = 17
        versionName = "1.16"
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
        externalNativeBuild {
            cmake {
                arguments += listOf(
                    "-DANDROID_STL=c++_static",
                    "-DTSO_CERT=$releaseCert",
                    "-DTSO_STRING_KEY=$stringProtectionKey"
                )
                cppFlags += "-std=c++17 -Oz -ffunction-sections -fdata-sections"
                cFlags += "-Oz -ffunction-sections -fdata-sections"
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
        jniLibs {
            // Библиотеки сжимаются в APK: без этого файл весит почти вдвое больше
            // (несжатые .so под две архитектуры). Целостность от этого не страдает:
            // ядро проверяет свою пломбу по тому файлу, который реально загружен,
            // поэтому подменённый .so на диске не пройдёт проверку.
            useLegacyPackaging = true
            excludes += setOf(
                "**/x86/**",
                "**/x86_64/**",
                "**/mips/**",
                "**/mips64/**"
            )
        }
    }

    if (signingReady) {
        signingConfigs {
            create("release") {
                storeFile = file(keystorePath!!)
                storePassword = keystorePass
                keyAlias = keystoreAlias
                keyPassword = keystoreKeyPass
                storeType = "PKCS12"
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            ndk {
                debugSymbolLevel = "NONE"
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (signingReady) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }
}

afterEvaluate {
    tasks.matching { it.name == "packageRelease" }.configureEach {
        doFirst {
            val script = file("src/main/cpp/seal_so.py")
            val libs = fileTree(layout.buildDirectory) {
                include("**/libc++_shared.so")
            }
            if (libs.files.isEmpty()) {
                throw GradleException("native library missing before seal")
            }
            libs.files.forEach { so ->
                exec {
                    // Build-time отметка формируется с отпечатком release-сертификата;
                    // runtime-проверок пломбы или окружения в приложении нет.
                    commandLine("python3", script.absolutePath, so.absolutePath, releaseCert)
                }
            }
        }
    }
}


