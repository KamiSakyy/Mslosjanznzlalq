package com.tsuyu.proxy;

import android.content.Context;

import java.io.File;

public final class Mk {
    static {
        System.loadLibrary("c++_shared");
    }

    private Mk() {
    }

    private static native int nativeStart(String host, int port, String secret);

    private static native void nativeStop();

    private static native void nativeConfigure(int pool, String cacheDir, int cfEnabled, String domain);

    private static native boolean nativeAlive();

    private static native long nativeBytesUp();

    private static native long nativeBytesDown();

    private static native int nativePing();

    private static native int nativeSearch();

    private static native int nativeRefresh();

    private static native boolean nativeSearchRunning();

    private static native int nativeSearchChecked();

    private static native String nativeFronts();

    private static native void nativeSelect(String domain);

    private static native String nativeSelected();

    private static native String nativeFastest();

    private static native boolean nativeNeedsRestart();

    private static native void nativeClearRestart();

    private static native int nativeHeal();

    private static native int nativeLive();

    private static native void nativeNetwork();

    private static native boolean nHostile();

    private static native void nNote(Context context);

    private static native int n0(int a);

    private static native int n1(int a, int b);

    private static native void n2(String s);

    public static synchronized void prepare(Context context) {
        TsuyuGuard.arm(context);
        context.getApplicationContext();
    }

    public static int start(String host, int port, String secret) {
        return nativeStart(host, port, secret);
    }

    public static void stop() {
        nativeStop();
    }

    public static boolean alive() {
        return nativeAlive();
    }

    public static long bytesUp() {
        return nativeBytesUp();
    }

    public static long bytesDown() {
        return nativeBytesDown();
    }

    public static int pingMs() {
        return nativePing();
    }

    public static void note(Context context) {
        if (context != null) {
            nNote(context.getApplicationContext());
        }
    }

    public static void configure(Context context) {
        TsuyuGuard.arm(context);
        File cache = new File(context.getCacheDir(), "tsuyu");
        if (!cache.exists()) {
            cache.mkdirs();
        }
        nativeConfigure(8, cache.getAbsolutePath(), 1, "");
    }

    public static int search() {
        return nativeSearch();
    }

    public static int refresh() {
        return nativeRefresh();
    }

    public static boolean searchRunning() {
        return nativeSearchRunning();
    }

    public static int searchChecked() {
        return nativeSearchChecked();
    }

    public static String fronts() {
        String value = nativeFronts();
        return value == null ? "" : value;
    }

    public static void select(String domain) {
        nativeSelect(domain == null ? "" : domain);
    }

    public static String selected() {
        String value = nativeSelected();
        return value == null ? "" : value;
    }

    public static String fastest() {
        String value = nativeFastest();
        return value == null ? "" : value;
    }

    public static boolean needsRestart() {
        return nativeNeedsRestart();
    }

    public static void clearRestart() {
        nativeClearRestart();
    }

    /**
     * Wakes the native health thread and returns what it knows about the pool:
     * 0 = not measured yet, 1 = at least one front is alive, 2 = every front is dead,
     * 3 = the phone has no network at all.
     */
    public static int heal() {
        return nativeHeal();
    }

    /** Number of fronts verified alive within the last three minutes. */
    public static int liveFronts() {
        return nativeLive();
    }

    /** Drops stale probes and client sockets after the phone changed network. */
    public static void networkChanged() {
        nativeNetwork();
    }
}
