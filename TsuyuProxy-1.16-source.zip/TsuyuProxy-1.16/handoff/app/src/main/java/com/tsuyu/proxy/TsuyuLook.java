package com.tsuyu.proxy;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public final class TsuyuLook {
    private static final String PREFS = "tsuyu_look";
    private static Bitmap wallCache;
    private static long wallStamp = -1L;
    private static Typeface fontCache;
    private static long fontStamp = -1L;

    private TsuyuLook() {
    }

    public static File dir(Context context) {
        File folder = new File(context.getFilesDir(), "look");
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return folder;
    }

    public static File wallFile(Context context) {
        return new File(dir(context), "wall.jpg");
    }

    public static File pendingWall(Context context) {
        return new File(dir(context), "pending.jpg");
    }

    public static File fontFile(Context context) {
        return new File(dir(context), "font.file");
    }

    public static boolean hasWall(Context context) {
        return wallFile(context).exists() && prefs(context).getBoolean("wall", false);
    }

    public static boolean stageCurrent(Context context) {
        File source = wallFile(context);
        if (!source.exists()) {
            return false;
        }
        return copy(context, Uri.fromFile(source), pendingWall(context));
    }

    public static boolean stageWall(Context context, Uri uri) {
        File raw = new File(dir(context), "incoming");
        if (!copy(context, uri, raw)) {
            return false;
        }
        Bitmap bitmap = decode(raw, 1800);
        raw.delete();
        if (bitmap == null) {
            return false;
        }
        boolean ok = writeJpeg(bitmap, pendingWall(context));
        bitmap.recycle();
        return ok;
    }

    public static boolean installFont(Context context, Uri uri) {
        File pending = new File(dir(context), "font.pending");
        if (!copy(context, uri, pending) || pending.length() < 32L) {
            pending.delete();
            return false;
        }
        try {
            Typeface probe = Typeface.createFromFile(pending);
            if (probe == null) {
                pending.delete();
                return false;
            }
            File dest = fontFile(context);
            if (!copy(context, Uri.fromFile(pending), dest)) {
                pending.delete();
                return false;
            }
            pending.delete();
            fontCache = Typeface.createFromFile(dest);
            fontStamp = dest.lastModified();
            return fontCache != null;
        } catch (Throwable ignored) {
            pending.delete();
            return false;
        }
    }

    public static void commitWall(Context context, float zoom, float panX, float panY, int alpha) {
        File pending = pendingWall(context);
        File dest = wallFile(context);
        if (dest.exists()) {
            dest.delete();
        }
        if (!pending.renameTo(dest)) {
            copy(context, Uri.fromFile(pending), dest);
            pending.delete();
        }
        if (!dest.exists() || dest.length() == 0L) {
            return;
        }
        wallCache = null;
        wallStamp = -1L;
        prefs(context).edit()
                .putFloat("zoom", zoom)
                .putFloat("pan_x", panX)
                .putFloat("pan_y", panY)
                .putInt("alpha", alpha)
                .putInt("button_alpha", alpha)
                .putInt("icon_alpha", alpha)
                .putBoolean("wall", true)
                .commit();
    }

    public static void resetTheme(Context context) {
        wallFile(context).delete();
        pendingWall(context).delete();
        new File(dir(context), "incoming").delete();
        wallCache = null;
        wallStamp = -1L;
        prefs(context).edit()
                .remove("zoom")
                .remove("pan_x")
                .remove("pan_y")
                .remove("alpha")
                .remove("button_alpha")
                .remove("icon_alpha")
                .remove("wall")
                .commit();
    }

    public static void resetFont(Context context) {
        fontFile(context).delete();
        new File(dir(context), "font.pending").delete();
        fontCache = null;
        fontStamp = -1L;
    }

    public static float zoom(Context context) {
        return prefs(context).getFloat("zoom", 1f);
    }

    public static float panX(Context context) {
        return prefs(context).getFloat("pan_x", 0f);
    }

    public static float panY(Context context) {
        return prefs(context).getFloat("pan_y", 0f);
    }

    public static int alpha(Context context) {
        SharedPreferences store = prefs(context);
        if (store.contains("alpha")) {
            return store.getInt("alpha", 255);
        }
        return store.getInt("button_alpha", 255);
    }

    public static boolean hidePortrait(Context context) {
        return prefs(context).getBoolean("hide_portrait", false);
    }

    public static void setHidePortrait(Context context, boolean hide) {
        prefs(context).edit().putBoolean("hide_portrait", hide).commit();
    }

    public static Bitmap wall(Context context) {
        File file = wallFile(context);
        if (!file.exists() || !prefs(context).getBoolean("wall", false)) {
            wallCache = null;
            return null;
        }
        if (wallCache != null && wallStamp == file.lastModified()) {
            return wallCache;
        }
        wallCache = decode(file, 1800);
        wallStamp = file.lastModified();
        return wallCache;
    }

    public static Typeface font(Context context) {
        File file = fontFile(context);
        if (!file.exists()) {
            fontCache = null;
            return null;
        }
        if (fontCache != null && fontStamp == file.lastModified()) {
            return fontCache;
        }
        try {
            fontCache = Typeface.createFromFile(file);
            fontStamp = file.lastModified();
        } catch (Throwable ignored) {
            fontCache = null;
        }
        return fontCache;
    }

    public static void apply(Activity activity) {
        View root = activity.findViewById(R.id.root);
        if (root == null) {
            root = activity.findViewById(R.id.fronts_root);
        }
        if (root == null) {
            return;
        }
        Bitmap paper = wall(activity);
        if (paper != null) {
            root.setBackground(new TsuyuWallDrawable(paper, zoom(activity), panX(activity), panY(activity)));
        } else {
            root.setBackgroundColor(0xFF0D0B12);
        }
        View portrait = activity.findViewById(R.id.portrait);
        if (portrait != null) {
            portrait.setVisibility(hidePortrait(activity) ? View.GONE : View.VISIBLE);
        }
        int fade = alpha(activity);
        paint(root, font(activity), fade, fade);
    }

    public static Bitmap glyph(Context context, String text, float sp) {
        return glyph(context, text, sp, Color.WHITE);
    }

    public static Bitmap glyph(Context context, String text, float sp, int color) {
        Typeface face = font(context);
        if (face == null || text == null || text.isEmpty()) {
            return null;
        }
        float px = sp * context.getResources().getDisplayMetrics().scaledDensity;
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        paint.setTextSize(px);
        paint.setTypeface(Typeface.create(face, Typeface.BOLD));
        float width = paint.measureText(text);
        Paint.FontMetrics metrics = paint.getFontMetrics();
        int bitmapWidth = Math.max(1, (int) Math.ceil(width));
        int bitmapHeight = Math.max(1, (int) Math.ceil(metrics.descent - metrics.ascent));
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
        new Canvas(bitmap).drawText(text, 0f, -metrics.ascent, paint);
        return bitmap;
    }

    public static void paint(View view, Typeface face, int buttonAlpha, int iconAlpha) {
        float fade = buttonAlpha / 255f;
        if (view instanceof Button || view.getId() == R.id.front_card) {
            view.setAlpha(fade);
        }
        if (view instanceof Button) {
            style((Button) view, face);
        } else if (view instanceof TextView) {
            style((TextView) view, face);
        } else if (view instanceof ImageView && view.getId() != R.id.front_fav) {
            view.setAlpha(iconAlpha / 255f);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                paint(group.getChildAt(i), face, buttonAlpha, iconAlpha);
            }
        }
    }

    private static void style(TextView view, Typeface face) {
        Typeface current = view.getTypeface();
        int flags = current == null ? Typeface.NORMAL : current.getStyle();
        if (face == null) {
            boolean bold = (flags & Typeface.BOLD) != 0;
            boolean italic = (flags & Typeface.ITALIC) != 0;
            String family = bold ? "sans-serif-medium" : "sans-serif";
            view.setTypeface(Typeface.create(family, italic ? Typeface.ITALIC : Typeface.NORMAL));
        } else {
            view.setTypeface(face, flags);
        }
        view.setFontFeatureSettings("kern");
        view.setIncludeFontPadding(false);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static boolean copy(Context context, Uri uri, File dest) {
        InputStream in = null;
        OutputStream out = null;
        try {
            if (dest.getParentFile() != null) {
                dest.getParentFile().mkdirs();
            }
            in = "file".equals(uri.getScheme())
                    ? new FileInputStream(uri.getPath())
                    : context.getContentResolver().openInputStream(uri);
            if (in == null) {
                return false;
            }
            out = new FileOutputStream(dest);
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) > 0) {
                out.write(buffer, 0, read);
            }
            return dest.length() > 0L;
        } catch (Exception ignored) {
            return false;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception ignored) {
            }
            try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private static boolean writeJpeg(Bitmap bitmap, File dest) {
        FileOutputStream out = null;
        try {
            if (dest.getParentFile() != null) {
                dest.getParentFile().mkdirs();
            }
            out = new FileOutputStream(dest);
            return bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
        } catch (Exception ignored) {
            return false;
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    public static Bitmap decode(File file, int maxSide) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            int sample = 1;
            while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        } catch (Throwable ignored) {
            return null;
        }
    }
}
