package com.tsuyu.proxy;

import android.content.Context;
import android.content.SharedPreferences;

import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.security.SecureRandom;

public final class TsuyuStore {
    private static final String PREFS = "tsuyu";
    private static final int[] PORTS = {2096, 8443, 2083, 2053, 38443};

    private final SharedPreferences prefs;

    public TsuyuStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static final String SECRET_KEY = "secret";
    private static final String SECRET_BOX = "secret_box";

    /**
     * Секрет подключения лежит в тайнике под ключом системы: в настройках
     * остаётся только шифротекст. Старую открытую запись переносим в тайник при
     * первом же чтении и стираем.
     */
    public String secret() {
        String current = KeyBox.open(prefs.getString(SECRET_BOX, ""));
        if (validSecret(current)) {
            return current.toLowerCase();
        }
        String legacy = prefs.getString(SECRET_KEY, "");
        if (validSecret(legacy)) {
            String plain = legacy.toLowerCase();
            String sealed = KeyBox.seal(plain);
            android.content.SharedPreferences.Editor edit = prefs.edit();
            if (sealed != null) {
                edit.putString(SECRET_BOX, sealed).remove(SECRET_KEY);
            }
            edit.apply();
            return plain;
        }
        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        StringBuilder out = new StringBuilder(32);
        for (byte value : bytes) {
            out.append(String.format("%02x", value));
        }
        String plain = out.toString();
        String sealed = KeyBox.seal(plain);
        if (sealed != null) {
            prefs.edit().putString(SECRET_BOX, sealed).remove(SECRET_KEY).apply();
        } else {
            prefs.edit().putString(SECRET_KEY, plain).apply();
        }
        return plain;
    }

    private static boolean validSecret(String value) {
        return value != null && value.length() == 32 && value.matches("[0-9a-fA-F]{32}");
    }

    public int port() {
        int saved = prefs.getInt("port", 0);
        if (saved > 0 && saved <= 65535 && (saved == boundNow() || free(saved))) {
            return saved;
        }
        for (int candidate : PORTS) {
            if (free(candidate)) {
                prefs.edit().putInt("port", candidate).apply();
                return candidate;
            }
        }
        prefs.edit().putInt("port", PORTS[0]).apply();
        return PORTS[0];
    }

    public void rememberPort(int port) {
        prefs.edit().putInt("port", port).apply();
    }

    public void markUsed() {
        prefs.edit().putBoolean("used", true).apply();
    }

    public boolean used() {
        return prefs.getBoolean("used", false);
    }

    public void setWanted(boolean value) {
        prefs.edit().putBoolean("wanted", value).apply();
    }

    public boolean wanted() {
        if (!prefs.contains("wanted")) {
            return used();
        }
        return prefs.getBoolean("wanted", false);
    }

    public String link() {
        return "https://t.me/proxy?server=127.0.0.1&port=" + port() + "&secret=dd" + secret();
    }

    public long favoriteAt(String domain) {
        if (domain == null || domain.isEmpty()) {
            return 0L;
        }
        return prefs.getLong("fav." + domain, 0L);
    }

    public void setFavorite(String domain, boolean on) {
        if (domain == null || domain.isEmpty()) {
            return;
        }
        if (on) {
            prefs.edit().putLong("fav." + domain, System.currentTimeMillis()).commit();
        } else {
            prefs.edit().remove("fav." + domain).commit();
        }
    }

    public String alias(String domain) {
        if (domain == null || domain.isEmpty()) {
            return "";
        }
        String key = "e." + domain;
        synchronized (prefs) {
            int number = prefs.getInt(key, 0);
            if (number <= 0) {
                number = prefs.getInt("e_next", 1);
                prefs.edit().putInt(key, number).putInt("e_next", number + 1).commit();
            }
            return "Эмилия " + number;
        }
    }

    public static String amount(long bytes) {
        if (bytes < 1024L) {
            return bytes + " Б";
        }
        if (bytes < 1024L * 1024L) {
            return String.format(java.util.Locale.US, "%.1f КБ", bytes / 1024.0);
        }
        if (bytes < 1024L * 1024L * 1024L) {
            return String.format(java.util.Locale.US, "%.1f МБ", bytes / 1048576.0);
        }
        return String.format(java.util.Locale.US, "%.2f ГБ", bytes / 1073741824.0);
    }

    private int boundNow() {
        return a.a.e.running ? prefs.getInt("port", 0) : 0;
    }

    private static boolean free(int port) {
        ServerSocket socket = null;
        try {
            socket = new ServerSocket();
            socket.setReuseAddress(true);
            socket.bind(new InetSocketAddress("127.0.0.1", port));
            return true;
        } catch (Exception ignored) {
            return false;
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (Exception ignored) {
                }
            }
        }
    }
}
