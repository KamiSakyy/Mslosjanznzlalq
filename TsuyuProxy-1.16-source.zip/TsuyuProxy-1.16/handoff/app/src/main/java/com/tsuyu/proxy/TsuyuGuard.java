package com.tsuyu.proxy;

import android.content.Context;

public final class TsuyuGuard {
    private TsuyuGuard() {
    }

    public static void arm(Context context) {
        if (context == null) {
            return;
        }
        Mk.note(context.getApplicationContext());
    }
}
