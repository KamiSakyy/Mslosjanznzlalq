package com.tsuyu.proxy;

import java.nio.charset.StandardCharsets;

public final class N {
    static {
        System.loadLibrary("c++_shared");
    }

    private N() {
    }

    private static native byte[] d(byte[] payload);

    public static String n(byte[] payload) {
        byte[] clear = d(payload);
        return clear == null ? "" : new String(clear, StandardCharsets.UTF_8);
    }
}
