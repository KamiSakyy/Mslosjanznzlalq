package com.tsuyu.proxy;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

public final class TsuyuWallDrawable extends Drawable {
    private final Bitmap bitmap;
    private final float zoom;
    private final float panX;
    private final float panY;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Matrix matrix = new Matrix();

    public TsuyuWallDrawable(Bitmap bitmap, float zoom, float panX, float panY) {
        this.bitmap = bitmap;
        this.zoom = zoom < 0.4f ? 0.4f : zoom;
        this.panX = panX;
        this.panY = panY;
    }

    @Override
    public void draw(Canvas canvas) {
        Rect bounds = getBounds();
        if (bitmap == null || bounds.width() <= 0 || bounds.height() <= 0) {
            return;
        }
        float cover = Math.max(bounds.width() / (float) bitmap.getWidth(), bounds.height() / (float) bitmap.getHeight());
        float scale = cover * zoom;
        float dx = (bounds.width() - bitmap.getWidth() * scale) / 2f + panX * bounds.width();
        float dy = (bounds.height() - bitmap.getHeight() * scale) / 2f + panY * bounds.height();
        matrix.setScale(scale, scale);
        matrix.postTranslate(bounds.left + dx, bounds.top + dy);
        canvas.drawBitmap(bitmap, matrix, paint);
    }

    @Override
    public void setAlpha(int alpha) {
        paint.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        paint.setColorFilter(colorFilter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
