package com.tsuyu.proxy;

import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Тайник для секрета подключения.
 *
 * Ключ шифрования живёт в системном хранилище ключей (AndroidKeyStore) и оттуда
 * его нельзя вынести ни файлом, ни бэкапом: в настройках приложения лежит только
 * шифротекст. Раньше секрет хранился открытым текстом, и на рутованном телефоне
 * (или из чужого бэкапа) его можно было просто прочитать.
 *
 * Если системный тайник недоступен (старые прошивки, сбой OEM), работаем как
 * раньше — открытым текстом: связь важнее, чем хранение без шифрования.
 */
final class KeyBox {
    private static final String ALIAS = "tsuyu-box-v1";
    private static final String TRANSFORM = "AES/GCM/NoPadding";
    private static final int TAG_BITS = 128;

    private KeyBox() {
    }

    static boolean available() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }

    /** Шифрует строку; при любой ошибке возвращает null. */
    static String seal(String plain) {
        if (plain == null || plain.isEmpty() || !available()) {
            return null;
        }
        try {
            Cipher cipher = Cipher.getInstance(TRANSFORM);
            cipher.init(Cipher.ENCRYPT_MODE, key());
            byte[] body = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
            byte[] iv = cipher.getIV();
            byte[] out = new byte[1 + iv.length + body.length];
            out[0] = (byte) iv.length;
            System.arraycopy(iv, 0, out, 1, iv.length);
            System.arraycopy(body, 0, out, 1 + iv.length, body.length);
            return Base64.encodeToString(out, Base64.NO_WRAP);
        } catch (Throwable error) {
            return null;
        }
    }

    /** Расшифровывает строку; при любой ошибке возвращает null. */
    static String open(String stored) {
        if (stored == null || stored.isEmpty() || !available()) {
            return null;
        }
        try {
            byte[] raw = Base64.decode(stored, Base64.NO_WRAP);
            int ivLen = raw[0] & 0xFF;
            if (ivLen <= 0 || 1 + ivLen >= raw.length) {
                return null;
            }
            byte[] iv = new byte[ivLen];
            System.arraycopy(raw, 1, iv, 0, ivLen);
            byte[] body = new byte[raw.length - 1 - ivLen];
            System.arraycopy(raw, 1 + ivLen, body, 0, body.length);
            Cipher cipher = Cipher.getInstance(TRANSFORM);
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(TAG_BITS, iv));
            return new String(cipher.doFinal(body), StandardCharsets.UTF_8);
        } catch (Throwable error) {
            return null;
        }
    }

    private static SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        java.security.Key existing = store.getKey(ALIAS, null);
        if (existing instanceof SecretKey) {
            return (SecretKey) existing;
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }
}
