package com.tsuyu.proxy;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

public class TsuyuPaper extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Matrix matrix = new Matrix();
    private final ScaleGestureDetector scaler;
    private Bitmap bitmap;
    private float zoom = 1f;
    private float panX;
    private float panY;
    private float lastX;
    private float lastY;
    private float focusX;
    private float focusY;
    private boolean restore;
    private float restoreX;
    private float restoreY;

    public TsuyuPaper(Context context, AttributeSet attrs) {
        super(context, attrs);
        scaler = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                focusX = detector.getFocusX();
                focusY = detector.getFocusY();
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                zoom *= detector.getScaleFactor();
                if (zoom < 0.45f) {
                    zoom = 0.45f;
                } else if (zoom > 6f) {
                    zoom = 6f;
                }
                panX += detector.getFocusX() - focusX;
                panY += detector.getFocusY() - focusY;
                focusX = detector.getFocusX();
                focusY = detector.getFocusY();
                invalidate();
                return true;
            }
        });
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
        zoom = 1f;
        panX = 0f;
        panY = 0f;
        restore = false;
        invalidate();
    }

    public void restore(Bitmap bitmap, float zoom, float panFractionX, float panFractionY) {
        this.bitmap = bitmap;
        this.zoom = zoom < 0.45f ? 1f : zoom;
        restoreX = panFractionX;
        restoreY = panFractionY;
        restore = true;
        if (getWidth() > 0 && getHeight() > 0) {
            panX = restoreX * getWidth();
            panY = restoreY * getHeight();
            restore = false;
        }
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (restore && w > 0 && h > 0) {
            panX = restoreX * w;
            panY = restoreY * h;
            restore = false;
            invalidate();
        }
    }

    public float zoom() {
        return zoom;
    }

    public float panFractionX() {
        return getWidth() <= 0 ? 0f : panX / getWidth();
    }

    public float panFractionY() {
        return getHeight() <= 0 ? 0f : panY / getHeight();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (bitmap == null || getWidth() <= 0 || getHeight() <= 0) {
            return;
        }
        float cover = Math.max(getWidth() / (float) bitmap.getWidth(), getHeight() / (float) bitmap.getHeight());
        float scale = cover * zoom;
        float dx = (getWidth() - bitmap.getWidth() * scale) / 2f + panX;
        float dy = (getHeight() - bitmap.getHeight() * scale) / 2f + panY;
        matrix.setScale(scale, scale);
        matrix.postTranslate(dx, dy);
        canvas.drawBitmap(bitmap, matrix, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaler.onTouchEvent(event);
        if (event.getPointerCount() == 1 && !scaler.isInProgress()) {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                lastX = event.getX();
                lastY = event.getY();
            } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                panX += event.getX() - lastX;
                panY += event.getY() - lastY;
                lastX = event.getX();
                lastY = event.getY();
                invalidate();
            }
        }
        return true;
    }
}
