package a.a;

import com.tsuyu.proxy.*;

import android.content.ComponentName;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class f extends TileService {
    @Override
    public void onStartListening() {
        super.onStartListening();
        render();
    }

    @Override
    public void onClick() {
        super.onClick();
        TsuyuGuard.arm(this);
        Runnable action = () -> {
            if (e.running) {
                startService(new android.content.Intent(this, e.class)
                        .setAction(e.ACTION_STOP));
            } else {
                TsuyuStore store = new TsuyuStore(this);
                store.secret();
                store.port();
                store.markUsed();
                android.content.Intent intent = new android.content.Intent(this, e.class)
                        .setAction(e.ACTION_START);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(intent);
                } else {
                    startService(intent);
                }
            }
            render();
        };
        if (isLocked()) {
            unlockAndRun(action);
        } else {
            action.run();
        }
    }

    private void render() {
        Tile tile = getQsTile();
        if (tile == null) {
            return;
        }
        tile.setLabel(getString(R.string.app_name));
        tile.setIcon(emilia());
        tile.setState(e.running ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.setSubtitle(e.running ? getString(R.string.notification_running) : "");
        }
        tile.updateTile();
    }

    private Icon emilia() {
        Bitmap src = BitmapFactory.decodeResource(getResources(), R.drawable.emilia_avatar);
        Bitmap scaled = src.getWidth() <= 128 ? src : Bitmap.createScaledBitmap(src, 128, 128, true);
        return Icon.createWithBitmap(scaled);
    }

    public static void requestSync(Context context) {
        try {
            requestListeningState(context, new ComponentName(context, f.class));
        } catch (Throwable ignored) {
        }
    }
}
