package a.a;

import com.tsuyu.proxy.*;

import android.app.Activity;
import android.os.Bundle;

public class d extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TsuyuGuard.arm(this);
        finish();
    }
}
