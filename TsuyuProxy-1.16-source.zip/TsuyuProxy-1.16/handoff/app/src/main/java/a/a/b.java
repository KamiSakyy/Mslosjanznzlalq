package a.a;

import com.tsuyu.proxy.*;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class b extends android.app.Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Button refresh;
    private boolean refreshing;
    private ProgressBar progress;
    private TextView status;
    private LinearLayout list;
    private boolean polling;

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            paint();
            if (Mk.searchRunning()) {
                handler.postDelayed(this, 700L);
            } else {
                polling = false;
            }
        }
    };

    // While the list is on screen the rows are re-read so the shown state really is the
    // last one the native health thread measured.
    private final Runnable watch = new Runnable() {
        @Override
        public void run() {
            paint();
            handler.postDelayed(this, 5000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TsuyuGuard.arm(this);
        setContentView(R.layout.activity_fronts);
        edge();
        Mk.configure(this);
        refresh = findViewById(R.id.fronts_refresh);
        progress = findViewById(R.id.fronts_progress);
        status = findViewById(R.id.fronts_status);
        list = findViewById(R.id.fronts_list);
        findViewById(R.id.fronts_back).setOnClickListener(v -> finish());
        refresh.setOnClickListener(v -> beginRefresh());
        paint();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(poll);
        handler.removeCallbacks(watch);
        super.onDestroy();
    }

    private void edge() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().setNavigationBarContrastEnforced(false);
            getWindow().setStatusBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().setNavigationBarDividerColor(Color.TRANSPARENT);
        }
        View root = findViewById(R.id.fronts_root);
        View header = findViewById(R.id.fronts_header);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            header.setPadding(header.getPaddingLeft(), top + 6, header.getPaddingRight(), header.getPaddingBottom());
            view.setPadding(view.getPaddingLeft(), 0, view.getPaddingRight(), Math.max(bottom, 12));
            return insets;
        });
        root.requestApplyInsets();
    }

    private void beginRefresh() {
        if (Mk.searchRunning()) {
            return;
        }
        Mk.configure(this);
        refreshing = true;
        Mk.refresh();
        if (!polling) {
            polling = true;
            handler.post(poll);
        }
        paint();
    }

    private void paint() {
        boolean busy = Mk.searchRunning();
        refresh.setEnabled(!busy);
        refresh.setText(busy && refreshing ? R.string.fronts_refreshing : R.string.fronts_refresh);
        if (!busy) {
            refreshing = false;
        }
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        status.setText("");
        status.setVisibility(View.GONE);
        List<Front> fronts = parse(Mk.fronts());
        Collections.sort(fronts, (left, right) -> Integer.compare(score(left), score(right)));
        String fastest = fastestOf(fronts);
        String chosen = Mk.selected();
        TsuyuStore store = new TsuyuStore(this);
        Collections.sort(fronts, (left, right) -> {
            long leftAt = store.favoriteAt(left.domain);
            long rightAt = store.favoriteAt(right.domain);
            boolean leftFav = leftAt > 0L;
            boolean rightFav = rightAt > 0L;
            if (leftFav != rightFav) {
                return leftFav ? -1 : 1;
            }
            if (leftFav && leftAt != rightAt) {
                return Long.compare(rightAt, leftAt);
            }
            return Integer.compare(score(left), score(right));
        });
        list.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);
        for (Front front : fronts) {
            View card = inflater.inflate(R.layout.item_front, list, false);
            boolean selected = front.domain.equals(chosen);
            card.setBackgroundResource(selected ? R.drawable.tsuyu_front_card_on : R.drawable.tsuyu_front_card);
            TextView domain = card.findViewById(R.id.front_domain);
            TextView ping = card.findViewById(R.id.front_ping);
            TextView badge = card.findViewById(R.id.front_badge);
            TextView meta = card.findViewById(R.id.front_meta);
            TextView state = card.findViewById(R.id.front_state);
            ImageView fav = card.findViewById(R.id.front_fav);
            String host = front.domain;
            boolean alive = front.state == Front.ALIVE;
            boolean dead = front.state == Front.DEAD;
            domain.setText(store.alias(host));
            // The ping and the speed are only shown when this front answered for real
            // in this session, otherwise the row is honestly labelled.
            ping.setText(alive && front.ping > 0 ? front.ping + " мс" : "—");
            badge.setVisibility(host.equals(fastest) ? View.VISIBLE : View.GONE);
            meta.setText(alive ? speedText(front.kbps) : "");
            if (selected) {
                state.setText(R.string.fronts_selected);
                state.setTextColor(0xFFC9A8FF);
            } else if (alive) {
                state.setText(R.string.fronts_alive);
                state.setTextColor(0xFF8CE99A);
            } else if (dead) {
                state.setText(R.string.fronts_dead);
                state.setTextColor(0xFFFF8A8A);
            } else {
                state.setText(R.string.fronts_checking);
                state.setTextColor(0xFF9A90A8);
            }
            fav.setImageResource(store.favoriteAt(host) > 0L ? R.drawable.tsuyu_star_on : R.drawable.tsuyu_star);
            fav.setOnClickListener(v -> {
                store.setFavorite(host, store.favoriteAt(host) <= 0L);
                paint();
            });
            card.setOnClickListener(v -> choose(host));
            list.addView(card);
        }
        TsuyuLook.apply(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        TsuyuLook.apply(this);
        handler.removeCallbacks(watch);
        handler.postDelayed(watch, 5000L);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(watch);
        super.onPause();
    }

    private void choose(String domain) {
        Mk.select(domain);
        // No full restart: the native layer moves fresh sessions onto the chosen front
        // by itself and the health thread verifies it right away.
        Mk.heal();
        paint();
        Toast.makeText(this, getString(R.string.fronts_home_chosen, new TsuyuStore(this).alias(domain)), Toast.LENGTH_SHORT).show();
    }

    private static int score(Front front) {
        if (front.state != Front.ALIVE || (front.ping <= 0 && front.kbps <= 1)) {
            return Integer.MAX_VALUE;
        }
        int ping = front.ping < 1 ? 2000 : front.ping;
        int kbps = front.kbps < 1 ? 50 : front.kbps;
        if (kbps > 50000) {
            kbps = 50000;
        }
        return ping + (1500000 / kbps);
    }

    private static String fastestOf(List<Front> fronts) {
        if (fronts.isEmpty() || score(fronts.get(0)) == Integer.MAX_VALUE) {
            return "";
        }
        return fronts.get(0).domain;
    }

    private static String speedText(int kbps) {
        if (kbps <= 1) {
            return "";
        }
        if (kbps >= 1000) {
            return String.format(java.util.Locale.US, "%.1f Мбит/с", kbps / 1000.0);
        }
        return kbps + " Кбит/с";
    }

    private static List<Front> parse(String raw) {
        List<Front> out = new ArrayList<>();
        if (raw == null || raw.isEmpty()) {
            return out;
        }
        String[] lines = raw.split("\n");
        for (String line : lines) {
            String[] part = line.split("\\|");
            if (part.length < 3 || part[0].isEmpty()) {
                continue;
            }
            Front front = new Front();
            front.domain = part[0];
            front.ping = number(part[1]);
            front.kbps = number(part[2]);
            front.state = part.length >= 4 ? number(part[3]) : Front.UNKNOWN;
            out.add(front);
        }
        return out;
    }

    private static int number(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static final class Front {
        static final int UNKNOWN = 0;
        static final int ALIVE = 1;
        static final int DEAD = 2;

        String domain = "";
        int ping;
        int kbps;
        int state = UNKNOWN;
    }
}
