package a.a;

import com.tsuyu.proxy.*;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;

public class c extends android.app.Activity {
    private TsuyuPaper paper;
    private Button sample;
    private ImageView iconA;
    private ImageView iconB;
    private SeekBar alpha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TsuyuGuard.arm(this);
        setContentView(R.layout.activity_wall);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().setNavigationBarContrastEnforced(false);
            getWindow().setStatusBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().setNavigationBarDividerColor(Color.TRANSPARENT);
        }
        paper = findViewById(R.id.paper);
        sample = findViewById(R.id.wall_sample);
        iconA = findViewById(R.id.wall_icon_a);
        iconB = findViewById(R.id.wall_icon_b);
        alpha = findViewById(R.id.wall_alpha);
        View back = findViewById(R.id.wall_back);
        View panel = findViewById(R.id.wall_panel);
        View root = findViewById(R.id.wall_root);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            back.setTranslationY(top + 8f);
            panel.setPadding(panel.getPaddingLeft(), panel.getPaddingTop(), panel.getPaddingRight(), bottom + 16);
            return insets;
        });
        root.requestApplyInsets();
        alpha.setProgress(Math.round(TsuyuLook.alpha(this) * 100f / 255f));
        alpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                preview();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        back.setOnClickListener(v -> finish());
        findViewById(R.id.wall_done).setOnClickListener(v -> save());
        Bitmap bitmap = TsuyuLook.decode(TsuyuLook.pendingWall(this), 1800);
        if (getIntent().getBooleanExtra("edit", false)) {
            paper.restore(bitmap, TsuyuLook.zoom(this), TsuyuLook.panX(this), TsuyuLook.panY(this));
        } else {
            paper.setBitmap(bitmap);
        }
        TsuyuLook.paint(panel, TsuyuLook.font(this), 255, 255);
        preview();
    }

    private void preview() {
        float fade = alpha.getProgress() / 100f;
        sample.setAlpha(fade);
        iconA.setAlpha(fade);
        iconB.setAlpha(fade);
    }

    private void save() {
        int fade = Math.round(alpha.getProgress() * 255f / 100f);
        TsuyuLook.commitWall(this, paper.zoom(), paper.panFractionX(), paper.panFractionY(), fade);
        finish();
    }
}
