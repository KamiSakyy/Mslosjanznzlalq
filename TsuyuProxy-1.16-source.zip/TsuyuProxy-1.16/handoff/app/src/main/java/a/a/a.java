package a.a;

import com.tsuyu.proxy.*;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class a extends android.app.Activity {
    private static final int PICK_WALL = 41;
    private static final int PICK_FONT = 42;
    private Button connect;
    private ImageView portrait;
    private TextView proxyLink;
    private TextView traffic;
    private final Handler ticker = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            paintStats();
            ticker.postDelayed(this, 1000L);
        }
    };
    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            render();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TsuyuGuard.arm(this);
        setContentView(R.layout.activity_tsuyu);
        edgeToEdge();
        connect = findViewById(R.id.connect);
        portrait = findViewById(R.id.portrait);
        traffic = findViewById(R.id.stat_traffic);
        proxyLink = findViewById(R.id.proxy_link);
        View open = findViewById(R.id.open_proxy);
        View fronts = findViewById(R.id.open_fronts);
        View telegram = findViewById(R.id.telegram);
        View settings = findViewById(R.id.settings);
        Mk.configure(this);
        portrait.setBackground(null);
        portrait.setClipToOutline(true);
        portrait.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                float radius = 40f * getResources().getDisplayMetrics().density;
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
            }
        });
        connect.setOnClickListener(v -> toggle());
        proxyLink.setOnClickListener(v -> copyLink());
        open.setOnClickListener(v -> openInTelegram());
        fronts.setOnClickListener(v -> startActivity(new Intent(this, b.class)));
        telegram.setBackgroundResource(R.drawable.tsuyu_icon_button);
        telegram.setOnClickListener(v -> openChannel());
        settings.setBackgroundResource(R.drawable.tsuyu_icon_button);
        settings.setOnClickListener(v -> showSettings());
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
        }
        render();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(e.ACTION_STATE);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, filter);
        }
        render();
        ticker.removeCallbacks(tick);
        ticker.post(tick);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null) {
            return;
        }
        Uri uri = data.getData();
        if (uri == null && data.getClipData() != null && data.getClipData().getItemCount() > 0) {
            uri = data.getClipData().getItemAt(0).getUri();
        }
        if (uri == null) {
            return;
        }
        if (request == PICK_WALL) {
            if (TsuyuLook.stageWall(this, uri)) {
                startActivity(new Intent(this, c.class));
            } else {
                Toast.makeText(this, R.string.look_wall_fail, Toast.LENGTH_SHORT).show();
            }
        } else if (request == PICK_FONT) {
            if (TsuyuLook.installFont(this, uri)) {
                TsuyuLook.apply(this);
                e.refreshLook(this);
            } else {
                Toast.makeText(this, R.string.look_font_fail, Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onStop() {
        ticker.removeCallbacks(tick);
        unregisterReceiver(stateReceiver);
        super.onStop();
    }

    private void edgeToEdge() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().setNavigationBarContrastEnforced(false);
            getWindow().setStatusBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().setNavigationBarDividerColor(Color.TRANSPARENT);
        }
        View root = findViewById(R.id.root);
        View header = findViewById(R.id.header);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            header.setPadding(header.getPaddingLeft(), top, header.getPaddingRight(), 0);
            int sideStart = view.getPaddingLeft();
            int sideEnd = view.getPaddingRight();
            view.setPadding(sideStart, 0, sideEnd, Math.max(bottom, 18));
            return insets;
        });
        root.requestApplyInsets();
    }

    private void toggle() {
        if (e.running) {
            startService(new Intent(this, e.class).setAction(e.ACTION_STOP));
        } else {
            TsuyuStore store = new TsuyuStore(this);
            store.secret();
            store.port();
            store.markUsed();
            Intent intent = new Intent(this, e.class).setAction(e.ACTION_START);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        }
        render();
    }

    private void copyLink() {
        TsuyuStore store = new TsuyuStore(this);
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("TsuyuProxy", store.link()));
        Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show();
    }

    private void openInTelegram() {
        boolean already = e.running;
        if (!already) {
            TsuyuStore store = new TsuyuStore(this);
            store.secret();
            store.port();
            store.markUsed();
            Intent intent = new Intent(this, e.class).setAction(e.ACTION_START);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            render();
        }
        ticker.postDelayed(this::launchTelegramProxy, already ? 0L : 700L);
    }

    private void launchTelegramProxy() {
        TsuyuStore store = new TsuyuStore(this);
        String direct = "tg://proxy?server=127.0.0.1&port=" + store.port() + "&secret=dd" + store.secret();
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(direct)));
        } catch (Exception error) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(store.link())));
            } catch (Exception again) {
                Toast.makeText(this, R.string.link_failed, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openChannel() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/AsuMeo")));
        } catch (Exception error) {
            Toast.makeText(this, R.string.link_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void render() {
        boolean on = e.running;
        connect.setText(on ? R.string.disconnect : R.string.connect);
        connect.setBackgroundResource(on ? R.drawable.tsuyu_button_on : R.drawable.tsuyu_button);
        connect.setBackgroundTintList(null);
        connect.setTextColor(on ? 0xFFFFC6D0 : 0xFF211430);
        portrait.setBackground(null);
        proxyLink.setText(new TsuyuStore(this).link());
        TextView pick = findViewById(R.id.front_pick);
        String chosen = Mk.selected();
        if (chosen == null || chosen.isEmpty()) {
            pick.setText(R.string.fronts_home_empty);
        } else {
            pick.setText(getString(R.string.fronts_home_chosen, new TsuyuStore(this).alias(chosen)));
        }
        paintEaten();
        TsuyuLook.apply(this);
    }

    private void paintEaten() {
        String amount = "—";
        if (e.running) {
            amount = TsuyuStore.amount(Mk.bytesUp() + Mk.bytesDown());
        }
        traffic.setText(getString(R.string.stat_traffic, amount));
    }

    private void showSettings() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_settings);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        View root = dialog.findViewById(R.id.look_root);
        TsuyuLook.paint(root, TsuyuLook.font(this), 255, 255);
        CheckBox hide = dialog.findViewById(R.id.look_hide);
        hide.setChecked(TsuyuLook.hidePortrait(this));
        hide.setOnCheckedChangeListener((button, checked) -> {
            TsuyuLook.setHidePortrait(this, checked);
            TsuyuLook.apply(this);
        });
        dialog.findViewById(R.id.look_wall).setOnClickListener(v -> {
            dialog.dismiss();
            pickWall();
        });
        View edit = dialog.findViewById(R.id.look_edit);
        edit.setVisibility(TsuyuLook.hasWall(this) ? View.VISIBLE : View.GONE);
        edit.setOnClickListener(v -> {
            dialog.dismiss();
            if (TsuyuLook.stageCurrent(this)) {
                startActivity(new Intent(this, c.class).putExtra("edit", true));
            } else {
                Toast.makeText(this, R.string.look_wall_fail, Toast.LENGTH_SHORT).show();
            }
        });
        dialog.findViewById(R.id.look_font).setOnClickListener(v -> {
            dialog.dismiss();
            pick("*/*", PICK_FONT);
        });
        dialog.findViewById(R.id.look_reset_theme).setOnClickListener(v -> {
            TsuyuLook.resetTheme(this);
            TsuyuLook.apply(this);
            dialog.dismiss();
            Toast.makeText(this, R.string.look_reset_done, Toast.LENGTH_SHORT).show();
        });
        dialog.findViewById(R.id.look_reset_font).setOnClickListener(v -> {
            TsuyuLook.resetFont(this);
            TsuyuLook.apply(this);
            e.refreshLook(this);
            dialog.dismiss();
            Toast.makeText(this, R.string.look_reset_done, Toast.LENGTH_SHORT).show();
        });
        dialog.findViewById(R.id.look_close).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void pickWall() {
        Intent photos = new Intent(MediaStore.ACTION_PICK_IMAGES);
        photos.setType("image/*");
        if (Build.VERSION.SDK_INT < 33) {
            photos = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            photos.setType("image/*");
        }
        photos.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(photos, PICK_WALL);
        } catch (Exception error) {
            pick("image/*", PICK_WALL);
        }
    }

    private void pick(String type, int request) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(type);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(intent, request);
        } catch (Exception error) {
            Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
            fallback.addCategory(Intent.CATEGORY_OPENABLE);
            fallback.setType(type);
            fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                startActivityForResult(fallback, request);
            } catch (Exception again) {
                Toast.makeText(this, request == PICK_FONT ? R.string.look_font_fail : R.string.look_wall_fail, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void paintStats() {
        paintEaten();
    }
}
