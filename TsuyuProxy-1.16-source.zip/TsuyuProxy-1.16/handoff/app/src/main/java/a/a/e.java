package a.a;

import com.tsuyu.proxy.*;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;

public class e extends Service {
    public static final String ACTION_START = "com.tsuyu.proxy.START";
    public static final String ACTION_STOP = "com.tsuyu.proxy.STOP";
    public static final String ACTION_RESTART = "com.tsuyu.proxy.RESTART";
    public static final String ACTION_WATCH = "com.tsuyu.proxy.WATCH";
    public static final String ACTION_LOOK = "com.tsuyu.proxy.LOOK";
    public static final String ACTION_STATE = "com.tsuyu.proxy.STATE";

    public static volatile boolean running = false;

    private static final int NOTIFICATION_ID = 101;
    private static final String CHANNEL_ID = "TsuyuProxy_Service_v3";
    private static final long WATCH_MS = 30L * 60L * 1000L;
    private static final long PULSE_ALERT_MS = 4_000L;
    private static final long PULSE_OK_MS = 20_000L;
    private static final long PULSE_IDLE_MS = 60_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Object gate = new Object();
    private String lastSecret = "";
    private int lastPort = 2096;
    private volatile boolean stopInProgress;
    private volatile boolean userStop;
    private volatile boolean starting;
    private int deadTicks;
    private int okTicks;
    private long lastNetAt;
    private ConnectivityManager.NetworkCallback networkCallback;

    private final Runnable pulse = new Runnable() {
        @Override
        public void run() {
            if (userStop || stopInProgress) {
                return;
            }
            TsuyuStore store = new TsuyuStore(e.this);
            if (!store.wanted()) {
                return;
            }
            if (lastSecret.isEmpty()) {
                lastSecret = store.secret();
                lastPort = store.port();
            }
            long next;
            if (!running || !Mk.alive()) {
                startProxy(lastPort, lastSecret);
                next = PULSE_ALERT_MS;
            } else {
                next = selfCheck();
            }
            if (!userStop && !stopInProgress) {
                handler.postDelayed(this, next);
            }
        }
    };

    // Asks the native health thread how the pool is doing and only escalates when the
    // phone really has network but every front stayed dead for minutes. The steady state
    // costs a single wake up per minute, that is what keeps the phone cool.
    private long selfCheck() {
        if (Mk.needsRestart()) {
            // The native layer failed over inside the session already, so this is only a hint.
            Mk.clearRestart();
        }
        int pool = Mk.heal();
        int live = Mk.liveFronts();
        if (live > 0) {
            deadTicks = 0;
            okTicks = Math.min(okTicks + 1, 8);
            return okTicks >= 4 ? PULSE_IDLE_MS : PULSE_OK_MS;
        }
        okTicks = 0;
        long now = SystemClock.elapsedRealtime();
        if (pool == 3) {
            // Airplane mode or no signal: there is nothing to repair, just wait. The
            // network callback wakes us on any connectivity change, so a slow beat is
            // enough here and keeps the phone from heating up while offline.
            deadTicks = 0;
            if (now - lastNetAt > 60_000L) {
                lastNetAt = now;
                Mk.networkChanged();
            }
            return 30_000L;
        }
        ++deadTicks;
        if (pool == 2) {
            // Никаких автоматических обновлений списка: пинги и скорости снимаются
            // только по кнопке «Обновить», иначе фоновая слежка рвёт соединение.
            // Если связи нет совсем долго, просто один раз пересобираем туннель.
            if (deadTicks >= 45) {
                // Roughly three minutes with a working network and no live front left:
                // rebuild the native side once, everything else already healed in place.
                deadTicks = 0;
                restartProxy();
            }
        }
        return PULSE_ALERT_MS;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        TsuyuGuard.arm(this);
        createChannel();
        watchNetwork();
    }

    private void watchNetwork() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || networkCallback != null) {
            return;
        }
        try {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (manager == null) {
                return;
            }
            NetworkRequest request = new NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build();
            ConnectivityManager.NetworkCallback callback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    switched();
                }

                @Override
                public void onLost(Network network) {
                    switched();
                }

                private void switched() {
                    handler.post(() -> {
                        if (userStop || stopInProgress || !running) {
                            return;
                        }
                        Mk.networkChanged();
                        Mk.heal();
                    });
                }
            };
            manager.registerNetworkCallback(request, callback);
            networkCallback = callback;
        } catch (Throwable ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopProxy();
            return START_NOT_STICKY;
        }
        TsuyuStore store = new TsuyuStore(this);
        if (ACTION_LOOK.equals(action)) {
            if (running) {
                try {
                    startInForeground();
                } catch (Throwable ignored) {
                }
            }
            return START_STICKY;
        }
        if (ACTION_RESTART.equals(action)) {
            userStop = false;
            store.setWanted(true);
            lastSecret = store.secret();
            lastPort = store.port();
            restartProxy();
            return START_STICKY;
        }
        if (action != null && !ACTION_START.equals(action) && !ACTION_WATCH.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action) && !store.wanted()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        userStop = false;
        lastSecret = store.secret();
        lastPort = store.port();
        if (running && Mk.alive()) {
            try {
                startInForeground();
            } catch (Throwable ignored) {
                scheduleWatch(30_000L);
                return START_STICKY;
            }
            scheduleWatch(WATCH_MS);
            armPulse();
            return START_STICKY;
        }
        startProxy(lastPort, lastSecret);
        return START_STICKY;
    }

    private void armPulse() {
        handler.removeCallbacks(pulse);
        handler.postDelayed(pulse, PULSE_ALERT_MS);
    }

    private void startProxy(int port, String secret) {
        if (stopInProgress || starting) {
            return;
        }
        if (running && Mk.alive()) {
            scheduleWatch(WATCH_MS);
            armPulse();
            return;
        }
        starting = true;
        lastPort = port;
        lastSecret = secret == null ? "" : secret;
        userStop = false;
        new TsuyuStore(this).setWanted(true);
        try {
            startInForeground();
        } catch (Throwable error) {
            starting = false;
            scheduleWatch(30_000L);
            return;
        }
        scheduleWatch(WATCH_MS);
        armPulse();
        final int startPort = lastPort;
        final String startSecret = lastSecret;
        new Thread(() -> {
            try {
                if (Mk.alive()) {
                    Mk.stop();
                }
                Mk.prepare(this);
                Mk.configure(this);
                int code = Mk.start("127.0.0.1", startPort, startSecret);
                synchronized (gate) {
                    if (userStop || code != 0) {
                        if (code == 0) {
                            Mk.stop();
                        }
                        if (!userStop) {
                            handler.post(this::retryLater);
                        }
                        return;
                    }
                    running = true;
                }
                new TsuyuStore(this).rememberPort(startPort);
                announce();
                f.requestSync(this);
            } catch (Throwable error) {
                handler.post(this::retryLater);
            } finally {
                starting = false;
            }
        }, "TsuyuStart").start();
    }

    private void retryLater() {
        starting = false;
        if (userStop || !new TsuyuStore(this).wanted()) {
            return;
        }
        handler.postDelayed(() -> {
            if (!userStop && new TsuyuStore(this).wanted()) {
                startProxy(lastPort, lastSecret);
            }
        }, 30_000L);
    }

    private void restartProxy() {
        if (stopInProgress || starting) {
            return;
        }
        new Thread(() -> {
            stopInProgress = true;
            stopNative();
            synchronized (gate) {
                running = false;
            }
            stopInProgress = false;
            handler.post(() -> startProxy(lastPort, lastSecret));
        }, "TsuyuRestart").start();
    }

    private void stopProxy() {
        if (stopInProgress) {
            return;
        }
        stopInProgress = true;
        synchronized (gate) {
            userStop = true;
            running = false;
        }
        new TsuyuStore(this).setWanted(false);
        cancelWatch();
        handler.removeCallbacks(pulse);
        new Thread(() -> {
            stopNative();
            announce();
            f.requestSync(this);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    stopForeground(STOP_FOREGROUND_REMOVE);
                } else {
                    stopForeground(true);
                }
            } catch (Throwable ignored) {
            }
            stopSelf();
            stopInProgress = false;
        }, "TsuyuStop").start();
    }

    private void stopNative() {
        try {
            Mk.stop();
        } catch (Throwable ignored) {
        }
    }

    private void startInForeground() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription(getString(R.string.notification_channel_description));
        channel.setShowBadge(false);
        channel.setSound(null, null);
        channel.enableVibration(false);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, a.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPending = PendingIntent.getActivity(
                this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        Intent restart = new Intent(this, e.class).setAction(ACTION_RESTART);
        PendingIntent restartPending = PendingIntent.getService(
                this, 2, restart, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        Intent stop = new Intent(this, e.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 3, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        RemoteViews view = notificationView(R.layout.notification_status, restartPending, stopPending);
        RemoteViews expanded = notificationView(R.layout.notification_status_big, restartPending, stopPending);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setContentTitle(getString(R.string.notification_running))
                .setContentText(getString(R.string.notification_running))
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(openPending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setPriority(Notification.PRIORITY_LOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            builder.setCustomContentView(view);
            builder.setCustomBigContentView(expanded);
        } else {
            builder.setContent(view);
            builder.addAction(R.drawable.ic_notification, getString(R.string.notification_restart), restartPending);
            builder.addAction(R.drawable.ic_notification, getString(R.string.notification_disconnect), stopPending);
        }
        return builder.build();
    }

    // «Обновить» сохраняет действие перезапуска подключения, а «Отключить» — остановку.
    // При выбранном шрифте RemoteViews показывает растровые подписи: он не может
    // получить загруженный Typeface приложения напрямую.
    private RemoteViews notificationView(int layout, PendingIntent restartPending, PendingIntent stopPending) {
        String status = getString(R.string.notification_running);
        String restart = getString(R.string.notification_restart);
        String stop = getString(R.string.notification_disconnect);
        RemoteViews view = new RemoteViews(getPackageName(), layout);
        view.setTextViewText(R.id.notification_text, status);
        view.setTextViewText(R.id.notification_restart_text, restart);
        view.setTextViewText(R.id.notification_stop_text, stop);
        view.setTextColor(R.id.notification_text, 0xFFFAFAFA);
        view.setTextColor(R.id.notification_restart_text, 0xFF211430);
        view.setTextColor(R.id.notification_stop_text, 0xFF211430);
        float statusSize = layout == R.layout.notification_status_big ? 17f : 16f;
        setNotificationGlyph(view, R.id.notification_text, R.id.notification_text_glyph,
                status, statusSize, 0xFFFAFAFA);
        setNotificationGlyph(view, R.id.notification_restart_text, R.id.notification_restart_glyph,
                restart, 12f, 0xFF211430);
        setNotificationGlyph(view, R.id.notification_stop_text, R.id.notification_stop_glyph,
                stop, 12f, 0xFF211430);
        view.setImageViewResource(R.id.notification_icon, R.drawable.emilia_avatar);
        view.setOnClickPendingIntent(R.id.notification_restart, restartPending);
        view.setOnClickPendingIntent(R.id.notification_stop, stopPending);
        return view;
    }

    private void setNotificationGlyph(RemoteViews view, int textViewId, int imageViewId,
                                      String text, float sizeSp, int color) {
        Bitmap glyph = TsuyuLook.glyph(this, text, sizeSp, color);
        if (glyph != null) {
            view.setImageViewBitmap(imageViewId, glyph);
            view.setContentDescription(imageViewId, text);
            view.setViewVisibility(textViewId, View.GONE);
            view.setViewVisibility(imageViewId, View.VISIBLE);
        } else {
            view.setViewVisibility(textViewId, View.VISIBLE);
            view.setViewVisibility(imageViewId, View.GONE);
        }
    }

    static void refreshLook(android.content.Context context) {
        if (!running || context == null) {
            return;
        }
        try {
            context.startService(new Intent(context, e.class).setAction(ACTION_LOOK));
        } catch (Throwable ignored) {
        }
    }

    private void scheduleWatch(long delayMs) {
        try {
            AlarmManager alarms = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (alarms == null) {
                return;
            }
            PendingIntent pending = watchIntent();
            long when = SystemClock.elapsedRealtime() + delayMs;
            if (Build.VERSION.SDK_INT >= 23) {
                alarms.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, when, pending);
            } else {
                alarms.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, when, pending);
            }
        } catch (Throwable ignored) {
        }
    }

    private void cancelWatch() {
        try {
            AlarmManager alarms = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (alarms != null) {
                alarms.cancel(watchIntent());
            }
        } catch (Throwable ignored) {
        }
    }

    private PendingIntent watchIntent() {
        Intent intent = new Intent(this, e.class).setAction(ACTION_WATCH);
        return PendingIntent.getService(
                this, 7, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private void announce() {
        Intent intent = new Intent(ACTION_STATE);
        intent.setPackage(getPackageName());
        sendBroadcast(intent);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (!userStop && new TsuyuStore(this).wanted()) {
            Intent restart = new Intent(this, e.class).setAction(ACTION_START);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(restart);
                } else {
                    startService(restart);
                }
            } catch (Throwable ignored) {
                scheduleWatch(5_000L);
            }
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(pulse);
        if (networkCallback != null) {
            try {
                ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
                if (manager != null) {
                    manager.unregisterNetworkCallback(networkCallback);
                }
            } catch (Throwable ignored) {
            }
            networkCallback = null;
        }
        boolean keep = !userStop && new TsuyuStore(this).wanted();
        synchronized (gate) {
            running = false;
        }
        if (keep) {
            scheduleWatch(5_000L);
        }
        super.onDestroy();
    }
}
