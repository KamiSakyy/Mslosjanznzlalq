#!/usr/bin/env python3
"""Emit a split key header for the native string decoder."""

import pathlib
import secrets
import sys


def main() -> int:
    if len(sys.argv) != 3:
        print("usage: gen_string_key.py <64-hex-key> <output-header>", file=sys.stderr)
        return 2
    text = sys.argv[1].strip()
    if len(text) != 64:
        print("string key must be 64 hexadecimal characters", file=sys.stderr)
        return 2
    try:
        key = bytes.fromhex(text)
    except ValueError:
        print("string key must be hexadecimal", file=sys.stderr)
        return 2
    if len(key) != 32:
        print("string key must decode to 32 bytes", file=sys.stderr)
        return 2

    shares = [secrets.token_bytes(32) for _ in range(3)]
    last = bytes(k ^ a ^ b ^ c for k, a, b, c in zip(key, *shares))
    shares.append(last)

    def array(name: str, values: bytes) -> str:
        rows = []
        for offset in range(0, len(values), 8):
            rows.append("        " + ", ".join(f"0x{x:02x}" for x in values[offset:offset + 8]))
        return f"    static const volatile std::uint8_t {name}[32] = {{\n" + ",\n".join(rows) + "\n    };"

    arrays = "\n".join(array(f"s{i}", values) for i, values in enumerate(shares))
    header = (
        "#pragma once\n"
        "#include <cstddef>\n"
        "#include <cstdint>\n\n"
        "inline void tso_get_string_key(std::uint8_t* out) {\n"
        f"{arrays}\n"
        "    for (std::size_t i = 0; i < 32; ++i) {\n"
        "        out[i] = static_cast<std::uint8_t>(s0[i] ^ s1[i] ^ s2[i] ^ s3[i]);\n"
        "    }\n"
        "}\n"
    )
    pathlib.Path(sys.argv[2]).write_text(header, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
