#!/usr/bin/env python3
# Пломба библиотеки.
#
# Build-time отметка для CI: HMAC-ключ выводится из публичного отпечатка
# сертификата подписи. Это не секрет и не барьер от реверс-инжиниринга; в
# запущенном приложении пломба не проверяется.
import hashlib
import hmac
import pathlib
import struct
import sys

SALT = b"tsuyu-seal-v2"


def _sections(data):
    if data[:4] != b"\x7fELF":
        raise SystemExit("not an ELF library")
    elf_class = data[4]
    endian = "<" if data[5] == 1 else ">"
    if elf_class == 2:
        e_shoff, = struct.unpack_from(endian + "Q", data, 40)
        e_shentsize, e_shnum, e_shstrndx = struct.unpack_from(endian + "HHH", data, 58)
        sh_fmt = endian + "IIQQQQIIQQ"
        sym_entsize = 24
    elif elf_class == 1:
        e_shoff, = struct.unpack_from(endian + "I", data, 32)
        e_shentsize, e_shnum, e_shstrndx = struct.unpack_from(endian + "HHH", data, 46)
        sh_fmt = endian + "IIIIIIIIII"
        sym_entsize = 16
    else:
        raise SystemExit("unknown ELF class")
    sections = []
    for i in range(e_shnum):
        off = e_shoff + i * e_shentsize
        name, typ, flags, addr, offset, size, link, info, align, entsize = struct.unpack_from(sh_fmt, data, off)
        sections.append({
            "name": name,
            "type": typ,
            "addr": addr,
            "offset": offset,
            "size": size,
            "link": link,
            "entsize": entsize or sym_entsize,
        })
    return elf_class, endian, sections


def symbol_offset(data, name):
    elf_class, endian, sections = _sections(data)
    want = name.encode() + b"\x00"
    for sec in sections:
        if sec["type"] not in (2, 11):
            continue
        blob = data[sec["offset"]:sec["offset"] + sec["size"]]
        strings = sections[sec["link"]]
        strtab = data[strings["offset"]:strings["offset"] + strings["size"]]
        step = 24 if elf_class == 2 else 16
        for i in range(0, len(blob) - step + 1, step):
            if elf_class == 2:
                st_name, st_info, st_other, st_shndx, st_value, st_size = struct.unpack_from(endian + "IBBHQQ", blob, i)
            else:
                st_name, st_value, st_size, st_info, st_other, st_shndx = struct.unpack_from(endian + "IIIBBH", blob, i)
            if st_shndx == 0 or st_shndx >= len(sections):
                continue
            if not strtab.startswith(want, st_name) and strtab[st_name:st_name + len(want)] != want:
                continue
            target = sections[st_shndx]
            return target["offset"] + (st_value - target["addr"]), st_size
    return None, 0


def load_ranges(data):
    """Загружаемые сегменты образа (PT_LOAD) — то, что реально попадает в память.

    Пломба считается по ним, а не по файлу целиком: снятие отладочных разделов
    при сборке релиза и выравнивание упаковщика APK переписывают хвост файла, но
    содержимое загружаемых сегментов не меняют. Поэтому пломба переживает сборку
    и остаётся привязанной к коду, а не к упаковке."""
    if data[:4] != b"\x7fELF":
        raise SystemExit("not an ELF library")
    elf_class = data[4]
    endian = "<" if data[5] == 1 else ">"
    if elf_class == 2:
        phoff, = struct.unpack_from(endian + "Q", data, 32)
        phentsize, phnum = struct.unpack_from(endian + "HH", data, 54)
        fmt, off_field, size_field = "Q", 8, 32
    elif elf_class == 1:
        phoff, = struct.unpack_from(endian + "I", data, 28)
        phentsize, phnum = struct.unpack_from(endian + "HH", data, 42)
        fmt, off_field, size_field = "I", 4, 16
    else:
        raise SystemExit("unknown ELF class")
    ranges = []
    for i in range(phnum):
        off = phoff + i * phentsize
        p_type, = struct.unpack_from(endian + "I", data, off)
        if p_type != 1:  # PT_LOAD
            continue
        p_offset, = struct.unpack_from(endian + fmt, data, off + off_field)
        p_filesz, = struct.unpack_from(endian + fmt, data, off + size_field)
        begin = int(p_offset)
        size = min(int(p_filesz), max(0, len(data) - begin))
        if size > 0:
            ranges.append((begin, size))
    ranges.sort()
    if not ranges:
        raise SystemExit("no loadable segments")
    return ranges


def _blank_areas(data, slot):
    """Байты, которые пломба не покрывает: сам слот пломбы и поля ELF-заголовка,
    описывающие таблицу разделов (снятие отладочных разделов переносит её, и это
    не относится к коду)."""
    if data[4] == 2:
        areas = [(40, 48), (58, 64)]
    else:
        areas = [(32, 36), (46, 52)]
    areas.append((slot, slot + 32))
    return areas


def seal_input(data, slot, blank=True):
    """Содержимое, которое покрывает пломба: загружаемые сегменты подряд, с
    обнулёнными служебными байтами (сама пломба себя не покрывает)."""
    areas = _blank_areas(data, slot) if blank else [(slot, slot + 32)]
    parts = []
    for begin, size in load_ranges(data):
        chunk = bytearray(data[begin:begin + size])
        for lo, hi in areas:
            for i in range(max(lo, begin), min(hi, begin + size)):
                chunk[i - begin] = 0
        parts.append(bytes(chunk))
    return b"".join(parts)


def seal_key(cert_hex):
    raw = bytes.fromhex(cert_hex.strip().lower())
    if len(raw) != 32:
        raise SystemExit("cert digest must be 32 bytes")
    return hmac.new(raw, SALT, hashlib.sha256).digest()


def main():
    args = [a for a in sys.argv[1:] if a != "--plain"]
    plain = "--plain" in sys.argv
    path = pathlib.Path(args[0])
    cert_hex = args[1] if len(args) > 1 else ""
    # Сертификатный отпечаток обязателен для CI-формата отметки. Он публичен,
    # поэтому эта пломба нужна для контроля сборки, а не для защиты от реверса.
    if not cert_hex and not plain:
        raise SystemExit("cert is required to seal (use --plain only for local tests)")
    data = bytearray(path.read_bytes())
    off, size = symbol_offset(data, "k_seal")
    if off is None:
        raise SystemExit("k_seal missing after link: " + str(path))
    if size not in (0, 40) or off < 0 or off + 40 > len(data):
        raise SystemExit("k_seal slot invalid (%s, %s): %s" % (off, size, path))
    slot = off + 8
    if not any(begin <= slot and slot + 32 <= begin + size for begin, size in load_ranges(data)):
        raise SystemExit("k_seal slot is outside loadable segments")
    covered = seal_input(data, slot)
    if cert_hex:
        tag = hmac.new(seal_key(cert_hex), covered, hashlib.sha256).digest()
    elif plain:
        tag = hashlib.sha256(covered).digest()
    else:
        raise SystemExit("cert is required to seal")
    data[slot:slot + 32] = tag
    path.write_bytes(data)


if __name__ == "__main__":
    main()
