#include "crypto.h"

#include <cstdio>
#include <cstring>
#include <string>

static int fails = 0;

static void expect(bool ok, const char* name) {
    if (!ok) {
        std::printf("FAIL %s\n", name);
        ++fails;
    } else {
        std::printf("ok   %s\n", name);
    }
}

static std::string hex_of(const uint8_t* data, size_t len) {
    static const char* digits = "0123456789abcdef";
    std::string out(len * 2, '0');
    for (size_t i = 0; i < len; ++i) {
        out[i * 2] = digits[data[i] >> 4];
        out[i * 2 + 1] = digits[data[i] & 0x0f];
    }
    return out;
}

int main() {
    uint8_t key[32];
    uint8_t plain[16];
    for (int i = 0; i < 32; ++i) key[i] = static_cast<uint8_t>(i);
    for (int i = 0; i < 16; ++i) plain[i] = static_cast<uint8_t>(i * 17);
    uint8_t cipher[16];
    aes256_encrypt_block(key, plain, cipher);
    expect(hex_of(cipher, 16) == "8ea2b7ca516745bfeafc49904b496089", "aes-256 block");

    uint8_t hash[32];
    const char* abc = "abc";
    sha256(reinterpret_cast<const uint8_t*>(abc), 3, hash);
    expect(hex_of(hash, 32) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", "sha256 abc");

    expect(decode_cf_domain("virkgj.com") == "pclead.co.uk", "domain decode");
    expect(normalize_cf_domain("Virkgj.com") == "pclead.co.uk", "domain normalize");
    expect(normalize_cf_domain("example.org").empty(), "domain reject");

    uint8_t secret[16];
    std::memset(secret, 0x11, sizeof(secret));
    uint8_t packet[64];
    random_bytes(packet, 64);
    uint8_t derived[32];
    sha256_2(packet + 8, 32, secret, 16, derived);
    Ctr stream;
    stream.init(derived, packet + 40);
    uint8_t keystream[64];
    std::memset(keystream, 0, sizeof(keystream));
    stream.xor_buf(keystream, 64);
    uint8_t tag[4] = {0xdd, 0xdd, 0xdd, 0xdd};
    int16_t dc = -2;
    for (int i = 0; i < 4; ++i) packet[56 + i] = tag[i] ^ keystream[56 + i];
    packet[60] = static_cast<uint8_t>(dc) ^ keystream[60];
    packet[61] = static_cast<uint8_t>(dc >> 8) ^ keystream[61];

    Handshake parsed;
    expect(read_handshake(packet, secret, 16, &parsed), "handshake accept");
    expect(parsed.proto == 0xDDDDDDDDu && parsed.dc == 2 && parsed.media, "handshake fields");
    expect(parsed.client_dec.processed == 64, "decryptor advanced");

    uint8_t relay[64];
    Ctr enc;
    Ctr dec;
    build_relay(tag, 4, false, relay, &enc, &dec);
    Ctr check;
    check.init(relay + 8, relay + 40);
    uint8_t opened[64];
    std::memcpy(opened, relay, 64);
    check.xor_buf(opened, 64);
    expect(std::memcmp(opened + 56, tag, 4) == 0 && opened[60] == 4 && opened[61] == 0, "relay tail");
    uint8_t a[48];
    uint8_t b[48];
    random_bytes(a, sizeof(a));
    std::memcpy(b, a, sizeof(a));
    enc.xor_buf(a, sizeof(a));
    check.xor_buf(b, sizeof(b));
    expect(std::memcmp(a, b, sizeof(a)) == 0, "relay stream continues");

    uint8_t iv[16];
    std::memset(iv, 0x5a, sizeof(iv));
    uint8_t sample[64];
    for (int i = 0; i < 64; ++i) sample[i] = static_cast<uint8_t>(i * 3 + 1);
    Ctr ctr;
    ctr.init(key, iv);
    uint8_t once[64];
    std::memcpy(once, sample, 64);
    ctr.xor_buf(once, 17);
    ctr.xor_buf(once + 17, 47);
    Ctr again;
    again.init(key, iv);
    uint8_t whole[64];
    std::memcpy(whole, sample, 64);
    again.xor_buf(whole, 64);
    expect(std::memcmp(once, whole, 64) == 0, "ctr partial blocks");

    std::printf(fails ? "%d failed\n" : "all passed\n", fails);
    return fails ? 1 : 0;
}
