__attribute__((used, visibility("default")))
unsigned char k_seal[40] = {
        0xC3, 0x91, 0x5A, 0xE7, 0x14, 0xB8, 0x6D, 0x02,
        0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0};

__attribute__((used, visibility("default"), noinline)) unsigned char* seal_ptr(void) {
    return k_seal;
}
