#include <jni.h>

extern "C" __attribute__((visibility("default"))) int q7a(int x) {
    int s = x ^ 0x15;
    for (int i = 0; i < 3; ++i) {
        s = (s * 17 + 3) ^ (i + 1);
    }
    return s;
}

extern "C" __attribute__((visibility("default"))) int m2c(int a, int b) {
    return (a + b) ^ 0x2c;
}

extern "C" __attribute__((visibility("default"))) int r9e(const char* text) {
    int n = 0;
    if (text != nullptr) {
        while (text[n] != '\0' && n < 32) {
            ++n;
        }
    }
    return n ^ 0x9e;
}

extern "C" __attribute__((visibility("default"))) jint Java_com_tsuyu_proxy_N_a(JNIEnv*, jclass, jint x) {
    return q7a(x) ^ 0x11;
}

extern "C" __attribute__((visibility("default"))) jint Java_com_tsuyu_proxy_N_b(JNIEnv*, jclass, jint x) {
    return m2c(x, 4);
}
