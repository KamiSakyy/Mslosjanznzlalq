#include "obf.h"
#include "tsproxy.h"
#include "tsuyu_string_key.h"

#include <mbedtls/gcm.h>

#include <jni.h>

#include <string>
#include <vector>

static std::string jstring_to_std(JNIEnv* env, jstring value) {
    if (value == nullptr) {
        return "";
    }
    const char* chars = env->GetStringUTFChars(value, nullptr);
    std::string out = chars == nullptr ? "" : chars;
    if (chars != nullptr) {
        env->ReleaseStringUTFChars(value, chars);
    }
    return out;
}

static jint native_start(JNIEnv* env, jclass, jstring host, jint port, jstring secret) {
    std::string host_text = jstring_to_std(env, host);
    std::string secret_text = jstring_to_std(env, secret);
    if (host_text.empty()) {
        host_text = XS("127.0.0.1");
    }
    return proxy_start(host_text.c_str(), port, secret_text.c_str());
}

static void native_stop(JNIEnv* env, jclass) {
    proxy_stop();
}

static void native_configure(JNIEnv* env, jclass, jint pool, jstring cache_dir, jint cf_enabled, jstring user_domain) {
    std::string cache = jstring_to_std(env, cache_dir);
    std::string domain = jstring_to_std(env, user_domain);
    proxy_configure(pool, cache.c_str(), cf_enabled, domain.c_str());
}

static jboolean native_alive(JNIEnv*, jclass) {
    return proxy_alive() ? JNI_TRUE : JNI_FALSE;
}

static jlong native_bytes_up(JNIEnv*, jclass) {
    return static_cast<jlong>(proxy_bytes_up());
}

static jlong native_bytes_down(JNIEnv*, jclass) {
    return static_cast<jlong>(proxy_bytes_down());
}

static jint native_ping(JNIEnv*, jclass) {
    return proxy_ping_ms();
}

static jstring native_text(JNIEnv* env, int (*copy)(char*, int)) {
    char buf[8192];
    int n = copy(buf, static_cast<int>(sizeof(buf)));
    if (n < 0) {
        n = 0;
    }
    buf[n] = '\0';
    return env->NewStringUTF(buf);
}

static jint native_search(JNIEnv* env, jclass) {
    return proxy_search_start();
}

static jint native_refresh(JNIEnv* env, jclass) {
    return proxy_refresh_start();
}

static jboolean native_search_running(JNIEnv*, jclass) {
    return proxy_search_running() ? JNI_TRUE : JNI_FALSE;
}

static jint native_search_checked(JNIEnv*, jclass) {
    return proxy_search_checked();
}

static jstring native_fronts(JNIEnv* env, jclass) {
    std::string text = proxy_fronts_text();
    return env->NewStringUTF(text.c_str());
}

static void native_select(JNIEnv* env, jclass, jstring domain) {
    std::string text = jstring_to_std(env, domain);
    proxy_select(text.c_str());
}

static jstring native_selected(JNIEnv* env, jclass) {
    return native_text(env, proxy_copy_selected);
}

static jstring native_fastest(JNIEnv* env, jclass) {
    return native_text(env, proxy_copy_fastest);
}

static jboolean native_needs_restart(JNIEnv*, jclass) {
    return proxy_needs_restart() ? JNI_TRUE : JNI_FALSE;
}

static void native_clear_restart(JNIEnv*, jclass) {
    proxy_clear_restart();
}

static jint native_heal(JNIEnv* env, jclass) {
    return proxy_heal();
}

static jint native_live(JNIEnv*, jclass) {
    return proxy_live_fronts();
}

static void native_network(JNIEnv* env, jclass) {
    proxy_network_changed();
}

static jboolean native_hostile(JNIEnv*, jclass) {
    return JNI_FALSE;
}

static void native_note(JNIEnv*, jclass, jobject) {
    // Раньше здесь включалась проверка окружения на запущенном приложении.
    // Теперь ничего не проверяется: защита — статическая, приложение не тратит
    // на неё ни времени, ни батареи.
}

static jint native_n0(JNIEnv*, jclass, jint a) {
    int s = a ^ 0x21;
    s = (s << 1) ^ 0x5;
    return s;
}

static jint native_n1(JNIEnv*, jclass, jint a, jint b) {
    return (a * 3 + b) ^ 0x44;
}

static void native_n2(JNIEnv* env, jclass, jstring) {
}

// Имена и сигнатуры моста собираются в рантайме из обфусцированных строк:
// в самой библиотеке не остаётся ни одного читаемого «nativeStart», по которому
// можно было бы восстановить интерфейс между Java и ядром.
struct MethodSlot {
    std::string name;
    std::string signature;
};

static std::vector<MethodSlot> kSlots = {
        {XS("nativeStart"), XS("(Ljava/lang/String;ILjava/lang/String;)I")},
        {XS("nativeStop"), XS("()V")},
        {XS("nativeConfigure"), XS("(ILjava/lang/String;ILjava/lang/String;)V")},
        {XS("nativeAlive"), XS("()Z")},
        {XS("nativeBytesUp"), XS("()J")},
        {XS("nativeBytesDown"), XS("()J")},
        {XS("nativePing"), XS("()I")},
        {XS("nativeSearch"), XS("()I")},
        {XS("nativeRefresh"), XS("()I")},
        {XS("nativeSearchRunning"), XS("()Z")},
        {XS("nativeSearchChecked"), XS("()I")},
        {XS("nativeFronts"), XS("()Ljava/lang/String;")},
        {XS("nativeSelect"), XS("(Ljava/lang/String;)V")},
        {XS("nativeSelected"), XS("()Ljava/lang/String;")},
        {XS("nativeFastest"), XS("()Ljava/lang/String;")},
        {XS("nativeNeedsRestart"), XS("()Z")},
        {XS("nativeClearRestart"), XS("()V")},
        {XS("nativeHeal"), XS("()I")},
        {XS("nativeLive"), XS("()I")},
        {XS("nativeNetwork"), XS("()V")},
        {XS("nHostile"), XS("()Z")},
        {XS("nNote"), XS("(Landroid/content/Context;)V")},
        {XS("n0"), XS("(I)I")},
        {XS("n1"), XS("(II)I")},
        {XS("n2"), XS("(Ljava/lang/String;)V")},
};

static const void* kImpl[] = {
        reinterpret_cast<void*>(native_start),
        reinterpret_cast<void*>(native_stop),
        reinterpret_cast<void*>(native_configure),
        reinterpret_cast<void*>(native_alive),
        reinterpret_cast<void*>(native_bytes_up),
        reinterpret_cast<void*>(native_bytes_down),
        reinterpret_cast<void*>(native_ping),
        reinterpret_cast<void*>(native_search),
        reinterpret_cast<void*>(native_refresh),
        reinterpret_cast<void*>(native_search_running),
        reinterpret_cast<void*>(native_search_checked),
        reinterpret_cast<void*>(native_fronts),
        reinterpret_cast<void*>(native_select),
        reinterpret_cast<void*>(native_selected),
        reinterpret_cast<void*>(native_fastest),
        reinterpret_cast<void*>(native_needs_restart),
        reinterpret_cast<void*>(native_clear_restart),
        reinterpret_cast<void*>(native_heal),
        reinterpret_cast<void*>(native_live),
        reinterpret_cast<void*>(native_network),
        reinterpret_cast<void*>(native_hostile),
        reinterpret_cast<void*>(native_note),
        reinterpret_cast<void*>(native_n0),
        reinterpret_cast<void*>(native_n1),
        reinterpret_cast<void*>(native_n2),
};

static jbyteArray native_string_decode(JNIEnv* env, jclass, jbyteArray payload) {
    if (payload == nullptr) {
        return env->NewByteArray(0);
    }
    const jsize packed_size = env->GetArrayLength(payload);
    constexpr jsize kNonceSize = 12;
    constexpr jsize kTagSize = 16;
    constexpr jsize kHeaderSize = kNonceSize + kTagSize;
    if (packed_size < kHeaderSize) {
        return env->NewByteArray(0);
    }

    std::vector<unsigned char> packed(static_cast<std::size_t>(packed_size));
    env->GetByteArrayRegion(payload, 0, packed_size, reinterpret_cast<jbyte*>(packed.data()));
    if (env->ExceptionCheck()) {
        return nullptr;
    }

    const std::size_t cipher_size = packed.size() - static_cast<std::size_t>(kHeaderSize);
    std::vector<unsigned char> clear(cipher_size);
    unsigned char key[32];
    tso_get_string_key(key);

    mbedtls_gcm_context context;
    mbedtls_gcm_init(&context);
    int result = mbedtls_gcm_setkey(&context, MBEDTLS_CIPHER_ID_AES, key, 256);
    if (result == 0) {
        const unsigned char* nonce = packed.data();
        const unsigned char* ciphertext = packed.data() + kNonceSize;
        const unsigned char* tag = ciphertext + cipher_size;
        result = mbedtls_gcm_auth_decrypt(
                &context,
                cipher_size,
                nonce,
                kNonceSize,
                nullptr,
                0,
                tag,
                kTagSize,
                ciphertext,
                clear.data());
    }
    mbedtls_gcm_free(&context);

    volatile unsigned char* key_bytes = key;
    for (std::size_t i = 0; i < sizeof(key); ++i) {
        key_bytes[i] = 0;
    }
    if (result != 0) {
        volatile unsigned char* failed_clear = clear.data();
        for (std::size_t i = 0; i < clear.size(); ++i) {
            failed_clear[i] = 0;
        }
        return env->NewByteArray(0);
    }

    jbyteArray output = env->NewByteArray(static_cast<jsize>(clear.size()));
    if (output != nullptr && !clear.empty()) {
        env->SetByteArrayRegion(
                output,
                0,
                static_cast<jsize>(clear.size()),
                reinterpret_cast<const jbyte*>(clear.data()));
    }
    volatile unsigned char* clear_bytes = clear.data();
    for (std::size_t i = 0; i < clear.size(); ++i) {
        clear_bytes[i] = 0;
    }
    return output;
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK || env == nullptr) {
        return JNI_ERR;
    }
    std::string core_name = XS("com/tsuyu/proxy/Mk");
    jclass core = env->FindClass(core_name.c_str());
    if (core == nullptr) {
        return JNI_ERR;
    }
    size_t count = kSlots.size();
    if (count != sizeof(kImpl) / sizeof(kImpl[0])) {
        return JNI_ERR;
    }
    std::vector<JNINativeMethod> methods(count);
    for (size_t i = 0; i < count; ++i) {
        methods[i].name = const_cast<char*>(kSlots[i].name.c_str());
        methods[i].signature = const_cast<char*>(kSlots[i].signature.c_str());
        methods[i].fnPtr = const_cast<void*>(kImpl[i]);
    }
    if (env->RegisterNatives(core, methods.data(), static_cast<jint>(count)) != 0) {
        return JNI_ERR;
    }

    std::string decoder_class_name = XS("com/tsuyu/proxy/N");
    jclass decoder = env->FindClass(decoder_class_name.c_str());
    if (decoder == nullptr) {
        return JNI_ERR;
    }
    std::string decoder_method_name = XS("d");
    std::string decoder_method_signature = XS("([B)[B");
    JNINativeMethod decoder_method = {
            const_cast<char*>(decoder_method_name.c_str()),
            const_cast<char*>(decoder_method_signature.c_str()),
            reinterpret_cast<void*>(native_string_decode),
    };
    if (env->RegisterNatives(decoder, &decoder_method, 1) != 0) {
        return JNI_ERR;
    }
    env->DeleteLocalRef(decoder);
    return JNI_VERSION_1_6;
}
