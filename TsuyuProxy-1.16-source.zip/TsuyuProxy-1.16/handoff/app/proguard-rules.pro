-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-overloadaggressively
-mergeinterfacesaggressively
-obfuscationdictionary proguard-dictionary.txt
-classobfuscationdictionary proguard-dictionary.txt
-packageobfuscationdictionary proguard-dictionary.txt
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# Manifest entry points retain their required class names.
-keep class a.a.a
-keep class a.a.b
-keep class a.a.c
-keep class a.a.d
-keep class a.a.e
-keep class a.a.f
-keep class a.a.g

# JNI_OnLoad resolves this class and its native method names dynamically.
-keep,allowoptimization class com.tsuyu.proxy.Mk {
    native <methods>;
}

# Build-time string instrumentation calls n(); the native decoder d() is
# registered by name from JNI_OnLoad and must retain its signature.
-keep,allowoptimization class com.tsuyu.proxy.N {
    private static native byte[] d(byte[]);
}
