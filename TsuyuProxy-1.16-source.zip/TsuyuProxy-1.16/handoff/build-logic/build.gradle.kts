plugins {
    `java-gradle-plugin`
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

dependencies {
    compileOnly("com.android.tools.build:gradle:8.9.2")
    compileOnly("org.ow2.asm:asm:9.7")
    compileOnly("org.jetbrains.kotlin:kotlin-stdlib:2.0.21")
}

gradlePlugin {
    plugins {
        create("stringfog") {
            id = "org.tsuyu.stringfog"
            implementationClass = "org.tsuyu.build.StringFogPlugin"
        }
    }
}
