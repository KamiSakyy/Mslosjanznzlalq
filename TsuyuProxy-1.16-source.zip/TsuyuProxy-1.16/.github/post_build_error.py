import json
import os
import urllib.request

text = open("/tmp/gradle-build.log", encoding="utf-8", errors="replace").read()
keys = ("What went wrong", "FAILURE", "Execution failed", "e: ", "error:", "Caused by:", "Unresolved", "> ")
picked = [line for line in text.splitlines() if any(key in line for key in keys)]
body = "Сборка упала:\n\n```\n" + "\n".join(picked[-180:]) + "\n\n--- tail ---\n" + text[-4000:] + "\n```"
req = urllib.request.Request(
    "https://api.github.com/repos/KamiSakyy/Tststtstststskalxmnzka/commits/"
    + os.environ["GITHUB_SHA"]
    + "/comments",
    data=json.dumps({"body": body}).encode(),
    headers={
        "Authorization": "Bearer " + os.environ["GH_TOKEN"],
        "Accept": "application/vnd.github+json",
        "Content-Type": "application/json",
        "User-Agent": "arena-build",
    },
)
try:
    print(urllib.request.urlopen(req).status)
except Exception as exc:
    print("comment failed", exc)
