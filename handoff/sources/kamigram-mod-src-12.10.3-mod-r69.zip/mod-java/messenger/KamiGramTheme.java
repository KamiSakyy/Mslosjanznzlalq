package org.telegram.messenger.kamigram;

import org.telegram.messenger.ApplicationLoader;
import org.telegram.messenger.FileLog;
import org.telegram.ui.ActionBar.Theme;

/**
 * KamiGram: iOS-цвета кодом (генерируется пакетом улучшений).
 * Тема задаёт общий вид, а эти ключи Telegram берёт из своих значений,
 * поэтому они переопределяются прямо в коде - как в iOS.
 */
public final class KamiGramTheme {

    private KamiGramTheme() {
    }

    /** Применяет iOS-цвета (только при включённом iOS-дизайне). */
    public static void apply() {
        try {
            if (!KamiGramConfig.iosDesign()) {
                return;
            }
            if (ApplicationLoader.applicationContext != null) {
                Theme.createDialogsResources(ApplicationLoader.applicationContext);
            }
        } catch (Throwable e) {
            FileLog.e(e);
        }
    }

    private static void set(int key, int color) {
        try {
            Theme.setColor(key, color, false);
        } catch (Throwable ignore) {
        }
    }
}
