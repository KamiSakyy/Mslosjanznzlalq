package org.telegram.messenger.kamigram;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.os.SystemClock;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.ApplicationLoader;
import org.telegram.messenger.FileLoadOperation;
import org.telegram.messenger.MessagesController;
import org.telegram.messenger.NotificationCenter;
import org.telegram.messenger.SharedConfig;
import org.telegram.messenger.UserConfig;
import org.telegram.proxy.ProxySettings;
import org.telegram.tgnet.ConnectionsManager;
import org.telegram.tgnet.TLObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Быстрый наблюдатель SakuProxy.
 *
 * Пользовательские записи не смешиваются с каталогом SakuProxy: пока custom
 * прокси жив, он остаётся выбранным. При подтверждённом сбое выбирается лучший
 * уже проверенный встроенный прокси, а если проверки ещё нет — запускается сразу.
 */
public final class KamiGramProxyPower implements NotificationCenter.NotificationCenterDelegate {

    /* KAMIGRAM_PROXY_FAST_FAILOVER_R77: a failed live route is replaced
       immediately; there is no long rotation cooldown hiding a faster route. */
    private static final long SWITCH_DELAY = 180L;
    private static final long DEAD_DELAY = 120L;
    private static final long CURRENT_FRESHNESS = 8_000L;
    private static final long LOOP_DELAY = 5_000L;
    private static final long SPEED_MARGIN = 25L;
    /* KAMIGRAM_PROXY_SEND_LEASE_R78 is retained only as a compatibility marker.
       r80 tracks real native request tokens instead of holding a fixed timer. */
    /* r81: request tokens are local to a ConnectionsManager. Include the
       account in the key so two accounts cannot release one another's send
       guard and rotate a route during an active upload. */
    private static final ConcurrentHashMap<Long, Boolean> MESSAGE_REQUESTS_IN_FLIGHT = new ConcurrentHashMap<>();

    private static final KamiGramProxyPower INSTANCE = new KamiGramProxyPower();

    private boolean initialized;
    private boolean switching;
    private boolean loopPosted;
    /* True only after Telegram confirms a usable connection. */
    private boolean lastConnectionHealthy;
    private long lastSwitchTime;
    private int loadFailures;
    private long loadFailureTime;
    private long lastLoadSwitch;

    private final Runnable switchRunnable = () -> {
        switching = false;
        switchToBest(null);
    };

    private KamiGramProxyPower() {
    }

    public static void init() {
        INSTANCE.initInternal();
        KamiGramBuiltinProxy.ensureBuiltinsLoaded();
    }

    private void initInternal() {
        if (initialized) {
            return;
        }
        initialized = true;
        try {
            KamiGramBuiltinProxy.ensureBuiltinsLoaded();
            for (int account = 0; account < UserConfig.MAX_ACCOUNT_COUNT; account++) {
                NotificationCenter.getInstance(account).addObserver(this, NotificationCenter.didUpdateConnectionState);
                NotificationCenter.getInstance(account).addObserver(this, NotificationCenter.fileLoadFailed);
                NotificationCenter.getInstance(account).addObserver(this, NotificationCenter.httpFileDidFailedLoad);
            }
            final NotificationCenter global = NotificationCenter.getGlobalInstance();
            global.addObserver(this, NotificationCenter.proxyCheckDone);
            global.addObserver(this, NotificationCenter.proxySettingsChanged);
            /* KAMIGRAM_PROXY_WATCH_ACTIVE_ONLY_R83: no permanent proxy timer;
               FileLoader starts it only while a native download is active. */
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
        }
    }

    private static boolean enabled() {
        return KamiGramBuiltinProxy.enabled();
    }

    private static boolean smartEnabled() {
        return KamiGramConfig.smartProxy();
    }

    /**
     * Central request classifier used by ConnectionsManager. Route stability is
     * tied to the real native request token, never to a synthetic delay. The
     * token is removed on Telegram's response or cancellation, so ordinary
     * sends remain immediate while the smart watcher cannot rotate the route
     * underneath an active send.
     */
    public static boolean isMessageRequest(TLObject object) {
        if (object == null) {
            return false;
        }
        try {
            final String simple = object.getClass().getSimpleName().toLowerCase();
            return simple.contains("sendmessage")
                || simple.contains("sendmedia")
                || simple.contains("sendmultimedia")
                || simple.contains("sendinlinebotresult")
                || simple.contains("sendpaidmessage")
                || simple.contains("sendscheduledmessages")
                || simple.contains("forwardmessages");
        } catch (Throwable ignore) {
            return false;
        }
    }

    private static long requestKey(int account, int requestToken) {
        return (((long) account) << 32) ^ (requestToken & 0xffffffffL);
    }

    /** r81: pin only the actual native request, with an account-safe token. */
    public static void noteMessageRequestStarted(int account, int requestToken) {
        if (requestToken >= 0) {
            MESSAGE_REQUESTS_IN_FLIGHT.put(requestKey(account, requestToken), Boolean.TRUE); /* KAMIGRAM_REQUEST_ACCOUNT_R81 */
        }
    }

    /** Compatibility overload for older call sites; it still has no timer. */
    public static void noteMessageRequestStarted(int requestToken) {
        noteMessageRequestStarted(-1, requestToken);
    }

    public static void noteMessageRequestStarted() {
        MESSAGE_REQUESTS_IN_FLIGHT.put(requestKey(-1, Integer.MIN_VALUE), Boolean.TRUE); /* KAMIGRAM_INSTANT_SEND_R80 */
    }

    /** Route selection is stable only while a real request token is active. */
    public static boolean messageSendInFlight() {
        return !MESSAGE_REQUESTS_IN_FLIGHT.isEmpty(); /* KAMIGRAM_INSTANT_SEND_R80 */
    }

    public static void noteMessageRequestFinished(int account, int requestToken) {
        MESSAGE_REQUESTS_IN_FLIGHT.remove(requestKey(account, requestToken)); /* KAMIGRAM_REQUEST_ACCOUNT_R81 */
    }

    public static void noteMessageRequestFinished(int requestToken) {
        noteMessageRequestFinished(-1, requestToken);
    }

    public static void noteMessageRequestFinished() {
        MESSAGE_REQUESTS_IN_FLIGHT.remove(requestKey(-1, Integer.MIN_VALUE)); /* KAMIGRAM_PROXY_SEND_FINISH_R78 */
    }

    private void startLoop() {
        if (loopPosted || !downloadsActive()) {
            return;
        }
        loopPosted = true;
        AndroidUtilities.runOnUIThread(loopRunnable, LOOP_DELAY);
    }

    private void stopLoop() {
        loopPosted = false;
        AndroidUtilities.cancelRunOnUIThread(loopRunnable);
        cancelSwitch();
    }

    private static boolean downloadsActive() {
        try {
            return KamiGramDownloadRecovery.hasActiveDownloads();
        } catch (Throwable ignore) {
            return false;
        }
    }

    /** Native FileLoader activity is the only reason to run proxy checks. */
    public static void onDownloadActivityChanged() {
        try {
            if (downloadsActive() && enabled() && smartEnabled()) {
                INSTANCE.startLoop();
            } else {
                INSTANCE.stopLoop();
            }
            KamiGramBuiltinProxy.onDownloadActivityChanged();
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
        }
    }

    private final Runnable loopRunnable = new Runnable() {
        @Override
        public void run() {
            loopPosted = false;
            try {
                if (downloadsActive() && enabled() && smartEnabled()) {
                    tickInternal();
                }
            } catch (Throwable throwable) {
                KamiGramLog.e(throwable);
            }
            if (downloadsActive() && enabled() && smartEnabled()) {
                startLoop();
            }
        }
    };

    private void tickInternal() {
        try {
            if (!downloadsActive()) {
                return; /* KAMIGRAM_PROXY_WATCH_ACTIVE_ONLY_R83 */
            }
            /* KAMIGRAM_PROXY_SEND_GUARD_R78: never rotate a route in the
               middle of an ordinary message send/retry. */
            if (messageSendInFlight()) {
                return;
            }
            KamiGramBuiltinProxy.ensureBuiltinsLoaded();
            final SharedConfig.ProxyInfo current = SharedConfig.currentProxy;
            final long now = SystemClock.elapsedRealtime();
            if (current != null && current.settings != null && !current.checking
                && (current.availableCheckTime == 0 || now - current.availableCheckTime > CURRENT_FRESHNESS)) {
                checkOne(current);
            }
            pingAll();

            /* The built-in manager also handles the no-current case. Calling it
               here closes the gap between app resume and its delayed watcher. */
            KamiGramBuiltinProxy.route(null, false);

            final SharedConfig.ProxyInfo refreshed = SharedConfig.currentProxy;
            if (refreshed == null || refreshed.settings == null) {
                return;
            }
            if (!refreshed.checking && refreshed.availableCheckTime != 0 && !refreshed.available) {
                switchToBest(null);
            } else if (refreshed.available && refreshed.ping > 0
                && KamiGramBuiltinProxy.isBuiltIn(refreshed)) {
                final SharedConfig.ProxyInfo best = KamiGramBuiltinProxy.bestAvailable();
                if (best != null && best != refreshed && best.ping + SPEED_MARGIN < refreshed.ping) {
                    /* KAMIGRAM_PROXY_FASTEST_LIVE_R77: do not keep a slower
                       built-in route merely because a cooldown is running. */
                    if (activate(best, null, true)) {
                        lastSwitchTime = now;
                        checkOne(best);
                    }
                }
            }
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
        }
    }

    private static Context contextOrNull() {
        try {
            return ApplicationLoader.applicationContext;
        } catch (Throwable ignore) {
            return null;
        }
    }

    /**
     * A live custom proxy is never replaced. An untested custom proxy is probed
     * first, so a short connection setup is not mistaken for a failure.
     */
    private static boolean customIsKnownDead(SharedConfig.ProxyInfo info) {
        return info != null && !KamiGramBuiltinProxy.isBuiltIn(info)
            && !info.checking && info.availableCheckTime != 0 && !info.available;
    }

    private static ArrayList<SharedConfig.ProxyInfo> aliveBuiltins() {
        final ArrayList<SharedConfig.ProxyInfo> result = new ArrayList<>();
        try {
            KamiGramBuiltinProxy.ensureBuiltinsLoaded();
            for (SharedConfig.ProxyInfo info : SharedConfig.proxyList) {
                if (KamiGramBuiltinProxy.isBuiltIn(info) && info.available && info.ping > 0) {
                    result.add(info);
                }
            }
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
        }
        return result;
    }

    /** Activate only a built-in fallback, never an arbitrary custom row. */
    private void switchToBest(Context context) {
        if (!enabled() || !smartEnabled() || messageSendInFlight()) {
            return; /* KAMIGRAM_PROXY_SEND_GUARD_R78 */
        }
        try {
            KamiGramBuiltinProxy.ensureBuiltinsLoaded();
            final SharedConfig.ProxyInfo current = SharedConfig.currentProxy;
            if (current != null && !KamiGramBuiltinProxy.isBuiltIn(current)) {
                if (current.available && current.ping > 0) {
                    return;
                }
                if (current.availableCheckTime == 0 || current.checking) {
                    checkOne(current);
                    return;
                }
                if (!customIsKnownDead(current)) {
                    return;
                }
            }

            final SharedConfig.ProxyInfo best = KamiGramBuiltinProxy.bestAvailable();
            if (best != null && best != current) {
                activate(best, contextOrNull(), true);
                return;
            }

            /* No result yet: probe all built-ins immediately. We deliberately do
               not disable the proxy or erase the custom pool while waiting. */
            pingAllBuiltins();
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
        }
    }

    private static void pingAllBuiltins() {
        try {
            KamiGramBuiltinProxy.ensureBuiltinsLoaded();
            for (SharedConfig.ProxyInfo info : SharedConfig.proxyList) {
                if (KamiGramBuiltinProxy.isBuiltIn(info) && !info.checking
                    && (info.availableCheckTime == 0 || !info.available)) {
                    checkOne(info);
                }
            }
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
        }
    }

    /** Called when a large native download is stalled or demonstrably too slow. */
    public static void onSlowDownload(FileLoadOperation operation) {
        try {
            if (operation == null || !downloadsActive() || !enabled() || !smartEnabled() || messageSendInFlight()) {
                return;
            }
            final long now = SystemClock.elapsedRealtime();
            if (now - INSTANCE.lastLoadSwitch < 15_000L) {
                return;
            }
            final SharedConfig.ProxyInfo current = SharedConfig.currentProxy;
            if (current == null || current.settings == null) {
                return;
            }
            INSTANCE.lastLoadSwitch = now;
            INSTANCE.loadFailures = 0;
            current.available = false;
            current.ping = 0;
            current.availableCheckTime = now;
            INSTANCE.switchToBest(contextOrNull());
        } catch (Throwable ignored) {
        }
    }

    private void onLoadFailure() {
        if (!downloadsActive()) {
            return; /* KAMIGRAM_PROXY_WATCH_ACTIVE_ONLY_R83 */
        }
        final long now = SystemClock.elapsedRealtime();
        if (now - loadFailureTime > 45_000L) {
            loadFailures = 0;
        }
        loadFailureTime = now;
        loadFailures++;

        final SharedConfig.ProxyInfo current = SharedConfig.currentProxy;
        if (current == null || current.settings == null) {
            return;
        }
        if (!current.checking && now - current.availableCheckTime > 3_000L) {
            checkOne(current);
        }
        if (loadFailures >= 2 && now - lastLoadSwitch > 15_000L) {
            final boolean isCustom = !KamiGramBuiltinProxy.isBuiltIn(current);
            if (isCustom || KamiGramBuiltinProxy.bestAvailable() != null) {
                loadFailures = 0;
                lastLoadSwitch = now;
                current.available = false;
                current.ping = 0;
                current.availableCheckTime = now;
                // ConnectionsManager.setProxySettings() invokes the resumable
                // FileLoader handover hook; no legacy network nudge is needed.
                switchToBest(contextOrNull());
            }
        }
    }

    /** Connect a proxy object already present in SharedConfig.proxyList. */
    public static boolean activate(SharedConfig.ProxyInfo info, Context context, boolean silent) {
        if (info == null || info.settings == null) {
            return false;
        }
        try {
            final SharedPreferences preferences = MessagesController.getGlobalMainSettings();
            if (preferences == null) {
                return false;
            }
            final SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("proxy_enabled", true);
            info.settings.toSharedPreferences(editor);
            if (!info.settings.getSecret().isEmpty()) {
                editor.putBoolean("proxy_enabled_calls", false);
            }
            editor.commit();
            /* A route change starts a new connection attempt. Never let the
               previous healthy state hide the new route's connecting phase. */
            INSTANCE.lastConnectionHealthy = false; /* KAMIGRAM_PROXY_ROUTE_CHANGE_R77 */
            SharedConfig.currentProxy = info;
            SharedConfig.saveProxyList();
            ConnectionsManager.setProxySettings(true, info.settings);
            NotificationCenter.getGlobalInstance().postNotificationName(NotificationCenter.proxySettingsChanged);
            NotificationCenter.getGlobalInstance().postNotificationName(NotificationCenter.proxyChangedByRotation);
            return true;
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
            return false;
        }
    }

    /** Add a user link without confusing it with a built-in preset. */
    public static boolean addAndActivate(String link, Context context) {
        try {
            final ProxySettings settings = ProxySettings.fromUri(Uri.parse(link));
            if (settings == null || !settings.isValid()) {
                return false;
            }
            final SharedConfig.ProxyInfo info = SharedConfig.addProxy(new SharedConfig.ProxyInfo(settings));
            return activate(info, context, true);
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
            return false;
        }
    }

    private void scheduleSwitch(long delay) {
        if (switching) {
            return;
        }
        switching = true;
        AndroidUtilities.runOnUIThread(switchRunnable, delay);
    }

    private void cancelSwitch() {
        switching = false;
        AndroidUtilities.cancelRunOnUIThread(switchRunnable);
    }

    public static void checkOne(final SharedConfig.ProxyInfo info) {
        if (info == null || info.checking || info.settings == null) {
            return;
        }
        try {
            info.checking = true;
            final int account = UserConfig.selectedAccount;
            ConnectionsManager.getInstance(account).checkProxy(info.settings, time -> AndroidUtilities.runOnUIThread(() -> {
                info.availableCheckTime = SystemClock.elapsedRealtime();
                info.checking = false;
                if (time == -1 || time <= 0) {
                    info.available = false;
                    info.ping = 0;
                } else {
                    info.available = true;
                    info.ping = time;
                }
                NotificationCenter.getGlobalInstance().postNotificationName(NotificationCenter.proxyCheckDone, info);
            }));
        } catch (Throwable throwable) {
            info.checking = false;
            KamiGramLog.e(throwable);
        }
    }

    /** Check all distinct proxy settings without collapsing custom and built-in rows. */
    public static void pingAll() {
        try {
            KamiGramBuiltinProxy.ensureBuiltinsLoaded();
            if (SharedConfig.proxyList == null) {
                return;
            }
            final long now = SystemClock.elapsedRealtime();
            final HashSet<String> seen = new HashSet<>();
            for (SharedConfig.ProxyInfo info : SharedConfig.proxyList) {
                if (info == null || info.settings == null) {
                    continue;
                }
                final String key = info.settings.getLink();
                if (!seen.add(key) || info.checking) {
                    continue;
                }
                final boolean current = info == SharedConfig.currentProxy;
                final long freshness = current ? 8_000L : 30_000L;
                if (info.availableCheckTime == 0 || now - info.availableCheckTime >= freshness) {
                    checkOne(info);
                }
            }
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
        }
    }

    public static void tick(Context context) {
        try {
            if (!downloadsActive() || !enabled() || !smartEnabled()) {
                return;
            }
            INSTANCE.tickInternal();
            INSTANCE.startLoop();
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
        }
    }

    public static String statusText() {
        try {
            if (!enabled()) {
                return "SakuProxy выключен";
            }
            final SharedConfig.ProxyInfo current = SharedConfig.currentProxy;
            if (current == null || current.settings == null) {
                return "SakuProxy · ищу живой";
            }
            final String prefix = KamiGramBuiltinProxy.isBuiltIn(current)
                ? "SakuProxy" : "Пользовательский прокси";
            final String state;
            if (current.checking) {
                state = "проверяю…";
            } else if (current.available && current.ping > 0) {
                state = current.ping + " мс";
            } else {
                state = "ищу резерв";
            }
            final int alive = aliveBuiltins().size();
            return prefix + " · " + state + " · SakuProxy живых: " + alive + '/' + KamiGramBuiltinProxy.count();
        } catch (Throwable throwable) {
            return "SakuProxy";
        }
    }

    public static int stateColor() {
        try {
            final SharedConfig.ProxyInfo current = SharedConfig.currentProxy;
            if (!enabled() || current == null) {
                return 0xFF8E8E93;
            }
            if (current.checking) {
                return 0xFFFF9F0A;
            }
            if (current.available && current.ping > 0) {
                return 0xFF30D158;
            }
            return 0xFFFF453A;
        } catch (Throwable throwable) {
            return 0xFF8E8E93;
        }
    }

    public static int proxyCount() {
        try {
            return SharedConfig.proxyList == null ? 0 : SharedConfig.proxyList.size();
        } catch (Throwable throwable) {
            return 0;
        }
    }

    public static boolean directMode() {
        /* r76 never disables SakuProxy merely because all probes are pending. */
        return false;
    }

    @Override
    public void didReceivedNotification(int id, int account, Object... args) {
        try {
            if (id != NotificationCenter.proxySettingsChanged
                && (id == NotificationCenter.didUpdateConnectionState
                    || id == NotificationCenter.proxyCheckDone
                    || id == NotificationCenter.fileLoadFailed
                    || id == NotificationCenter.httpFileDidFailedLoad)
                && !downloadsActive()) {
                cancelSwitch();
                return; /* KAMIGRAM_PROXY_WATCH_ACTIVE_ONLY_R83 */
            }
            if (id == NotificationCenter.didUpdateConnectionState) {
                if (account != UserConfig.selectedAccount || !enabled() || !smartEnabled()) {
                    return;
                }
                /* KAMIGRAM_PROXY_SEND_GUARD_R78: a transient Connecting state
                   belongs to the message retry path; keep the current route
                   stable until Telegram finishes that request. */
                if (messageSendInFlight()) {
                    cancelSwitch();
                    return;
                }
                final int state = ConnectionsManager.getInstance(account).getConnectionState();
                if (state == ConnectionsManager.ConnectionStateConnected
                    || state == ConnectionsManager.ConnectionStateUpdating) {
                    lastConnectionHealthy = true; /* KAMIGRAM_CONNECTION_HEALTHY_R77 */
                    cancelSwitch();
                    lastSwitchTime = 0;
                } else if (state == ConnectionsManager.ConnectionStateWaitingForNetwork) {
                    /* There is no useful fallback while Android reports that the
                       device itself is offline; the overlay must remain visible. */
                    lastConnectionHealthy = false;
                    cancelSwitch();
                } else if (state == ConnectionsManager.ConnectionStateConnectingToProxy
                    || state == ConnectionsManager.ConnectionStateConnecting) {
                    /* The old live route is no longer usable as soon as Telegram
                       leaves Connected/Updating. Mark it dead before selecting the
                       fastest already-live SakuProxy, rather than waiting for a
                       several-second probe timeout. */
                    if (lastConnectionHealthy) {
                        final SharedConfig.ProxyInfo current = SharedConfig.currentProxy;
                        if (current != null && current.settings != null) {
                            current.available = false;
                            current.ping = 0;
                            current.availableCheckTime = SystemClock.elapsedRealtime();
                        }
                    }
                    lastConnectionHealthy = false;
                    scheduleSwitch(state == ConnectionsManager.ConnectionStateConnectingToProxy
                        ? SWITCH_DELAY : DEAD_DELAY);
                }
            } else if (id == NotificationCenter.proxyCheckDone) {
                if (!enabled() || !smartEnabled()) {
                    return;
                }
                final SharedConfig.ProxyInfo checked = args != null && args.length > 0 && args[0] instanceof SharedConfig.ProxyInfo
                    ? (SharedConfig.ProxyInfo) args[0] : null;
                if (checked == null) {
                    return;
                }
                final SharedConfig.ProxyInfo current = SharedConfig.currentProxy;
                if (!checked.available && checked == current) {
                    switchToBest(null);
                } else if (checked.available && (current == null
                    || (current.availableCheckTime != 0 && !current.available))) {
                    /* A successful built-in probe is enough to replace a
                       completed dead probe, including a dead built-in that was
                       selected as the initial optimistic candidate. */
                    switchToBest(null);
                }
            } else if (id == NotificationCenter.fileLoadFailed || id == NotificationCenter.httpFileDidFailedLoad) {
                if (account == UserConfig.selectedAccount && enabled() && smartEnabled()) {
                    onLoadFailure();
                }
            } else if (id == NotificationCenter.proxySettingsChanged) {
                cancelSwitch();
            }
        } catch (Throwable throwable) {
            KamiGramLog.e(throwable);
        }
    }

    public static void refreshNow(Context context) {
        if (!downloadsActive() || !enabled() || !smartEnabled()) {
            return;
        }
        KamiGramBuiltinProxy.ensureBuiltinsLoaded();
        pingAll();
        INSTANCE.switchToBest(context);
        KamiGramBuiltinProxy.route(context, true);
    }

    /**
     * KAMIGRAM_THERMAL_LIMIT_R83: retain six native FileLoader operations on a
     * normal device, but let Android power/thermal policy lower concurrency
     * without deleting temp/parts or changing resume offsets.
     */
    public static int downloadParallelLimit(int normal) {
        int limit = Math.min(6, Math.max(1, normal));
        try {
            final Context context = contextOrNull();
            if (context == null) {
                return limit;
            }
            final PowerManager power = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (power != null && power.isPowerSaveMode()) {
                return Math.min(limit, 2);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && power != null) {
                final int thermal = power.getCurrentThermalStatus();
                if (thermal >= PowerManager.THERMAL_STATUS_SEVERE) {
                    return Math.min(limit, 2);
                } else if (thermal >= PowerManager.THERMAL_STATUS_MODERATE) {
                    return Math.min(limit, 4);
                }
            }
        } catch (Throwable ignore) {
        }
        return limit;
    }

    /**
     * A title overlay may disappear only after Telegram confirms a usable
     * connection. ApplicationLoader.isNetworkOnline() is not sufficient: it is
     * also true while a proxy is negotiating or has just failed.
     */
    public static boolean connectionHealthy() { /* KAMIGRAM_CONNECTION_HEALTHY_R77 */
        try {
            final int state = ConnectionsManager.getInstance(UserConfig.selectedAccount).getConnectionState();
            return state == ConnectionsManager.ConnectionStateConnected
                || state == ConnectionsManager.ConnectionStateUpdating;
        } catch (Throwable ignore) {
            return false;
        }
    }

    public static boolean networkOnline() {
        try {
            return ApplicationLoader.isNetworkOnline();
        } catch (Throwable throwable) {
            return true;
        }
    }
}
