package org.telegram.messenger.kamigram;

/** Stock Telegram themes only; legacy no-op compatibility shim. */
public final class KamiGramTheme {
    private KamiGramTheme() { }
    public static void apply() { }
}
