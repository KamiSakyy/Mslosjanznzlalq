package org.telegram.messenger.kamigram;

/**
 * Номер сборки Sakura. Пишется автоматически при сборке и виден в настройках
 * (строка Sakura) — по нему сразу понятно, какая версия стоит на телефоне.
 */
public final class KamiGramBuild {

    /** Номер сборки, подставляется сборщиком (например, "r64"). */
    public static final String NUMBER = "r120";

    private KamiGramBuild() {
    }

    /** Короткая подпись версии (r106: фиксированная, без технического номера). */
    public static String label() {
        return "сборка k1";
    }
}
