package org.telegram.messenger.kamigram;

import org.telegram.messenger.ApplicationLoader;
import org.telegram.messenger.FileLog;
import org.telegram.ui.ActionBar.Theme;

/**
 * KamiGram: iOS-цвета кодом (генерируется пакетом улучшений).
 * Тема задаёт общий вид, а эти ключи Telegram берёт из своих значений,
 * поэтому они переопределяются прямо в коде - как в iOS.
 */
public final class KamiGramTheme {

    private KamiGramTheme() {
    }

    /** Применяет iOS-цвета (только при включённом iOS-дизайне). */
    public static void apply() {
        try {
            set(Theme.key_actionBarDefaultSelector, 0x22FFFFFF);
            set(Theme.key_switch2Track, 0xFF39393D);
            set(Theme.key_switchTrackBlueSelector, 0xFF48484A);
            set(Theme.key_switchTrackBlue, 0xFF39393D);
            set(Theme.key_voipgroup_mutedIcon, 0xFFFF453A);
            set(Theme.key_player_progress, 0xFF0A84FF);
            set(Theme.key_player_buttonActive, 0xFF0A84FF);
            set(Theme.key_profile_creatorIcon, 0xFF0A84FF);
            set(Theme.key_featuredStickers_addedIcon, 0xFF0A84FF);
            set(Theme.key_featuredStickers_addButton, 0xFF0A84FF);
            set(Theme.key_chat_recordedVoiceDot, 0xFFFF453A);
            set(Theme.key_chat_recordTime, 0xFFFF453A);
            set(Theme.key_chat_messagePanelVoicePressed, 0xFFFF453A);
            if (!KamiGramConfig.iosDesign()) {
                return;
            }
            set(Theme.key_chats_unreadCounter, 0xFFFF453A);
            set(Theme.key_chats_unreadCounterMuted, 0xFF8E8E93);
            set(Theme.key_chats_unreadCounterText, 0xFFFFFFFF);
            set(Theme.key_chats_onlineCircle, 0xFF30D158);
            set(Theme.key_chats_secretIcon, 0xFF30D158);
            set(Theme.key_switchTrackChecked, 0xFF34C759);
            set(Theme.key_checkbox, 0xFF0A84FF);
            set(Theme.key_fastScrollActive, 0xFF0A84FF);
            set(Theme.key_progressCircle, 0xFF0A84FF);
            set(Theme.key_chat_messageLinkIn, 0xFF0A84FF);
            set(Theme.key_chat_messageLinkOut, 0xFFA8D4FF);
            set(Theme.key_chat_replyPanelName, 0xFF0A84FF);
            set(Theme.key_profile_actionIcon, 0xFF0A84FF);
            set(Theme.key_avatar_backgroundActionBarBlue, 0xFF0A84FF);
            set(Theme.key_chat_inLoader, 0xFF0A84FF);
            set(Theme.key_chat_outLoader, 0xFF0A84FF);
            set(Theme.key_chat_messagePanelSend, 0xFF0A84FF);
            set(Theme.key_chat_recordedVoiceProgress, 0xFF0A84FF);
            set(Theme.key_chats_actionBackground, 0xFF0A84FF);
            set(Theme.key_actionBarDefaultIcon, 0xFFFFFFFF);
            set(Theme.key_chat_attachIcon, 0xFF8E8E93);
            set(Theme.key_chat_messagePanelIcons, 0xFF8E8E93);
            set(Theme.key_chat_fieldOverlayText, 0xFFFFFFFF);
            if (ApplicationLoader.applicationContext != null) {
                Theme.createDialogsResources(ApplicationLoader.applicationContext);
            }
        } catch (Throwable e) {
            FileLog.e(e);
        }
    }

    private static void set(int key, int color) {
        try {
            Theme.setColor(key, color, false);
        } catch (Throwable ignore) {
        }
    }
}
