package org.telegram.messenger.kamigram;

import org.telegram.messenger.ApplicationLoader;
import org.telegram.messenger.FileLog;
import org.telegram.ui.ActionBar.Theme;

/**
 * KamiGram: iOS-цвета кодом (генерируется пакетом улучшений).
 * Тема задаёт общий вид, а эти ключи Telegram берёт из своих значений,
 * поэтому они переопределяются прямо в коде - как в iOS.
 */
public final class KamiGramTheme {

    private KamiGramTheme() {
    }

    /** Применяет iOS-цвета (только при включённом iOS-дизайне). */
    public static void apply() {
        try {
            set(Theme.key_voipgroup_mutedIcon, 0xFFFF453A);
            set(Theme.key_player_progress, 0xFF5E5CE6);
            set(Theme.key_player_buttonActive, 0xFF5E5CE6);
            set(Theme.key_profile_creatorIcon, 0xFF5E5CE6);
            set(Theme.key_featuredStickers_addedIcon, 0xFF5E5CE6);
            set(Theme.key_featuredStickers_addButton, 0xFF5E5CE6);
            set(Theme.key_actionBarDefaultSelector, 0x22FFFFFF);
            set(Theme.key_switch2Track, 0xFF39393D);
            set(Theme.key_switchTrackBlueSelector, 0xFF48484A);
            set(Theme.key_switchTrackBlue, 0xFF39393D);
            set(Theme.key_graySectionText, 0xFF8E8E93);
            set(Theme.key_graySection, 0xFF2C2C2E);
            set(Theme.key_chat_topPanelLine, 0xFF3A3A3C);
            set(Theme.key_chat_messagePanelVoicePressed, 0xFF5E5CE6);
            if (!KamiGramConfig.iosDesign()) {
                return;
            }
            set(Theme.key_chats_unreadCounter, 0xFFFF453A);
            set(Theme.key_chats_unreadCounterMuted, 0xFF8E8E93);
            set(Theme.key_chats_unreadCounterText, 0xFFFFFFFF);
            set(Theme.key_chats_onlineCircle, 0xFF30D158);
            set(Theme.key_chats_name, 0xFF000000);
            set(Theme.key_chats_message, 0xFF8E8E93);
            set(Theme.key_chats_date, 0xFF8E8E93);
            set(Theme.key_chats_nameMessage, 0xFF8E8E93);
            set(Theme.key_chats_pinnedIcon, 0xFF8E8E93);
            set(Theme.key_chats_muteIcon, 0xFF8E8E93);
            set(Theme.key_chats_secretIcon, 0xFF30D158);
            set(Theme.key_divider, 0xFF38383A);
            set(Theme.key_chat_serviceBackground, 0xFF262628);
            set(Theme.key_chat_selectedBackground, 0xFF1C1C1E);
            set(Theme.key_chat_messagePanelBackground, 0xFF1C1C1E);
            set(Theme.key_switchTrackChecked, 0xFF30D158);
            set(Theme.key_checkbox, 0xFF5E5CE6);
            set(Theme.key_fastScrollActive, 0xFF5E5CE6);
            set(Theme.key_progressCircle, 0xFF5E5CE6);
            set(Theme.key_chat_inBubble, 0xFF1C1C1E);
            set(Theme.key_chat_outBubble, 0xFF3A3A3C);
            set(Theme.key_chat_wallpaper, 0xFF000000);
            set(Theme.key_chat_messageLinkIn, 0xFF5E5CE6);
            set(Theme.key_chat_messageLinkOut, 0xFFFFFFFF);
            set(Theme.key_chat_serviceBackgroundSelected, 0xFF2C2C2E);
            set(Theme.key_chat_replyPanelName, 0xFF5E5CE6);
            set(Theme.key_profile_actionIcon, 0xFF5E5CE6);
            set(Theme.key_player_background, 0xFF1C1C1E);
            set(Theme.key_chat_status, 0xFF8E8E93);
            set(Theme.key_chat_topPanelBackground, 0xFF1C1C1E);
            set(Theme.key_avatar_backgroundActionBarBlue, 0xFF5E5CE6);
            set(Theme.key_chat_inBubbleSelected, 0xFF2C2C2E);
            set(Theme.key_chat_outBubbleSelected, 0xFF48484A);
            set(Theme.key_chat_inLoader, 0xFF5E5CE6);
            set(Theme.key_chat_outLoader, 0xFF5E5CE6);
            set(Theme.key_chat_attachIcon, 0xFF5E5CE6);
            set(Theme.key_chat_messagePanelIcons, 0xFF5E5CE6);
            set(Theme.key_chat_messagePanelSend, 0xFF5E5CE6);
            set(Theme.key_chat_recordedVoiceProgress, 0xFF5E5CE6);
            set(Theme.key_chat_recordedVoiceBackground, 0xFF5E5CE6);
            set(Theme.key_chat_fieldOverlayText, 0xFF8E8E93);
            set(Theme.key_actionBarDefaultIcon, 0xFF5E5CE6);
            set(Theme.key_chats_actionBackground, 0xFF5E5CE6);
            set(Theme.key_windowBackgroundGray, 0xFF1C1C1E);
            set(Theme.key_windowBackgroundWhite, 0xFF000000);
            if (ApplicationLoader.applicationContext != null) {
                Theme.createDialogsResources(ApplicationLoader.applicationContext);
            }
        } catch (Throwable e) {
            FileLog.e(e);
        }
    }

    private static void set(int key, int color) {
        try {
            Theme.setColor(key, color, false);
        } catch (Throwable ignore) {
        }
    }
}
