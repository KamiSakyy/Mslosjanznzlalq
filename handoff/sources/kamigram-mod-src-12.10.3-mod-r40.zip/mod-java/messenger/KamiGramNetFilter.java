package org.telegram.messenger.kamigram;

import org.telegram.messenger.FileLog;
import org.telegram.tgnet.TLObject;
import org.telegram.tgnet.TLRPC;
import org.telegram.tgnet.tl.TL_stories;

/**
 * KamiGram: фильтр «нулевого трафика».
 *
 * Всё, что жрёт интернет впустую, отсекается ДО выхода в сеть - в одном месте:
 *   - стикеры, наборы эмодзи и премиум-эмодзи (запросы и сами файлы .tgs/.webm);
 *   - истории: списки, просмотры и медиа;
 *   - реклама: спонсорские сообщения, промо, Telegram Premium, Stars, бусты;
 *   - рекомендации, «часто используемые», превью ссылок, телефонная книга;
 *   - в режиме «призрак» - подтверждения прочтения, «печатает» и статус «в сети».
 *
 * ВАЖНО про имена: в исходниках Telegram часть запросов объявлена как
 * `TL_messages_getWebPage`, а часть - просто `getWebPage` внутри класса `TL_messages`.
 * Поэтому имя собирается из класса-владельца и простого имени, и проверяются оба варианта.
 */
public final class KamiGramNetFilter {

    /** Запросы, которые в режиме «призрак» не должны уходить на сервер вообще. */
    private static final String[] GHOST = {
        "TL_messages_readHistory",
        "TL_channels_readHistory",
        "TL_messages_readEncryptedHistory",
        "TL_messages_readMessageContents",
        "TL_messages_readMentions",
        "TL_messages_setTyping",
        "TL_account_updateStatus",
        "TL_stories_readStories",
        "TL_stories_incrementStoryViews"
    };

    /** Реклама, спонсорские сообщения и рекомендации - моду не нужны. */
    private static final String[] ADS = {
        "TL_messages_getSponsoredMessages",
        "TL_channels_getSponsoredMessages",
        "TL_channels_getChannelRecommendations",
        "TL_messages_getSuggestedDialogFilters",
        "TL_help_getPromoData",
        "TL_help_getPremiumPromo",
        "TL_contacts_getSponsoredPeers"
    };

    /** «Часто используемые» контакты и топ-пиры: лишний трафик и лишние данные о нас. */
    private static final String[] TOP_PEERS = {
        "TL_contacts_getTopPeers",
        "TL_contacts_toggleTopPeers",
        "TL_contacts_resetTopPeerRating",
        "TL_contacts_search"
    };

    /** Поиск GIF, стикеров и инлайн-ботов при вводе текста. */
    private static final String[] GIF_SEARCH = {
        "TL_messages_searchGifs",
        "TL_messages_searchStickers",
        "TL_messages_getInlineBotResults"
    };

    /** Превью ссылок и веб-страницы: мегабайты картинок на каждую ссылку. */
    private static final String[] LINK_PREVIEW = {
        "TL_messages_getWebPage",
        "TL_messages_getWebPagePreview",
        "TL_messages_getExtendedMedia",
        "TL_messages_getFactCheck"
    };

    /**
     * Чисто «телеграмовский» трафик, который моду не нужен: реклама Premium/Stars,
     * бусты, наборы GIF и музыки. Ничего полезного в этих запросах нет.
     */
    private static final String[] TRASH = {
        "TL_help_getPremiumPromo",
        "TL_help_getPromoData",
        "TL_messages_getEmojiGameInfo",
        "TL_messages_getSavedGifs",
        "TL_messages_getSavedReactionTags",
        "TL_premium_getBoostsStatus",
        "TL_premium_getBoostsList",
        "TL_premium_getMyBoosts",
        "TL_payments_getStarsStatus",
        "TL_payments_getStarsTransactions"
    };

    /** Исходящие действия пользователя по историям - их не блокируем даже при запрете историй. */
    private static final String[] STORY_ACTIONS = {
        "TL_stories_sendStory",
        "TL_stories_deleteStories",
        "TL_stories_editStory",
        "TL_stories_sendReaction",
        "TL_stories_report",
        "TL_stories_activateStealthMode",
        "TL_stories_togglePeerStoriesHidden",
        "TL_stories_exportStoryLink"
    };

    // /* KAMIGRAM_BLOCK_LIST */: запросы, которые НЕ уходят на сервер.
    private static final String[] KAMIGRAM_BLOCK = {
        "TL_users_suggestBirthday",
        "TL_stars_toggleStarGiftsPinnedToTop",
        "TL_stars_reorderStarGiftCollections",
        "TL_stars_getUniqueStarGiftValueInfo",
        "TL_stars_getResaleStarGifts",
        "TL_stars_getStarGiftUpgradePreview",
        "TL_stars_getStarGiftCollections",
        "TL_stars_getSavedStarGift",
        "TL_stars_getStarGifts",
        "TL_premium_applyBoost",
        "TL_payments_clearSavedInfo",
        "TL_payments_getSuggestedStarRefBots",
        "TL_payments_getConnectedStarRefBot",
        "TL_payments_getConnectedStarRefBots",
        "TL_stats_getStoryStats",
        "TL_stories_searchPosts",
        "TL_stories_getStoryViewsList",
        "TL_stories_getStoriesViews",
        "TL_stories_getStoriesByID",
        "TL_stories_getStoriesArchive",
        "TL_stories_getPinnedStories",
        "TL_stories_getAllStories",
        "TL_stickers_checkShortName",
        "TL_messages_clickSponsoredMessage",
        "TL_messages_viewSponsoredMessage",
        "TL_messages_toggleBotInAttachMenu",
        "TL_messages_saveGif",
        "TL_messages_getPaidReactionPrivacy",
        "TL_messages_getDefaultTagReactions",
        "TL_messages_getTopReactions",
        "TL_messages_getEmojiKeywords",
        "TL_messages_uninstallStickerSet",
        "TL_messages_toggleStickerSets",
        "TL_messages_reorderStickerSets",
        "TL_langpack_getDifference",
        "TL_help_dismissSuggestion",
        "TL_contacts_getStatuses",
        "TL_channels_setEmojiStickers",
        "TL_channels_updateEmojiStatus",
        "TL_channels_setBoostsToUnblockRestrictions",
        "TL_bots_toggleUserEmojiStatusPermission",
        "TL_bots_getBotRecommendations",
        "TL_account_webPagePreview",
        "TL_account_toggleSponsoredMessages",
        "TL_account_setReactionsNotifySettings",
        "TL_account_getReactionsNotifySettings",
        "TL_account_updateBirthday",
        "TL_account_getBirthdays",
        "TL_account_getSavedRingtones",
        "TL_account_getSavedMusicByID",
        "TL_account_getSavedMusicIds",
        "TL_account_clearRecentEmojiStatuses",
        "TL_account_updateEmojiStatus",
        "TL_account_getDefaultProfilePhotoEmojis",
        "TL_account_getDefaultGroupPhotoEmojis",
        "TL_account_getDefaultBackgroundEmojis",
        "TL_account_getChannelRestrictedStatusEmojis",
        "TL_account_getChannelDefaultEmojiStatuses",
        "TL_account_getRecentEmojiStatuses",
        "TL_account_getDefaultEmojiStatuses",
        "TL_account_updateTheme",
        "TL_account_resetWallPapers",
        "TL_account_saveWallPaper",
        "TL_account_installWallPaper",
        "TL_account_saveTheme",
        "TL_account_installTheme",
        "TL_account_createTheme",
        "TL_account_getTheme",
        "TL_account_getThemes",
        "TL_account_getWallPaper",
        "TL_account_getMultiWallPapers",
        "TL_account_getWallPapers",
        "TL_help_getTermsOfServiceUpdate",
        "TL_help_getAppUpdate",
        "TL_messages_getSponsoredMessages",
        "TL_channels_getChannelRecommendations",
        "TL_contacts_getSponsoredPeers",
        "TL_help_getPremiumPromo",
        "TL_help_getPromoData",
        "TL_premium_getBoostsStatus",
        "TL_premium_getBoostsList",
        "TL_premium_getMyBoosts",
        "TL_payments_getStarsStatus",
        "TL_payments_getStarsTransactions",
        "TL_payments_getStarsTopupOptions",
        "TL_payments_getStarsGiftOptions",
        "TL_payments_getStarsGiveawayOptions",
        "TL_payments_getStarsRevenueStats",
        "TL_payments_getStarsRevenueWithdrawalUrl",
        "TL_payments_getStarsRevenueAdsAccountUrl",
        "TL_payments_getGiveawayInfo",
        "TL_payments_getPremiumGiftCodeOptions",
        "TL_payments_getSavedInfo",
        "TL_messages_getAllStickers",
        "TL_messages_getArchivedStickers",
        "TL_messages_getAttachedStickers",
        "TL_messages_getFavedStickers",
        "TL_messages_getFeaturedStickers",
        "TL_messages_getMaskStickers",
        "TL_messages_getMyStickers",
        "TL_messages_getOldFeaturedStickers",
        "TL_messages_getRecentStickers",
        "TL_messages_getStickerSet",
        "TL_messages_getStickers",
        "TL_messages_searchStickerSets",
        "TL_messages_searchStickers",
        "TL_messages_readFeaturedStickers",
        "TL_messages_saveRecentSticker",
        "TL_messages_faveSticker",
        "TL_messages_getEmojiStickers",
        "TL_messages_getFeaturedEmojiStickers",
        "TL_messages_getEmojiStickerGroups",
        "TL_messages_getEmojiStatusGroups",
        "TL_messages_getEmojiProfilePhotoGroups",
        "TL_messages_getEmojiGroups",
        "TL_messages_getEmojiURL",
        "TL_messages_getCustomEmojiDocuments",
        "TL_messages_searchCustomEmoji",
        "TL_messages_searchEmojiStickerSets",
        "TL_messages_getEmojiGameInfo",
        "TL_messages_getRecentReactions",
        "TL_contacts_importContacts",
        "TL_contacts_getTopPeers",
        "TL_contacts_toggleTopPeers",
        "TL_contacts_resetTopPeerRating",
        "TL_messages_getSavedGifs",
        "TL_messages_getSavedReactionTags",
        "TL_messages_getWebPage",
        "TL_messages_getExtendedMedia",
        "TL_messages_getAttachMenuBot",
        "TL_messages_getAttachMenuBots",
        "TL_messages_getSuggestedDialogFilters",
        "TL_channels_getAdminLog",
        "TL_channels_getAdminedPublicChannels",
        "TL_channels_readMessageContents",
        "TL_stories_getAllReadPeerStories",
        "TL_stories_getAlbumStories",
        "TL_stories_getPeerMaxIDs",
        "TL_help_getInviteText",
        "TL_help_getPassportConfig",
        "TL_help_getSupport",
        "TL_help_getSupportName",
        "TL_messages_getCommonChats",
        "TL_messages_getDefaultHistoryTTL",
        "TL_messages_getDialogUnreadMarks",
        "TL_messages_getUnreadPollVotes",
        "TL_messages_getInlineBotResults",
        "TL_chatlists_getLeaveChatlistSuggestions",
        "TL_help_getTimezonesList",
        "TL_messages_getEmojiKeywordsLanguages",
        "TL_messages_getEmojiKeywordsDifference",
        "TL_messages_getSearchCounters",
        "TL_help_hidePromoData"
    };

    /** Список блокировки: сравниваем простое и полное имя запроса. */
    private static boolean kamigramBlocked(String[] names) {
        if (names == null) {
            return false;
        }
        for (int a = 0; a < KAMIGRAM_BLOCK.length; a++) {
            if (KAMIGRAM_BLOCK[a].equals(names[0]) || KAMIGRAM_BLOCK[a].equals(names[1])) {
                return true;
            }
        }
        return false;
    }

    private KamiGramNetFilter() {
    }

    public static boolean blockRequest(TLObject object) {
        if (object == null) {
            return false;
        }
        try {
            final String[] names = requestNames(object);
            if (kamigramBlocked(names)) {
                return true;
            }
            if (names == null) {
                return false;
            }
            final String simple = names[0];
            final String full = names[1];
            if (KamiGramConfig.ghostMode() && (hit(GHOST, simple) || hit(GHOST, full))) {
                return true;
            }
            if (KamiGramConfig.noStickers() && isStickerRequest(full, simple)) {
                return true;
            }
            if (KamiGramConfig.noStories() && isStoryRequest(full, simple)) {
                return true;
            }
            if (KamiGramConfig.noAds() && (hit(ADS, simple) || hit(ADS, full))) {
                return true;
            }
            if (KamiGramConfig.noTopPeers() && (hit(TOP_PEERS, simple) || hit(TOP_PEERS, full))) {
                return true;
            }
            if (KamiGramConfig.noGifSearch() && (hit(GIF_SEARCH, simple) || hit(GIF_SEARCH, full))) {
                return true;
            }
            if (KamiGramConfig.noLinkPreview() && (hit(LINK_PREVIEW, simple) || hit(LINK_PREVIEW, full))) {
                return true;
            }
            return hit(TRASH, simple) || hit(TRASH, full);
        } catch (Throwable e) {
            FileLog.e(e);
        }
        return false;
    }

    /**
     * Файлы стикеров и премиум-эмодзи (.tgs / .webm / .webp) и медиа историй
     * не скачиваются: экономия трафика и батареи.
     */
    public static boolean blockDownload(TLRPC.Document document, Object parentObject) {
        try {
            if (KamiGramConfig.noStories() && parentObject instanceof TL_stories.StoryItem) {
                return true;
            }
            if (KamiGramConfig.noStickers() && isStickerDocument(document)) {
                return true;
            }
        } catch (Throwable e) {
            FileLog.e(e);
        }
        return false;
    }

    /** [простое имя, имя с пространством: TL_messages_getWebPage]. */
    private static String[] requestNames(TLObject object) {
        final Class<?> cls = object.getClass();
        final String simple = cls.getSimpleName();
        if (simple == null || simple.length() == 0) {
            return null;
        }
        if (simple.indexOf('_') > 0) {
            // уже с пространством имён: TL_messages_getWebPage
            return new String[] {simple, simple};
        }
        final Class<?> enclosing = cls.getEnclosingClass();
        final String full = enclosing == null ? simple : enclosing.getSimpleName() + "_" + simple;
        return new String[] {simple, full};
    }

    private static boolean hit(String[] list, String name) {
        for (int a = 0; a < list.length; a++) {
            if (list[a].equals(name)) {
                return true;
            }
        }
        return false;
    }

    /** Запросы про стикеры, наборы эмодзи и премиум-эмодзи. */
    private static boolean isStickerRequest(String full, String simple) {
        if (!full.startsWith("TL_messages_") && !simple.startsWith("TL_messages_")) {
            return false;
        }
        final String rest = full.startsWith("TL_messages_") ? full.substring("TL_messages_".length()) : simple;
        if (rest.contains("EmojiKeywords")) {
            // подсказки клавиатуры эмодзи оставляем: они крошечные и нужны для поиска
            return false;
        }
        return rest.contains("Sticker") || rest.contains("Emoji");
    }

    /** Запросы про истории (все, кроме исходящих действий самого пользователя). */
    private static boolean isStoryRequest(String full, String simple) {
        if (!full.startsWith("TL_stories_") && !simple.startsWith("TL_stories_")) {
            return false;
        }
        return !(hit(STORY_ACTIONS, full) || hit(STORY_ACTIONS, simple));
    }

    /** Документ - стикер или премиум-эмодзи. */
    private static boolean isStickerDocument(TLRPC.Document document) {
        if (document == null) {
            return false;
        }
        if ("application/x-tgsticker".equals(document.mime_type)) {
            return true;
        }
        if (document.attributes != null) {
            for (int a = 0; a < document.attributes.size(); a++) {
                final TLRPC.DocumentAttribute attribute = document.attributes.get(a);
                if (attribute instanceof TLRPC.TL_documentAttributeSticker
                    || attribute instanceof TLRPC.TL_documentAttributeCustomEmoji) {
                    return true;
                }
            }
        }
        return false;
    }
}
