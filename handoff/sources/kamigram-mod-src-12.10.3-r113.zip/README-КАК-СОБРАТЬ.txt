Sakura - исходники мода (версия 12.10.3, сборка r113)
=================================================

Что внутри:
  mod/        - патчер apply-mod.sh и все Java-классы Sakura
  mod-java/   - классы мода уже в применённом виде (как в APK)
  reports/    - отчёты по улучшениям и diff против исходников Telegram

Как собрать:
  1. git clone --depth 1 https://github.com/DrKLO/Telegram.git
  2. TG_DIR=<куда склонировали> APP_NAME=Sakura APP_PACKAGE=com.kami.gram \
       bash mod/apply-mod.sh
  3. cd <TG_DIR> && ./gradlew :TMessagesProj_App:assembleAfatRelease

Подпись: оригинальный ключ Telegram (android / androidkey).
Файлов в архиве: 180
