// Живые новости аниме-индустрии. Проверенные источники (без ключей):
//  • MyAnimeList RSS   — новости индустрии
//  • LiveChart.me      — выходящие серии (по времени показа в регионе)
//  • Otaku USA         — журнальные новости и фичи
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 LumiChat/2.0";

export interface NewsItem {
  title: string;
  link: string;
  source: string;
  publishedAt: string;
  snippet: string;
  image: string | null;
}

let cache: { at: number; items: NewsItem[] } | null = null;

function decodeEntities(s: string) {
  return s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;|&#39;|&rsquo;/g, "'")
    .replace(/&#x2F;/g, "/")
    .replace(/&#(\d+);/g, (_, d) => String.fromCharCode(Number(d)))
    .replace(/\s+/g, " ")
    .trim();
}

function pick(block: string, tag: string) {
  return block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`))?.[1] || "";
}

function parseRss(xml: string, source: string, limit: number): NewsItem[] {
  const items: NewsItem[] = [];
  const re = /<item>([\s\S]*?)<\/item>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml)) && items.length < limit) {
    const b = m[1];
    const title = decodeEntities(pick(b, "title")).trim();
    let link = decodeEntities(pick(b, "link")).trim();
    const guid = decodeEntities(pick(b, "guid")).trim();
    if (!link && guid.startsWith("http")) link = guid;
    const pubRaw = (pick(b, "pubDate") || pick(b, "dc:date") || pick(b, "date")).trim();
    const pub = pubRaw ? new Date(pubRaw) : null;
    const snippet = decodeEntities(pick(b, "description")).slice(0, 220);
    const imgMatch =
      b.match(/<enclosure[^>]+url="([^"]+)"[^>]*type="image/) ||
      b.match(/url="([^"]+\.(?:jpe?g|png|webp))"/i);
    if (!title || !link) continue;
    items.push({
      title,
      link,
      source,
      publishedAt: pub && !isNaN(+pub) ? pub.toISOString() : new Date().toISOString(),
      snippet,
      image: imgMatch ? imgMatch[1] : null,
    });
  }
  return items;
}

async function fetchRss(url: string, source: string, limit: number): Promise<NewsItem[]> {
  try {
    const res = await fetch(url, { headers: { "User-Agent": UA, Accept: "application/rss+xml,application/xml,text/xml" }, signal: AbortSignal.timeout(10000) });
    if (!res.ok) return [];
    return parseRss(await res.text(), source, limit);
  } catch {
    return [];
  }
}

export async function GET() {
  if (cache && Date.now() - cache.at < 10 * 60 * 1000) {
    return NextResponse.json({ items: cache.items });
  }
  const [mal, livechart, otaku] = await Promise.all([
    fetchRss("https://myanimelist.net/rss/news.xml", "MyAnimeList", 12),
    fetchRss("https://www.livechart.me/feeds/episodes", "Новые серии · LiveChart", 8),
    fetchRss("https://otakuusamagazine.com/feed/", "Otaku USA", 6),
  ]);
  const items = [...mal, ...livechart, ...otaku]
    .filter((i) => i.title && i.link)
    .sort((a, b) => +new Date(b.publishedAt) - +new Date(a.publishedAt))
    .slice(0, 26);
  if (items.length) cache = { at: Date.now(), items };
  return NextResponse.json({ items });
}
