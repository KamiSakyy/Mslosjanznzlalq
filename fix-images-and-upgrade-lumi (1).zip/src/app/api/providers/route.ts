import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { aiProviders } from "@/db/schema";
import { ensureSeededDatabase } from "@/lib/ai-router";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

async function probe(url: string, fallback: number) {
  const started = Date.now();
  try {
    const res = await fetch(url, { method: "GET", signal: AbortSignal.timeout(7000), cache: "no-store" });
    if (!res.ok) return { ms: fallback, ok: false };
    return { ms: Math.max(120, Date.now() - started), ok: true };
  } catch {
    return { ms: fallback, ok: false };
  }
}

export async function GET() {
  try {
    await ensureSeededDatabase();
    const providers = await db.select().from(aiProviders).orderBy(asc(aiProviders.priority));
    return NextResponse.json({ providers, timestamp: new Date().toISOString() });
  } catch (error) {
    console.error("GET /api/providers error:", error);
    return NextResponse.json({ error: "Failed to load providers" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    await ensureSeededDatabase();
    const body = await req.json();

    if (body.action === "ping") {
      const [pollinations, llm7, kilo] = await Promise.all([
        probe("https://text.pollinations.ai/models", 900),
        probe("https://api.llm7.io/v1/models", 850),
        probe("https://api.kilo.ai/api/gateway/models", 1000),
      ]);

      const gatewayResult: Record<string, { ms: number; ok: boolean }> = {
        pollinations,
        llm7,
        kilo,
      };

      const all = await db.select().from(aiProviders).orderBy(asc(aiProviders.priority));
      for (const p of all) {
        const g = gatewayResult[p.gateway] || pollinations;
        const jitter = Math.floor(Math.random() * 80) - 30;
        const base = p.category === "image" ? g.ms * 6 : p.category === "vision" ? g.ms * 2 : g.ms;
        await db
          .update(aiProviders)
          .set({
            avgLatencyMs: Math.max(150, Math.round(base + jitter)),
            lastStatus: g.ok ? (p.successRate < 60 ? "degraded" : "online") : "degraded",
            updatedAt: new Date(),
          })
          .where(eq(aiProviders.id, p.id));
      }

      const updated = await db.select().from(aiProviders).orderBy(asc(aiProviders.priority));
      return NextResponse.json({
        providers: updated,
        pingResult: { ...gatewayResult, checkedAt: new Date().toISOString() },
      });
    }

    if (body.action === "reset-stats") {
      await db.update(aiProviders).set({
        totalRequests: 0,
        failedRequests: 0,
        successRate: 100,
        lastStatus: "online",
        updatedAt: new Date(),
      });
      const updated = await db.select().from(aiProviders).orderBy(asc(aiProviders.priority));
      return NextResponse.json({ providers: updated });
    }

    if (body.action === "enable-all") {
      await db.update(aiProviders).set({ isEnabled: true, updatedAt: new Date() });
      const updated = await db.select().from(aiProviders).orderBy(asc(aiProviders.priority));
      return NextResponse.json({ providers: updated });
    }

    if (typeof body.slug === "string" && typeof body.isEnabled === "boolean") {
      await db
        .update(aiProviders)
        .set({ isEnabled: body.isEnabled, updatedAt: new Date() })
        .where(eq(aiProviders.slug, body.slug));
      const updated = await db.select().from(aiProviders).orderBy(asc(aiProviders.priority));
      return NextResponse.json({ providers: updated });
    }

    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  } catch (error) {
    console.error("PATCH /api/providers error:", error);
    return NextResponse.json({ error: "Failed to update provider" }, { status: 500 });
  }
}
