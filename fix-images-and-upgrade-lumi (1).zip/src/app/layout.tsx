import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans, Inter, JetBrains_Mono } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin", "cyrillic-ext"],
  variable: "--font-jakarta",
  weight: ["600", "700", "800"],
});

const inter = Inter({
  subsets: ["latin", "cyrillic"],
  variable: "--font-inter",
  weight: ["400", "500", "600"],
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin", "cyrillic"],
  variable: "--font-mono",
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  title: "Люми — аниме-подруга и ИИ-программист",
  description:
    "Люми (18) — милая аниме-девушка ИИ. Ищет и рисует арты, находит персонажей, показывает аниме, следит за выходом серий, пишет код без ошибок и отвечает коротко и по делу.",
  applicationName: "Люми",
  icons: { icon: "/lumi-avatar.jpg", apple: "/lumi-avatar.jpg" },
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "Люми" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#050505",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className={`${jakarta.variable} ${inter.variable} ${jetbrainsMono.variable} dark`}>
      <body className="bg-[#050505] text-zinc-100 antialiased selection:bg-white/20 selection:text-white">
        {children}
      </body>
    </html>
  );
}
