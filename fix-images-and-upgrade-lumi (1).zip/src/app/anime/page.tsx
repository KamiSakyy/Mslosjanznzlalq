"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import { Search, Star, Tv, Calendar, Flame, Trophy, Clock, Play, X, Loader2, ArrowLeft, Sparkles, ChevronRight } from "lucide-react";
import { searchAniLibriaClient, getEpisodesClient, type AniLibEpisode } from "@/lib/anilibria-client";

const CustomVideoPlayer = dynamic(() => import("@/components/VideoPlayer").then((m) => m.CustomVideoPlayer), { ssr: false });

interface AnimeCard {
  id: number; russian: string; name: string; image: string; score: number;
  episodes: number; episodesAired: number; status: string; kind: string; airedOn: string | null;
}
interface Details extends AnimeCard { description: string; genres: string[]; studios: string[]; duration: number; nextEpisodeAt: string | null }
interface CalEntry { animeId: number; russian: string; name: string; image: string; nextEpisode: number; nextEpisodeAt: string }

const TABS = [
  { id: "popular", label: "Популярное", icon: Flame },
  { id: "ongoing", label: "Онгоинги", icon: Tv },
  { id: "top", label: "Топ рейтинг", icon: Trophy },
  { id: "calendar", label: "Календарь", icon: Calendar },
] as const;
type Tab = (typeof TABS)[number]["id"];

function statusLabel(s: string) {
  return s === "released" ? "Вышло" : s === "ongoing" ? "Онгоинг" : s === "anons" ? "Анонс" : s;
}

function GridCard({ card, onOpen }: { card: AnimeCard; onOpen: () => void }) {
  return (
    <button onClick={onOpen} className="group text-left w-full">
      <div className="relative aspect-[2/3] rounded-xl overflow-hidden border border-white/[0.06] bg-[#111]">
        {card.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={card.image} alt="" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
        ) : (
          <div className="w-full h-full grid place-items-center text-zinc-700"><Tv className="w-8 h-8" /></div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent" />
        {card.score > 0 && (
          <span className="absolute top-1.5 right-1.5 inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur text-[11px] font-semibold text-amber-300">
            <Star className="w-3 h-3 fill-current" />{card.score}
          </span>
        )}
        <span className="absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded bg-black/60 backdrop-blur text-[9px] font-mono text-zinc-200">{statusLabel(card.status)}</span>
        <div className="absolute inset-0 grid place-items-center opacity-0 group-hover:opacity-100 transition">
          <span className="w-12 h-12 rounded-full bg-fuchsia-500/90 text-white grid place-items-center shadow-lg"><Play className="w-5 h-5 fill-current ml-0.5" /></span>
        </div>
      </div>
      <div className="mt-1.5 text-[12.5px] text-zinc-200 leading-tight line-clamp-2 group-hover:text-white">{card.russian || card.name}</div>
      <div className="text-[10.5px] text-zinc-500">{card.airedOn?.slice(0, 4) || ""}{card.episodes ? ` · ${card.episodes} эп.` : ""}</div>
    </button>
  );
}

// ── Watch view (fullscreen-ish overlay) ─────────────────────────────────────
function WatchView({ card, onClose }: { card: AnimeCard; onClose: () => void }) {
  const [det, setDet] = useState<Details | null>(null);
  const [episodes, setEpisodes] = useState<AniLibEpisode[]>([]);
  const [ep, setEp] = useState<AniLibEpisode | null>(null);
  const [phase, setPhase] = useState<"loading" | "info" | "notfound">("loading");
  const [relName, setRelName] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setPhase("loading");
      // details from server (Shikimori)
      const d = await (await fetch(`/api/anime?action=details&id=${card.id}`)).json().catch(() => ({}));
      if (cancelled) return;
      setDet(d.details || null);
      // video from client (AniLibria — user's browser)
      let releases = await searchAniLibriaClient(card.russian || card.name, 4);
      if (releases.length === 0 && card.name) releases = await searchAniLibriaClient(card.name, 4);
      if (cancelled) return;
      const rel = releases[0];
      if (!rel) { setPhase("notfound"); return; }
      const e = await getEpisodesClient(rel.id);
      if (cancelled) return;
      setRelName(e.release?.name || rel.name || "");
      setEpisodes(e.episodes);
      setEp(e.episodes[0] || null);
      setPhase(e.episodes.length ? "info" : "notfound");
    })();
    return () => { cancelled = true; };
  }, [card]);

  const dl = (raw: string | null, q: string) =>
    raw ? `/api/download?u=${encodeURIComponent(raw)}&name=${encodeURIComponent((card.russian || card.name).slice(0, 40) + "_" + (ep?.ordinal || 1) + "_" + q)}` : undefined;
  const sources = ep
    ? [
        ...(ep.hls1080 ? [{ url: ep.hls1080, label: "1080p", downloadUrl: dl(ep.raw1080, "1080p") }] : []),
        ...(ep.hls720 ? [{ url: ep.hls720, label: "720p", downloadUrl: dl(ep.raw720, "720p") }] : []),
        ...(ep.hls480 ? [{ url: ep.hls480, label: "480p", downloadUrl: dl(ep.raw480, "480p") }] : []),
      ]
    : [];

  return (
    <div className="fixed inset-0 z-50 bg-[#070708] overflow-y-auto">
      <div className="sticky top-0 z-10 h-14 px-4 flex items-center gap-3 bg-[#070708]/90 backdrop-blur border-b border-white/[0.08]">
        <button onClick={onClose} className="w-9 h-9 rounded-lg grid place-items-center text-zinc-400 hover:text-white hover:bg-white/[0.06]"><ArrowLeft className="w-5 h-5" /></button>
        <span className="text-[14px] font-semibold text-zinc-100 truncate">{card.russian || card.name}</span>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-4">
        {phase === "loading" ? (
          <div className="aspect-video rounded-xl bg-[#0e0e10] grid place-items-center"><Loader2 className="w-8 h-8 animate-spin text-zinc-600" /></div>
        ) : phase === "notfound" ? (
          <div className="aspect-video rounded-xl bg-[#0e0e10] grid place-items-center text-center px-6">
            <div>
              <Tv className="w-10 h-10 mx-auto mb-3 text-zinc-600" />
              <p className="text-zinc-300">Видео пока недоступно в AniLibria 😔</p>
              <p className="text-[12px] text-zinc-500 mt-1">Но описание и инфо доступны ниже</p>
            </div>
          </div>
        ) : (
          <>
            {ep && <CustomVideoPlayer key={ep.ordinal} poster={card.image} sources={sources} />}
            {episodes.length > 1 && (
              <div className="mt-3">
                <div className="text-[12px] text-zinc-400 mb-2">Серии · {relName}</div>
                <div className="flex flex-wrap gap-1.5">
                  {episodes.map((e) => (
                    <button key={e.ordinal} onClick={() => setEp(e)}
                      className={`min-w-[38px] h-9 px-2 rounded-lg text-[12px] font-mono transition ${ep?.ordinal === e.ordinal ? "bg-fuchsia-500 text-white" : "bg-white/[0.05] text-zinc-300 hover:bg-white/[0.1]"}`}>
                      {e.ordinal}{e.name ? "" : ""}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* Info */}
        <div className="mt-5 flex gap-4">
          {card.image && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={card.image} alt="" className="w-24 h-36 rounded-xl object-cover border border-white/[0.06] shrink-0" />
          )}
          <div className="min-w-0 flex-1">
            <h1 className="text-[17px] font-bold text-zinc-100 leading-tight">{card.russian || card.name}</h1>
            {card.name && card.name !== card.russian && <p className="text-[12px] text-zinc-500">{card.name}</p>}
            <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px] text-zinc-400">
              {card.score > 0 && <span className="inline-flex items-center gap-1 text-amber-300"><Star className="w-3.5 h-3.5 fill-current" />{card.score}</span>}
              {card.episodes > 0 && <span className="inline-flex items-center gap-1"><Tv className="w-3.5 h-3.5" />{card.episodes} эп.</span>}
              {card.airedOn && <span>{card.airedOn.slice(0, 4)}</span>}
              <span className="px-1.5 py-0.5 rounded bg-white/[0.06] text-[10px]">{statusLabel(card.status)}</span>
            </div>
            {det?.genres && det.genres.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">{det.genres.slice(0, 8).map((g) => <span key={g} className="px-1.5 py-0.5 rounded-md bg-white/[0.05] text-[10px] text-zinc-400">{g}</span>)}</div>
            )}
          </div>
        </div>
        {det?.description && <p className="mt-3 text-[13.5px] leading-relaxed text-zinc-400">{det.description}</p>}
      </div>
    </div>
  );
}

export default function AnimeSite() {
  const [tab, setTab] = useState<Tab>("popular");
  const [cards, setCards] = useState<AnimeCard[]>([]);
  const [calendar, setCalendar] = useState<CalEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [searchMode, setSearchMode] = useState(false);
  const [watch, setWatch] = useState<AnimeCard | null>(null);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  const loadTab = useCallback(async (t: Tab) => {
    setLoading(true);
    try {
      if (t === "calendar") {
        const d = await (await fetch(`/api/anime?action=calendar`)).json();
        setCalendar(d.calendar || []);
      } else {
        const params = t === "popular" ? "order=popularity" : t === "ongoing" ? "order=popularity&status=ongoing" : "order=ranked&kind=tv";
        const d = await (await fetch(`/api/anime?action=browse&${params}`)).json();
        setCards(d.results || []);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { if (!searchMode) loadTab(tab); }, [tab, searchMode, loadTab]);

  const onSearch = (v: string) => {
    setQuery(v);
    if (debounce.current) clearTimeout(debounce.current);
    if (!v.trim()) { setSearchMode(false); return; }
    debounce.current = setTimeout(async () => {
      setSearchMode(true);
      setLoading(true);
      const d = await (await fetch(`/api/anime?action=search&q=${encodeURIComponent(v)}`)).json();
      setCards(d.results || []);
      setLoading(false);
    }, 350);
  };

  const hero = cards[0];

  return (
    <div className="min-h-[100dvh] bg-[#070708] text-zinc-100">
      <header className="sticky top-0 z-30 bg-[#070708]/90 backdrop-blur-lg border-b border-white/[0.08]">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center gap-3">
          <Link href="/" className="w-9 h-9 rounded-lg grid place-items-center text-zinc-400 hover:text-white hover:bg-white/[0.06]" title="В чат с Айей"><ArrowLeft className="w-5 h-5" /></Link>
          <div className="flex items-center gap-2 flex-1 min-w-0">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/lumi-avatar.jpg" alt="Люми" className="w-8 h-8 rounded-lg object-cover border border-fuchsia-400/30" />
            <div className="min-w-0">
              <div className="font-[family-name:var(--font-jakarta)] text-[14px] font-bold tracking-tight">Аниме</div>
              <div className="text-[10px] text-zinc-500 -mt-0.5 truncate">каталог · онлайн-просмотр</div>
            </div>
          </div>
          <div className="relative w-40 sm:w-64">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <input value={query} onChange={(e) => onSearch(e.target.value)} placeholder="Поиск…"
              className="w-full h-9 pl-8 pr-2 rounded-lg border border-white/[0.08] bg-[#101012] text-[13px] text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-white/[0.2]" />
          </div>
        </div>
        {!searchMode && (
          <div className="max-w-6xl mx-auto px-4 pb-2 flex gap-1.5 overflow-x-auto no-scrollbar">
            {TABS.map((t) => {
              const Icon = t.icon;
              return (
                <button key={t.id} onClick={() => setTab(t.id)} className={`shrink-0 h-8 px-3 rounded-lg text-[12.5px] font-medium inline-flex items-center gap-1.5 transition ${tab === t.id ? "bg-white text-black" : "bg-white/[0.04] text-zinc-400 hover:text-white"}`}>
                  <Icon className="w-3.5 h-3.5" /> {t.label}
                </button>
              );
            })}
          </div>
        )}
      </header>

      <main className="max-w-6xl mx-auto px-4 py-5">
        {loading ? (
          <div className="min-h-[55vh] grid place-items-center"><Loader2 className="w-7 h-7 animate-spin text-zinc-600" /></div>
        ) : tab === "calendar" && !searchMode ? (
          <div className="space-y-2">
            <h2 className="text-[15px] font-semibold text-zinc-200 mb-1">📅 Календарь выхода серий</h2>
            {calendar.map((c) => {
              const d = new Date(c.nextEpisodeAt);
              const when = d.toLocaleString("ru-RU", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
              return (
                <button key={c.animeId + "-" + c.nextEpisode} onClick={() => setWatch({ id: c.animeId, russian: c.russian, name: c.name, image: c.image, score: 0, episodes: 0, episodesAired: 0, status: "ongoing", kind: "tv", airedOn: null })}
                  className="w-full flex items-center gap-3 rounded-xl border border-white/[0.06] bg-[#0e0e10] p-2 hover:border-white/[0.15] transition text-left">
                  {c.image && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={c.image} alt="" loading="lazy" className="w-12 h-16 rounded-lg object-cover shrink-0" />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="text-[14px] text-zinc-100 truncate">{c.russian || c.name}</div>
                    <div className="text-[12px] text-zinc-500 inline-flex items-center gap-1"><Clock className="w-3 h-3" />Серия {c.nextEpisode} · {when}</div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-600 shrink-0" />
                </button>
              );
            })}
          </div>
        ) : (
          <>
            {/* Hero (only on popular, no search) */}
            {!searchMode && tab === "popular" && hero && (
              <button onClick={() => setWatch(hero)} className="relative w-full h-44 sm:h-56 rounded-2xl overflow-hidden mb-5 group text-left border border-white/[0.06]">
                {hero.image && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={hero.image} alt="" className="absolute inset-0 w-full h-full object-cover object-center opacity-40 group-hover:opacity-50 transition" />
                )}
                <div className="absolute inset-0 bg-gradient-to-r from-[#070708] via-[#070708]/70 to-transparent" />
                <div className="relative h-full flex flex-col justify-end p-5">
                  <span className="text-[11px] font-mono text-fuchsia-300 mb-1">🔥 №1 сейчас</span>
                  <h2 className="text-[22px] sm:text-[26px] font-bold text-white leading-tight max-w-md">{hero.russian || hero.name}</h2>
                  <div className="mt-2 flex items-center gap-3 text-[12px] text-zinc-300">
                    {hero.score > 0 && <span className="inline-flex items-center gap-1 text-amber-300"><Star className="w-3.5 h-3.5 fill-current" />{hero.score}</span>}
                    {hero.episodes > 0 && <span>{hero.episodes} эп.</span>}
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-fuchsia-500 text-white font-semibold"><Play className="w-3.5 h-3.5 fill-current" />Смотреть</span>
                  </div>
                </div>
              </button>
            )}

            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
              {(searchMode || tab !== "popular" ? cards : cards.slice(1)).map((c, i) => (
                <div key={c.id} className="animate-card-in" style={{ animationDelay: `${Math.min(i * 25, 500)}ms` }}>
                  <GridCard card={c} onOpen={() => setWatch(c)} />
                </div>
              ))}
              {cards.length === 0 && <p className="col-span-full text-center text-zinc-500 py-12">Ничего не найдено 🥺</p>}
            </div>
          </>
        )}
      </main>

      {watch && <WatchView card={watch} onClose={() => setWatch(null)} />}
    </div>
  );
}
