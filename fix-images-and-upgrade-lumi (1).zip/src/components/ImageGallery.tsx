"use client";

import React, { useState } from "react";
import { X, ExternalLink, Download, Heart, Loader2 } from "lucide-react";
import { ShareChips } from "@/components/LumiPanel";
import { toggleFav, isFav } from "@/lib/lumi-store";

interface ImgItem { image: string; thumbnail: string; title: string; source: string }

function Tile({ img, onOpen }: { img: ImgItem; onOpen: () => void }) {
  const [loaded, setLoaded] = useState(false);
  const [dead, setDead] = useState(false);
  if (dead) return null;
  return (
    <button onClick={onOpen} className="group relative aspect-square rounded-xl overflow-hidden border border-white/[0.06] bg-[#111]">
      {!loaded && (
        <span className="absolute inset-0 grid place-items-center text-zinc-700">
          <Loader2 className="w-4 h-4 animate-spin" />
        </span>
      )}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={img.thumbnail || img.image}
        alt={img.title}
        loading="lazy"
        onLoad={() => setLoaded(true)}
        onError={() => setDead(true)}
        className={`w-full h-full object-cover group-hover:scale-105 transition duration-300 ${loaded ? "opacity-100" : "opacity-0"}`}
      />
      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition" />
    </button>
  );
}

export function ImageGallery({ images }: { images: ImgItem[] }) {
  const [open, setOpen] = useState<number | null>(null);
  const [favTick, setFavTick] = useState(0); // триггер перерисовки сердечек

  const download = (url: string, title: string) => {
    const name = (title || "image").replace(/[^\w\u0400-\u04FF.-]+/g, "_").slice(0, 40) || "image";
    const a = document.createElement("a");
    a.href = `/api/download?kind=image&u=${encodeURIComponent(url)}&name=${encodeURIComponent(name)}`;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const cur = open !== null ? images[open] : null;
  const curFav = cur ? isFav(cur.image) : false;
  void favTick;

  return (
    <>
      <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-2">
        {images.map((img, i) => (
          <Tile key={img.image + i} img={img} onOpen={() => setOpen(i)} />
        ))}
      </div>

      {cur && (
        <div className="fixed inset-0 z-[60] bg-black/90 backdrop-blur-sm grid place-items-center p-4 animate-fade-in" onClick={() => setOpen(null)}>
          <div className="relative max-w-3xl w-full" onClick={(e) => e.stopPropagation()}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={cur.image} alt={cur.title} className="w-full max-h-[78vh] object-contain rounded-xl" />
            <div className="mt-2 flex items-center gap-2 flex-wrap">
              {cur.title && <span className="text-[12px] text-zinc-400 flex-1 min-w-0 truncate">{cur.title}</span>}
              <button
                onClick={() => { toggleFav(cur); setFavTick((t) => t + 1); }}
                className={`h-8 w-8 rounded-lg grid place-items-center border transition ${curFav ? "border-pink-500/40 bg-pink-500/10 text-pink-400" : "border-white/[0.15] text-zinc-300 hover:text-pink-300"}`}
                title={curFav ? "Убрать из избранного" : "В избранное"}
              >
                <Heart className={`w-3.5 h-3.5 ${curFav ? "fill-current" : ""}`} />
              </button>
              <button onClick={() => download(cur.image, cur.title)} className="h-8 px-3 rounded-lg bg-white text-black text-[12px] font-semibold inline-flex items-center gap-1.5">
                <Download className="w-3.5 h-3.5" />Скачать
              </button>
              {cur.source && (
                <a href={cur.source} target="_blank" rel="noopener noreferrer" className="h-8 px-3 rounded-lg border border-white/[0.15] text-zinc-200 text-[12px] inline-flex items-center gap-1.5">
                  <ExternalLink className="w-3.5 h-3.5" />Источник
                </a>
              )}
              <span className="inline-flex items-center gap-1 h-8 px-1 rounded-lg border border-white/[0.15]">
                <ShareChips url={cur.source || cur.image} text={cur.title || "Арт от Люми"} />
              </span>
              <button onClick={() => setOpen(null)} className="w-8 h-8 rounded-lg border border-white/[0.15] grid place-items-center text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            {images.length > 1 && (
              <div className="mt-2 flex items-center justify-center gap-2 text-[12px] text-zinc-400">
                <button onClick={() => setOpen((open! - 1 + images.length) % images.length)} className="px-2 py-1 rounded hover:bg-white/10">←</button>
                <span>{open! + 1} / {images.length}</span>
                <button onClick={() => setOpen((open! + 1) % images.length)} className="px-2 py-1 rounded hover:bg-white/10">→</button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
