"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import { Play, Pause, Volume2, VolumeX, Maximize, Minimize, Settings, RotateCcw, RotateCw, Loader2, AlertCircle, Download } from "lucide-react";

export interface Source {
  url: string;
  label: string; // "480p" etc.
  downloadUrl?: string; // /api/download?... — real full-episode file download
}

function fmt(t: number) {
  if (!isFinite(t) || t < 0) return "0:00";
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  const h = Math.floor(m / 60);
  return h > 0 ? `${h}:${String(m % 60).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

// Custom HLS/DASH interceptor player. Loads hls.js/dash.js on the client and
// plays .m3u8 / .mpd streams with a full custom control bar.
export function CustomVideoPlayer({ sources, poster, autoPlay = true }: { sources: Source[]; poster?: string; autoPlay?: boolean }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
   
  const engineRef = useRef<any>(null);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const wantPlay = useRef(autoPlay);

  const [qi, setQi] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [cur, setCur] = useState(0);
  const [dur, setDur] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [vol, setVol] = useState(1);
  const [muted, setMuted] = useState(false);
  const [full, setFull] = useState(false);
  const [rate, setRate] = useState(1);
  const [showCtrl, setShowCtrl] = useState(true);
  const [menu, setMenu] = useState<null | "quality" | "speed">(null);

  const src = sources[qi]?.url;

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !src) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    const resumeAt = video.currentTime;

    const destroy = () => {
      if (engineRef.current) {
        try {
          if (typeof engineRef.current.destroy === "function") engineRef.current.destroy();
          else if (typeof engineRef.current.reset === "function") engineRef.current.reset();
        } catch { /* ignore */ }
        engineRef.current = null;
      }
    };
    destroy();

    const lower = src.toLowerCase();
    const isDash = lower.includes(".mpd");
    const isHls = lower.includes(".m3u8") || lower.includes("mpegurl") || lower.includes("/api/stream");

    const afterAttach = () => {
      if (cancelled) return;
      if (resumeAt > 1 && resumeAt < (video.duration || Infinity)) {
        try { video.currentTime = resumeAt; } catch { /* ignore */ }
      }
      if (wantPlay.current) video.play().catch(() => {});
    };

    (async () => {
      try {
        if (isHls && video.canPlayType("application/vnd.apple.mpegurl")) {
          // Safari / iOS native HLS
          video.src = src;
          video.addEventListener("loadedmetadata", afterAttach, { once: true });
        } else if (isHls) {
          const mod = await import("hls.js");
          const Hls = mod.default;
          if (cancelled) return;
          if (Hls.isSupported()) {
            const hls = new Hls({
              enableWorker: true,
              lowLatencyMode: false,
              maxBufferLength: 30,
              manifestLoadingTimeOut: 20000,
              manifestLoadingMaxRetry: 4,
              fragLoadingTimeOut: 30000,
              fragLoadingMaxRetry: 6,
              xhrSetup: (xhr) => { xhr.withCredentials = false; },
            });
            hls.on(Hls.Events.MANIFEST_PARSED, () => {
              setLoading(false);
              afterAttach();
            });
            hls.on(Hls.Events.FRAG_BUFFERED, () => setLoading(false));
            hls.on(Hls.Events.ERROR, (_e: unknown, data: { fatal?: boolean; type?: string }) => {
              if (!data?.fatal) return;
              // Try to recover network/media errors before giving up.
              if (data.type === "networkError") {
                try { hls.startLoad(); return; } catch { /* fall through */ }
              } else if (data.type === "mediaError") {
                try { hls.recoverMediaError(); return; } catch { /* fall through */ }
              }
              setError("Не удалось загрузить видеопоток");
              setLoading(false);
            });
            hls.loadSource(src);
            hls.attachMedia(video);
            engineRef.current = hls;
          } else {
            video.src = src;
            video.addEventListener("loadedmetadata", afterAttach, { once: true });
          }
        } else if (isDash) {
          const dashjs = await import("dashjs");
          if (cancelled) return;
          const player = dashjs.MediaPlayer().create();
          player.initialize(video, src, wantPlay.current);
          player.on("streamInitialized", afterAttach);
          engineRef.current = player;
        } else {
          video.src = src;
          video.addEventListener("loadedmetadata", afterAttach, { once: true });
        }
      } catch {
        if (!cancelled) { setError("Плеер не смог запуститься"); setLoading(false); }
      }
    })();

    return () => {
      cancelled = true;
      video.removeEventListener("loadedmetadata", afterAttach);
      destroy();
    };
     
  }, [src]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onTime = () => { setCur(v.currentTime); if (v.buffered.length) setBuffered(v.buffered.end(v.buffered.length - 1)); };
    const onDur = () => setDur(v.duration || 0);
    const onPlay = () => { setPlaying(true); wantPlay.current = true; };
    const onPause = () => setPlaying(false);
    const onWaiting = () => setLoading(true);
    const onPlaying = () => { setLoading(false); setError(null); };
    const onCanPlay = () => setLoading(false);
    const onLoadedData = () => setLoading(false);
    v.addEventListener("timeupdate", onTime);
    v.addEventListener("durationchange", onDur);
    v.addEventListener("play", onPlay);
    v.addEventListener("pause", onPause);
    v.addEventListener("waiting", onWaiting);
    v.addEventListener("playing", onPlaying);
    v.addEventListener("canplay", onCanPlay);
    v.addEventListener("loadeddata", onLoadedData);
    return () => {
      v.removeEventListener("timeupdate", onTime);
      v.removeEventListener("durationchange", onDur);
      v.removeEventListener("play", onPlay);
      v.removeEventListener("pause", onPause);
      v.removeEventListener("loadeddata", onLoadedData);
      v.removeEventListener("waiting", onWaiting);
      v.removeEventListener("playing", onPlaying);
      v.removeEventListener("canplay", onCanPlay);
    };
  }, []);

  useEffect(() => {
    const onFs = () => setFull(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) { wantPlay.current = true; v.play().catch(() => {}); }
    else { wantPlay.current = false; v.pause(); }
  }, []);

  const seek = (t: number) => { const v = videoRef.current; if (v) v.currentTime = Math.max(0, Math.min(dur || v.duration || 0, t)); };
  const toggleFull = () => { if (document.fullscreenElement) document.exitFullscreen(); else wrapRef.current?.requestFullscreen().catch(() => {}); };
  const armHide = () => { setShowCtrl(true); if (hideTimer.current) clearTimeout(hideTimer.current); hideTimer.current = setTimeout(() => { if (playing) setShowCtrl(false); }, 2800); };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === " " || e.key === "k") { e.preventDefault(); togglePlay(); }
    else if (e.key === "ArrowRight") seek(cur + 10);
    else if (e.key === "ArrowLeft") seek(cur - 10);
    else if (e.key === "f") toggleFull();
    else if (e.key === "m") { const v = videoRef.current; if (v) { v.muted = !v.muted; setMuted(v.muted); } }
    else if (e.key === "ArrowUp") { const v = videoRef.current; if (v) { v.volume = Math.min(1, v.volume + 0.1); setVol(v.volume); } }
    else if (e.key === "ArrowDown") { const v = videoRef.current; if (v) { v.volume = Math.max(0, v.volume - 0.1); setVol(v.volume); } }
    armHide();
  };

  if (sources.length === 0) {
    return <div className="w-full aspect-video rounded-xl bg-black grid place-items-center text-zinc-500 text-sm">Нет доступных источников видео</div>;
  }

  return (
    <div ref={wrapRef} tabIndex={0} onKeyDown={onKey} onMouseMove={armHide} onClick={() => setMenu(null)}
      className="relative w-full aspect-video bg-black rounded-xl overflow-hidden group outline-none select-none">
      <video ref={videoRef} poster={poster} playsInline preload="auto" className="w-full h-full" onClick={(e) => { e.stopPropagation(); togglePlay(); }} />

      {error ? (
        <div className="absolute inset-0 grid place-items-center bg-black/70">
          <div className="text-center text-zinc-300">
            <AlertCircle className="w-8 h-8 mx-auto mb-2 text-rose-400" />
            <p className="text-sm">{error}</p>
            {sources.length > 1 && <p className="text-xs text-zinc-500 mt-1">Попробуйте другое качество ниже</p>}
          </div>
        </div>
      ) : loading ? (
        <div className="absolute inset-0 grid place-items-center pointer-events-none"><Loader2 className="w-10 h-10 text-white/80 animate-spin" /></div>
      ) : !playing ? (
        <button onClick={(e) => { e.stopPropagation(); togglePlay(); }} className="absolute inset-0 grid place-items-center">
          <span className="w-16 h-16 rounded-full bg-white/90 text-black grid place-items-center shadow-xl"><Play className="w-7 h-7 fill-current ml-1" /></span>
        </button>
      ) : null}

      <div className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent px-3 pb-2 pt-8 transition-opacity ${showCtrl || !playing ? "opacity-100" : "opacity-0"}`} onClick={(e) => e.stopPropagation()}>
        <div className="relative h-1.5 rounded-full bg-white/20 cursor-pointer mb-2 group/bar"
          onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); seek(((e.clientX - r.left) / r.width) * dur); }}>
          <div className="absolute inset-y-0 left-0 rounded-full bg-white/25" style={{ width: `${(buffered / dur) * 100 || 0}%` }} />
          <div className="absolute inset-y-0 left-0 rounded-full bg-fuchsia-400" style={{ width: `${(cur / dur) * 100 || 0}%` }} />
          <div className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white shadow opacity-0 group-hover/bar:opacity-100" style={{ left: `calc(${(cur / dur) * 100 || 0}% - 6px)` }} />
        </div>
        <div className="flex items-center gap-1 sm:gap-2 text-white">
          <button onClick={togglePlay} className="p-1.5 hover:text-fuchsia-300 transition shrink-0">{playing ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}</button>
          <button onClick={() => seek(cur - 10)} className="p-1.5 hover:text-fuchsia-300 transition shrink-0" title="-10с"><RotateCcw className="w-[18px] h-[18px]" /></button>
          <button onClick={() => seek(cur + 10)} className="p-1.5 hover:text-fuchsia-300 transition shrink-0" title="+10с"><RotateCw className="w-[18px] h-[18px]" /></button>
          <div className="hidden xs:flex items-center gap-1 group/vol shrink-0">
            <button onClick={() => { const v = videoRef.current; if (v) { v.muted = !v.muted; setMuted(v.muted); } }} className="p-1.5 hover:text-fuchsia-300 transition">{muted || vol === 0 ? <VolumeX className="w-[18px] h-[18px]" /> : <Volume2 className="w-[18px] h-[18px]" />}</button>
            <input type="range" min={0} max={1} step={0.05} value={muted ? 0 : vol}
              onChange={(e) => { const v = videoRef.current; if (v) { const nv = Number(e.target.value); v.volume = nv; v.muted = nv === 0; setVol(nv); setMuted(nv === 0); } }}
              className="w-0 group-hover/vol:w-16 transition-all duration-200 accent-fuchsia-400 h-1" />
          </div>
          <span className="text-[10px] sm:text-[11px] font-mono text-white/70 tabular-nums shrink-0">{fmt(cur)} / {fmt(dur)}</span>

          <div className="ml-auto flex items-center gap-0.5 sm:gap-1 relative shrink-0">
            <button onClick={() => setMenu(menu === "speed" ? null : "speed")} className="text-[11px] font-mono px-1.5 py-1 rounded hover:bg-white/10 transition min-w-[30px]">{rate}x</button>
            <button onClick={() => setMenu(menu === "quality" ? null : "quality")} className="px-1.5 py-1 hover:text-fuchsia-300 transition inline-flex items-center gap-0.5" title="Качество"><Settings className="w-[18px] h-[18px]" /><span className="hidden sm:inline text-[10px] font-mono">{sources[qi]?.label}</span></button>
            {sources[qi]?.downloadUrl && (
              <a href={sources[qi].downloadUrl} target="_blank" rel="noopener noreferrer" download className="px-1.5 py-1 hover:text-emerald-300 transition" title="Скачать серию"><Download className="w-[18px] h-[18px]" /></a>
            )}
            <button onClick={toggleFull} className="px-1.5 py-1 hover:text-fuchsia-300 transition">{full ? <Minimize className="w-[18px] h-[18px]" /> : <Maximize className="w-[18px] h-[18px]" />}</button>

            {menu === "quality" && (
              <div className="absolute bottom-10 right-0 rounded-xl bg-[#141416]/95 backdrop-blur border border-white/10 p-1 min-w-[130px] shadow-2xl animate-fade-in">
                <div className="px-2 py-1 text-[10px] text-white/40 font-mono">Качество</div>
                {sources.map((s, i) => (
                  <div key={s.label} className="flex items-center">
                    <button onClick={() => { setQi(i); setMenu(null); }} className={`flex-1 text-left px-2 py-1.5 rounded-lg text-[12px] transition ${i === qi ? "bg-fuchsia-500 text-white" : "text-white/80 hover:bg-white/10"}`}>{s.label}</button>
                    {s.downloadUrl && <a href={s.downloadUrl} target="_blank" rel="noopener noreferrer" download onClick={(e) => e.stopPropagation()} className="p-1.5 text-white/50 hover:text-emerald-300" title={`Скачать ${s.label}`}><Download className="w-3.5 h-3.5" /></a>}
                  </div>
                ))}
              </div>
            )}
            {menu === "speed" && (
              <div className="absolute bottom-10 right-0 rounded-xl bg-[#141416]/95 backdrop-blur border border-white/10 p-1 min-w-[80px] shadow-2xl animate-fade-in">
                <div className="px-2 py-1 text-[10px] text-white/40 font-mono">Скорость</div>
                {[0.5, 0.75, 1, 1.25, 1.5, 2].map((r) => <button key={r} onClick={() => { const v = videoRef.current; if (v) v.playbackRate = r; setRate(r); setMenu(null); }} className={`w-full text-left px-2 py-1.5 rounded-lg text-[12px] transition ${r === rate ? "bg-fuchsia-500 text-white" : "text-white/80 hover:bg-white/10"}`}>{r}x</button>)}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
