"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  Infinity as InfinityIcon,
  Swords,
  Play,
  Pause,
  Send,
  RotateCcw,
  Loader2,
  Trophy,
  Check,
  Copy,
} from "lucide-react";
import { MarkdownRenderer } from "@/components/MarkdownRenderer";
import { CopyChip } from "@/components/ChatMessage";

const AGENT_COLORS = ["text-sky-300", "text-emerald-300", "text-amber-300", "text-fuchsia-300", "text-rose-300", "text-cyan-300"];
const colorFor = (i: number) => AGENT_COLORS[i % AGENT_COLORS.length];

async function streamPost(
  url: string,
  body: unknown,
  onEvent: (e: Record<string, unknown>) => void,
  signal?: AbortSignal
) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal,
  });
  if (!res.ok || !res.body) throw new Error("network");
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const chunks = buffer.split("\n\n");
    buffer = chunks.pop() || "";
    for (const chunk of chunks) {
      const line = chunk.split("\n").find((l) => l.startsWith("data:"));
      if (!line) continue;
      try {
        onEvent(JSON.parse(line.slice(5).trim()));
      } catch {
        /* ignore */
      }
    }
  }
}

// ===========================================================================
// Mode 1 — Infinite dialogue
// ===========================================================================

interface DlgLine { id: number; speaker: string; slug: string; content: string; role: "agent" | "human" }

export function InfiniteDialogue({ agentOrder }: { agentOrder: string[] }) {
  const [topic, setTopic] = useState("Кто важнее — человек или сервера?");
  const [started, setStarted] = useState(false);
  const [running, setRunning] = useState(false);
  const [lines, setLines] = useState<DlgLine[]>([]);
  const [thinking, setThinking] = useState<string | null>(null);
  const [userMsg, setUserMsg] = useState("");
  const [agents, setAgents] = useState<{ slug: string; name: string }[]>([]);

  const runningRef = useRef(false);
  const nextSpeakerRef = useRef<string>("");
  const pendingUserRef = useRef<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(1);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [lines, thinking]);

  const transcript = () => lines.filter((l) => l.role === "agent").map((l) => ({ speaker: l.speaker, slug: l.slug, content: l.content }));

  const oneTurn = async () => {
    const controller = new AbortController();
    abortRef.current = controller;
    const injected = pendingUserRef.current;
    pendingUserRef.current = null;
    try {
      await streamPost("/api/dialogue", {
        topic,
        transcript: transcript(),
        speakerSlug: nextSpeakerRef.current || undefined,
        userMessage: injected,
        agentSlugs: agentOrder.length ? agentOrder : undefined,
      }, (e) => {
        if (e.type === "agents") setAgents(e.agents as { slug: string; name: string }[]);
        else if (e.type === "thinking") setThinking(String(e.speaker));
        else if (e.type === "message") {
          setThinking(null);
          setLines((old) => [...old, { id: idRef.current++, speaker: String(e.speaker), slug: String(e.providerSlug), content: String(e.content), role: "agent" }]);
        } else if (e.type === "next") nextSpeakerRef.current = String(e.speakerSlug);
      }, controller.signal);
    } finally {
      setThinking(null);
    }
  };

  const loop = async () => {
    while (runningRef.current) {
      try { await oneTurn(); } catch { if (!runningRef.current) break; }
      if (!runningRef.current) break;
      await new Promise((r) => setTimeout(r, 1100));
    }
  };

  const start = () => { setStarted(true); setRunning(true); runningRef.current = true; loop(); };
  const toggle = () => {
    if (running) { runningRef.current = false; abortRef.current?.abort(); setRunning(false); }
    else { setRunning(true); runningRef.current = true; loop(); }
  };
  const reset = () => { runningRef.current = false; abortRef.current?.abort(); setRunning(false); setStarted(false); setLines([]); setThinking(null); nextSpeakerRef.current = ""; };

  const sendUser = () => {
    const text = userMsg.trim();
    if (!text) return;
    setLines((old) => [...old, { id: idRef.current++, speaker: "Вы", slug: "human", content: text, role: "human" }]);
    pendingUserRef.current = text;
    setUserMsg("");
    if (!runningRef.current) { setRunning(true); runningRef.current = true; loop(); }
  };

  const agentIndex = (slug: string) => Math.max(0, agents.findIndex((a) => a.slug === slug));

  if (!started) {
    return (
      <div className="h-full overflow-y-auto">
        <div className="max-w-lg mx-auto w-full px-4 py-8">
          <div className="flex items-center gap-2.5 mb-4">
            <span className="w-9 h-9 rounded-xl bg-white text-black grid place-items-center"><InfinityIcon className="w-5 h-5" /></span>
            <div>
              <h2 className="text-[15px] font-semibold text-zinc-100">Бесконечный диалог ИИ</h2>
              <p className="text-[12px] text-zinc-500">Модели реально спорят по теме. Вы можете вмешаться в любой момент.</p>
            </div>
          </div>
          <label className="block text-[11px] font-mono uppercase tracking-wide text-zinc-600 mb-1.5">Тема спора</label>
          <textarea value={topic} onChange={(e) => setTopic(e.target.value)} rows={2}
            className="w-full rounded-xl border border-white/[0.08] bg-[#0e0e10] px-3 py-2.5 text-[14px] text-zinc-100 resize-none focus:outline-none focus:border-white/[0.2]" />
          <div className="mt-3 flex flex-wrap gap-1.5">
            {["Кто важнее — человек или сервера?", "ИИ заменит программистов?", "Существует ли свобода воли?", "Кошки или собаки?"].map((t) => (
              <button key={t} onClick={() => setTopic(t)} className="px-2.5 py-1 rounded-lg border border-white/[0.08] text-[11.5px] text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04]">{t}</button>
            ))}
          </div>
          <button onClick={start} className="mt-5 w-full h-11 rounded-xl bg-white text-black text-[14px] font-semibold inline-flex items-center justify-center gap-2 active:scale-[0.99]">
            <Play className="w-4 h-4 fill-current" /> Запустить спор
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="shrink-0 px-4 py-2.5 border-b border-white/[0.08] flex items-center gap-2">
        <span className="text-[12.5px] text-zinc-300 truncate flex-1">💬 {topic}</span>
        <button onClick={toggle} className="h-8 px-3 rounded-lg border border-white/[0.1] text-[12px] text-zinc-200 inline-flex items-center gap-1.5 hover:bg-white/[0.05]">
          {running ? <><Pause className="w-3.5 h-3.5" /> Пауза</> : <><Play className="w-3.5 h-3.5 fill-current" /> Далее</>}
        </button>
        <button onClick={reset} className="h-8 w-8 rounded-lg border border-white/[0.1] grid place-items-center text-zinc-400 hover:bg-white/[0.05]"><RotateCcw className="w-3.5 h-3.5" /></button>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4">
        <div className="max-w-2xl mx-auto space-y-3">
          {lines.map((l) =>
            l.role === "human" ? (
              <div key={l.id} className="flex justify-end animate-fade-in">
                <div className="max-w-[80%] rounded-2xl rounded-br-md bg-[#17171a] border border-white/[0.07] px-3.5 py-2 text-[14px] text-zinc-100">{l.content}</div>
              </div>
            ) : (
              <div key={l.id} className="group animate-fade-in">
                <div className={`text-[11px] font-mono mb-1 ${colorFor(agentIndex(l.slug))}`}>{l.speaker}</div>
                <div className="inline-flex items-start gap-1.5">
                  <div className="inline-block rounded-2xl rounded-tl-md bg-[#0e0e10] border border-white/[0.06] px-3.5 py-2 text-[14px] leading-relaxed text-zinc-200">{l.content}</div>
                  <span className="lg:opacity-0 lg:group-hover:opacity-100 transition mt-1"><CopyChip text={l.content} /></span>
                </div>
              </div>
            )
          )}
          {thinking && (
            <div className="animate-fade-in">
              <div className={`text-[11px] font-mono mb-1 ${colorFor(agentIndex(nextSpeakerRef.current))}`}>{thinking}</div>
              <div className="inline-flex items-center gap-1.5 rounded-2xl rounded-tl-md bg-[#0e0e10] border border-white/[0.06] px-3.5 py-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 dot-1" /><span className="w-1.5 h-1.5 rounded-full bg-zinc-500 dot-2" /><span className="w-1.5 h-1.5 rounded-full bg-zinc-500 dot-3" />
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>
      </div>

      <div className="shrink-0 px-4 py-2.5 border-t border-white/[0.08]">
        <div className="max-w-2xl mx-auto rounded-2xl border border-white/[0.08] bg-[#0e0e10] px-2 py-1.5 flex items-end gap-1">
          <textarea value={userMsg} rows={1} onChange={(e) => setUserMsg(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendUser(); } }}
            placeholder="Вмешаться в спор…"
            className="flex-1 bg-transparent px-2 py-1.5 text-[14px] text-zinc-100 placeholder-zinc-600 resize-none focus:outline-none max-h-24" />
          <button onClick={sendUser} disabled={!userMsg.trim()} className={`w-9 h-9 rounded-xl grid place-items-center shrink-0 ${userMsg.trim() ? "bg-white text-black" : "bg-white/[0.04] text-zinc-600"}`}><Send className="w-4 h-4" /></button>
        </div>
      </div>
    </div>
  );
}

// ===========================================================================
// Mode 2 — Battle: models answer the same prompt, you pick the winner
// ===========================================================================

interface BattleAnswer { speaker: string; providerSlug: string; providerName: string; modelId: string; content: string; latencyMs: number }
interface BattleRound { id: number; prompt: string; answers: BattleAnswer[]; winner: string | null; loading: boolean }

export function Battle({ agentOrder }: { agentOrder: string[] }) {
  const [rounds, setRounds] = useState<BattleRound[]>([]);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(1);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [rounds]);

  const send = async () => {
    const text = prompt.trim();
    if (!text || busy) return;
    setPrompt("");
    setBusy(true);
    const roundId = idRef.current++;
    setRounds((old) => [...old, { id: roundId, prompt: text, answers: [], winner: null, loading: true }]);
    try {
      await streamPost("/api/battle", { prompt: text, count: 3, agentSlugs: agentOrder.length ? agentOrder : undefined }, (e) => {
        if (e.type === "answers") {
          setRounds((old) => old.map((r) => (r.id === roundId ? { ...r, answers: e.answers as BattleAnswer[], loading: false } : r)));
        } else if (e.type === "error") {
          setRounds((old) => old.map((r) => (r.id === roundId ? { ...r, loading: false } : r)));
        }
      });
    } catch {
      setRounds((old) => old.map((r) => (r.id === roundId ? { ...r, loading: false } : r)));
    } finally {
      setBusy(false);
    }
  };

  const pickWinner = (roundId: number, speaker: string) => {
    setRounds((old) => old.map((r) => (r.id === roundId ? { ...r, winner: speaker } : r)));
  };

  const copy = async (key: string, text: string) => {
    try { await navigator.clipboard.writeText(text); setCopied(key); window.setTimeout(() => setCopied(null), 1600); } catch { /* ignore */ }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-5">
        <div className="max-w-3xl mx-auto space-y-6">
          {rounds.length === 0 && !busy && (
            <div className="min-h-[40vh] flex flex-col items-center justify-center text-center">
              <span className="w-10 h-10 rounded-xl bg-white text-black grid place-items-center mb-4"><Swords className="w-5 h-5" /></span>
              <h2 className="text-[16px] font-semibold text-zinc-100">Battle Mode</h2>
              <p className="mt-2 text-[12.5px] text-zinc-500 max-w-xs">Задайте вопрос — 3 модели ответят одновременно, а вы выберете лучший ответ.</p>
              <div className="mt-5 w-full max-w-md space-y-1.5">
                {["Объясни квантовую запутанность простыми словами", "Придумай слоган для кофейни", "Напиши хайку про осень"].map((t) => (
                  <button key={t} onClick={() => setPrompt(t)} className="w-full text-left px-3.5 py-2.5 rounded-xl border border-white/[0.06] text-[13px] text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.03]">{t}</button>
                ))}
              </div>
            </div>
          )}

          {rounds.map((round) => (
            <div key={round.id} className="animate-fade-in">
              <div className="flex justify-end mb-3">
                <div className="max-w-[80%] rounded-2xl rounded-br-md bg-[#17171a] border border-white/[0.07] px-3.5 py-2 text-[14px] text-zinc-100">{round.prompt}</div>
              </div>

              {round.loading ? (
                <div className="grid sm:grid-cols-3 gap-3">
                  {[0, 1, 2].map((i) => (
                    <div key={i} className="rounded-xl border border-white/[0.06] bg-[#0e0e10] p-3 h-40 flex items-center justify-center">
                      <Loader2 className="w-4 h-4 animate-spin text-zinc-600" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {round.answers.map((a, i) => {
                    const isWinner = round.winner === a.speaker;
                    const dimmed = round.winner && !isWinner;
                    const key = `${round.id}-${a.speaker}`;
                    return (
                      <div key={key} className={`rounded-xl border p-3 flex flex-col transition ${isWinner ? "border-amber-300/50 bg-amber-300/[0.04]" : "border-white/[0.08] bg-[#0e0e10]"} ${dimmed ? "opacity-45" : ""}`}>
                        <div className="flex items-center gap-1.5 mb-2">
                          <span className={`text-[11px] font-mono ${colorFor(i)}`}>{a.speaker}</span>
                          {isWinner && <Trophy className="w-3.5 h-3.5 text-amber-300" />}
                          <span className="ml-auto text-[10px] font-mono text-zinc-600">{Math.round(a.latencyMs / 100) / 10}с</span>
                          <button onClick={() => copy(key, a.content)} className="w-6 h-6 rounded-md grid place-items-center text-zinc-600 hover:text-zinc-200 hover:bg-white/[0.06]">
                            {copied === key ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </div>
                        <div className="flex-1 min-h-0 max-h-72 overflow-y-auto text-[13px] pr-1">
                          <MarkdownRenderer content={a.content} compact />
                        </div>
                        <button
                          onClick={() => pickWinner(round.id, a.speaker)}
                          disabled={Boolean(round.winner)}
                          className={`mt-2.5 h-8 rounded-lg text-[12px] font-medium inline-flex items-center justify-center gap-1.5 transition ${isWinner ? "bg-amber-300 text-black" : round.winner ? "border border-white/[0.08] text-zinc-600" : "bg-white text-black hover:bg-zinc-200"}`}
                        >
                          {isWinner ? <><Trophy className="w-3.5 h-3.5" /> Лучший</> : "Выбрать лучшим"}
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
          <div ref={endRef} />
        </div>
      </div>

      <div className="shrink-0 px-4 py-2.5 border-t border-white/[0.08]">
        <div className="max-w-3xl mx-auto rounded-2xl border border-white/[0.08] bg-[#0e0e10] px-2 py-1.5 flex items-end gap-1">
          <textarea value={prompt} rows={1} onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Задайте вопрос всем моделям…"
            className="flex-1 bg-transparent px-2 py-1.5 text-[14px] text-zinc-100 placeholder-zinc-600 resize-none focus:outline-none max-h-28" />
          <button onClick={send} disabled={!prompt.trim() || busy} className={`w-9 h-9 rounded-xl grid place-items-center shrink-0 ${prompt.trim() && !busy ? "bg-white text-black" : "bg-white/[0.04] text-zinc-600"}`}>
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
}

// ===========================================================================
// Lab shell
// ===========================================================================

export function ModelLab({ agentOrder }: { agentOrder: string[] }) {
  const [mode, setMode] = useState<"battle" | "dialogue">("battle");
  return (
    <div className="flex flex-col h-full">
      <div className="shrink-0 h-12 px-4 border-b border-white/[0.08] flex items-center gap-2">
        <div className="flex items-center gap-1 rounded-xl bg-[#0e0e10] border border-white/[0.06] p-0.5">
          <button onClick={() => setMode("battle")} className={`h-8 px-3 rounded-lg text-[12.5px] font-medium inline-flex items-center gap-1.5 transition ${mode === "battle" ? "bg-white text-black" : "text-zinc-400 hover:text-zinc-200"}`}>
            <Swords className="w-3.5 h-3.5" /> Battle Mode
          </button>
          <button onClick={() => setMode("dialogue")} className={`h-8 px-3 rounded-lg text-[12.5px] font-medium inline-flex items-center gap-1.5 transition ${mode === "dialogue" ? "bg-white text-black" : "text-zinc-400 hover:text-zinc-200"}`}>
            <InfinityIcon className="w-3.5 h-3.5" /> Диалог ИИ
          </button>
        </div>
      </div>
      <div className="flex-1 min-h-0">
        {mode === "battle" ? <Battle agentOrder={agentOrder} /> : <InfiniteDialogue agentOrder={agentOrder} />}
      </div>
    </div>
  );
}
