"use client";

// Панель Люми: живые новости аниме, подписки на серии с уведомлениями, избранные арты.
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Bell, BellPlus, CheckCheck, ExternalLink, Heart, Loader2, Newspaper, Plus, RefreshCw, Trash2, X,
} from "lucide-react";
import {
  addSub, checkSub, getFavs, getSubs, markSeen, notifPermission, removeFav, removeSub,
  requestNotif, sendNotif, SubCheckResult, Subscription, FavoriteArt,
} from "@/lib/lumi-store";

export interface NewsItem {
  title: string;
  link: string;
  source: string;
  publishedAt: string;
  snippet: string;
  image: string | null;
}

function ago(iso: string) {
  const m = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (m < 1) return "только что";
  if (m < 60) return `${m} мин назад`;
  if (m < 1440) return `${Math.round(m / 60)} ч назад`;
  return `${Math.round(m / 1440)} дн назад`;
}

export function shareLinks(url: string, text: string) {
  return [
    { id: "x", label: "X", href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}` },
    { id: "tg", label: "TG", href: `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}` },
    { id: "vk", label: "VK", href: `https://vk.com/share.php?url=${encodeURIComponent(url)}&comment=${encodeURIComponent(text)}` },
  ];
}

export function ShareChips({ url, text }: { url: string; text: string }) {
  return (
    <span className="inline-flex items-center gap-1">
      {shareLinks(url, text).map((s) => (
        <a
          key={s.id}
          href={s.href}
          target="_blank"
          rel="noopener noreferrer"
          className="h-6 px-1.5 rounded-md text-[10px] font-mono font-bold text-zinc-500 hover:text-white hover:bg-white/[0.08] grid place-items-center transition"
          title={`Поделиться в ${s.label}`}
        >
          {s.label}
        </a>
      ))}
    </span>
  );
}

type Tab = "news" | "subs" | "favs";

export function LumiPanel({ open, onClose, initialTab }: { open: boolean; onClose: () => void; initialTab?: Tab }) {
  const [tab, setTab] = useState<Tab>(initialTab || "news");
  useEffect(() => {
    if (open) setTab(initialTab || "news");
  }, [open, initialTab]);

  return (
    <>
      {open && <button aria-label="Закрыть" className="fixed inset-0 z-[55] bg-black/60 animate-fade-in" onClick={onClose} />}
      <aside
        className={`fixed inset-y-0 right-0 z-[56] w-full sm:w-[430px] bg-[#0b0b0d] border-l border-white/[0.08] flex flex-col transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full pointer-events-none"
        }`}
      >
        <div className="h-14 px-4 flex items-center justify-between border-b border-white/[0.08] shrink-0">
          <div className="flex items-center gap-2.5">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/lumi-avatar.jpg" alt="Люми" className="w-7 h-7 rounded-lg object-cover border border-fuchsia-400/30" />
            <span className="text-[13px] font-bold text-zinc-100">Люми · Медиа</span>
          </div>
          <button onClick={onClose} className="w-9 h-9 grid place-items-center rounded-lg text-zinc-500 hover:text-white">
            <X className="w-[18px] h-[18px]" />
          </button>
        </div>

        <div className="px-3 pt-3 pb-2 flex gap-1.5 shrink-0">
          {(
            [
              { id: "news" as Tab, icon: Newspaper, label: "Новости" },
              { id: "subs" as Tab, icon: Bell, label: "Серии" },
              { id: "favs" as Tab, icon: Heart, label: "Избранное" },
            ] as const
          ).map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex-1 h-9 rounded-xl text-[12px] font-medium inline-flex items-center justify-center gap-1.5 transition ${
                  tab === t.id ? "bg-white text-black" : "bg-white/[0.04] text-zinc-400 hover:text-zinc-200"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {t.label}
              </button>
            );
          })}
        </div>

        <div className="flex-1 min-h-0 overflow-y-auto p-3">
          {tab === "news" && <NewsTab open={open && tab === "news"} />}
          {tab === "subs" && <SubsTab open={open && tab === "subs"} />}
          {tab === "favs" && <FavsTab />}
        </div>
      </aside>
    </>
  );
}

// ── Новости ──────────────────────────────────────────────────────────────────
function NewsTab({ open }: { open: boolean }) {
  const [items, setItems] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(false);

  const load = useCallback(async (force = false) => {
    if (loading || (items.length && !force)) return;
    setLoading(true);
    setErr(false);
    try {
      const res = await fetch("/api/news", { cache: "no-store" });
      const data = await res.json();
      setItems(Array.isArray(data.items) ? data.items : []);
      if (!data.items?.length) setErr(true);
    } catch {
      setErr(true);
    } finally {
      setLoading(false);
    }
  }, [items.length, loading]);

  useEffect(() => {
    if (open) load();
  }, [open, load]);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between px-1 pb-1">
        <span className="text-[11px] text-zinc-600">MyAnimeList · LiveChart · Otaku USA — в реальном времени</span>
        <button onClick={() => load(true)} className="w-7 h-7 grid place-items-center rounded-lg text-zinc-600 hover:text-white" title="Обновить">
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>
      {loading && !items.length && (
        <div className="py-16 grid place-items-center text-zinc-600"><Loader2 className="w-5 h-5 animate-spin" /></div>
      )}
      {err && !items.length && (
        <p className="text-center text-[12px] text-zinc-600 py-10">Не удалось загрузить новости. Попробуй ещё раз 💫</p>
      )}
      {items.map((n) => (
        <article key={n.link} className="rounded-xl border border-white/[0.07] bg-[#101013] p-3 hover:border-white/[0.14] transition">
          <div className="flex items-center gap-2 text-[10px] font-mono text-zinc-600">
            <span className={`px-1.5 py-0.5 rounded ${n.source.includes("LiveChart") ? "bg-emerald-500/15 text-emerald-300" : n.source.includes("Otaku") ? "bg-orange-500/15 text-orange-300" : "bg-sky-500/15 text-sky-300"}`}>
              {n.source}
            </span>
            <span>{ago(n.publishedAt)}</span>
            <span className="ml-auto"><ShareChips url={n.link} text={n.title} /></span>
          </div>
          <a href={n.link} target="_blank" rel="noopener noreferrer" className="mt-1.5 block text-[13px] leading-snug text-zinc-100 hover:text-white">
            {n.title}
          </a>
          {n.snippet && <p className="mt-1 text-[11.5px] leading-relaxed text-zinc-500">{n.snippet}…</p>}
        </article>
      ))}
    </div>
  );
}

// ── Подписки на серии + уведомления ──────────────────────────────────────────
function SubsTab({ open }: { open: boolean }) {
  const [subs, setSubs] = useState<Subscription[]>([]);
  const [results, setResults] = useState<Record<string, SubCheckResult>>({});
  const [checking, setChecking] = useState(false);
  const [title, setTitle] = useState("");
  const [perm, setPerm] = useState<string>("default");
  const busy = useRef(false);

  const refresh = useCallback(() => setSubs(getSubs()), []);

  useEffect(() => {
    refresh();
    setPerm(notifPermission());
    const on = () => refresh();
    window.addEventListener("lumi:subs", on);
    return () => window.removeEventListener("lumi:subs", on);
  }, [refresh]);

  const runCheck = useCallback(async (silent = false) => {
    if (busy.current) return;
    busy.current = true;
    if (!silent) setChecking(true);
    try {
      const list = getSubs();
      const map: Record<string, SubCheckResult> = {};
      let fresh: SubCheckResult[] = [];
      for (const s of list) {
        const r = await checkSub(s);
        map[s.id] = r;
        if (r.newEpisodes > 0) fresh.push(r);
      }
      setResults((old) => ({ ...old, ...map }));
      setSubs(getSubs());
      fresh = fresh.filter((f) => f.foundCount !== null);
      if (fresh.length) {
        sendNotif(
          fresh.length === 1 ? `Новая серия: ${fresh[0].sub.title} ✨` : `Новые серии в ${fresh.length} аниме! ✨`,
          fresh
            .slice(0, 3)
            .map((f) => `«${f.sub.title}» — уже ${f.foundCount} сери${f.foundCount === 1 ? "я" : f.foundCount! < 5 ? "и" : "й"}`)
            .join(" · ")
        );
      }
    } finally {
      busy.current = false;
      setChecking(false);
    }
  }, []);

  // Авто-проверка: при открытии + каждые 3 минуты, пока панель открыта
  useEffect(() => {
    if (!open) return;
    if (getSubs().length) runCheck(true);
    const t = window.setInterval(() => runCheck(true), 180_000);
    return () => window.clearInterval(t);
  }, [open, runCheck]);

  const subscribe = () => {
    const t = title.trim();
    if (t.length < 2) return;
    setSubs(addSub(t));
    setTitle("");
    window.setTimeout(() => runCheck(true), 300);
  };

  return (
    <div className="space-y-2.5">
      {perm === "default" && (
        <button
          onClick={async () => setPerm(await requestNotif())}
          className="w-full rounded-xl border border-fuchsia-400/20 bg-fuchsia-500/[0.07] px-3 py-2.5 text-left flex items-center gap-2.5"
        >
          <BellPlus className="w-4 h-4 text-fuchsia-300 shrink-0" />
          <span className="text-[12px] text-zinc-300">
            <b className="text-zinc-100">Включить уведомления</b> — Люми сообщит, когда выйдет новая серия 🌸
          </span>
        </button>
      )}
      {perm === "denied" && (
        <p className="rounded-xl border border-white/[0.08] px-3 py-2 text-[11.5px] text-zinc-500">
          Уведомления заблокированы браузером. Разреши их в настройках сайта (замок в адресной строке), чтобы Люми могла присылать новые серии.
        </p>
      )}

      <div className="flex gap-1.5">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && subscribe()}
          placeholder="Добавить аниме: например, «Фрирен»"
          className="flex-1 h-9 rounded-xl bg-white/[0.04] border border-white/[0.08] px-3 text-[13px] text-zinc-100 placeholder:text-zinc-600 outline-none focus:border-fuchsia-400/40"
        />
        <button onClick={subscribe} className="h-9 px-3 rounded-xl bg-white text-black text-[12px] font-semibold inline-flex items-center gap-1">
          <Plus className="w-3.5 h-3.5" /> Следить
        </button>
      </div>

      <div className="flex items-center justify-between px-1">
        <span className="text-[11px] text-zinc-600">
          Подписок: {subs.length} · проверка раз в 3 мин через AniLibria
        </span>
        <button
          onClick={() => runCheck()}
          disabled={checking || !subs.length}
          className="h-7 px-2 rounded-lg text-[11px] text-zinc-400 hover:text-white bg-white/[0.04] inline-flex items-center gap-1.5 disabled:opacity-40"
        >
          <RefreshCw className={`w-3 h-3 ${checking ? "animate-spin" : ""}`} /> Проверить
        </button>
      </div>

      {!subs.length && (
        <p className="text-center text-[12px] text-zinc-600 py-10 leading-relaxed">
          Пока пусто 🌙<br />Добавь аниме — и я буду следить за выходом новых серий в твоём регионе.
        </p>
      )}

      {subs.map((s) => {
        const r = results[s.id];
        const fresh = r && r.newEpisodes > 0;
        return (
          <article key={s.id} className={`rounded-xl border p-3 flex gap-3 transition ${fresh ? "border-fuchsia-400/30 bg-fuchsia-500/[0.06]" : "border-white/[0.07] bg-[#101013]"}`}>
            {s.poster ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={s.poster} alt="" className="w-12 h-16 rounded-lg object-cover border border-white/[0.06] shrink-0" />
            ) : (
              <div className="w-12 h-16 rounded-lg bg-white/[0.05] grid place-items-center text-[18px] font-bold text-zinc-600 shrink-0">
                {s.title.charAt(0).toUpperCase()}
              </div>
            )}
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-semibold text-zinc-100 leading-tight truncate">{s.title}</div>
              <div className="mt-1 text-[11px] text-zinc-500">
                {r == null ? (
                  checking ? "проверяю…" : "ожидает проверки"
                ) : r.foundCount == null ? (
                  <span className="text-zinc-600">не нашла на AniLibria — попробуй точное название</span>
                ) : (
                  <>
                    вышло серий: <b className="text-zinc-300">{r.foundCount}</b>
                    {s.episodesTotal ? ` / ${s.episodesTotal}` : ""}
                    {fresh && <span className="ml-1.5 px-1.5 py-0.5 rounded bg-fuchsia-500/20 text-fuchsia-300 font-semibold">+{r.newEpisodes} новая!</span>}
                  </>
                )}
              </div>
              <div className="mt-2 flex items-center gap-1.5">
                {fresh && (
                  <button
                    onClick={() => { markSeen(s.id, r.foundCount!); setResults((o) => ({ ...o, [s.id]: { ...r, newEpisodes: 0 } })); }}
                    className="h-7 px-2 rounded-lg bg-white/[0.06] text-[11px] text-zinc-300 hover:bg-white/[0.1] inline-flex items-center gap-1"
                  >
                    <CheckCheck className="w-3 h-3" /> Посмотрел
                  </button>
                )}
                <button
                  onClick={() => removeSub(s.title)}
                  className="h-7 px-2 rounded-lg text-[11px] text-zinc-600 hover:text-red-300 inline-flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" /> Отписаться
                </button>
              </div>
            </div>
          </article>
        );
      })}
    </div>
  );
}

// ── Избранные арты ───────────────────────────────────────────────────────────
function FavsTab() {
  const [favs, setFavs] = useState<FavoriteArt[]>([]);

  useEffect(() => {
    setFavs(getFavs());
    const on = () => setFavs(getFavs());
    window.addEventListener("lumi:favs", on);
    return () => window.removeEventListener("lumi:favs", on);
  }, []);

  return (
    <div>
      {!favs.length ? (
        <p className="text-center text-[12px] text-zinc-600 py-10 leading-relaxed">
          Пока пусто 💫<br />Нажимай на сердечко на любом арте в чате — и он появится здесь.
        </p>
      ) : (
        <>
          <p className="px-1 pb-2 text-[11px] text-zinc-600">Твои сохранённые арты · {favs.length}</p>
          <div className="grid grid-cols-2 gap-2">
            {favs.map((f) => (
              <figure key={f.image} className="group relative rounded-xl overflow-hidden border border-white/[0.07] bg-[#101013] aspect-square">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={f.thumbnail || f.image} alt={f.title} loading="lazy" className="w-full h-full object-cover" />
                <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent p-2 pt-6 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                  <span className="text-[10px] text-zinc-300 truncate flex-1">{f.title}</span>
                  <a href={f.image} target="_blank" rel="noopener noreferrer" className="w-6 h-6 grid place-items-center rounded text-zinc-300 hover:text-white" title="Открыть">
                    <ExternalLink className="w-3 h-3" />
                  </a>
                  <button onClick={() => removeFav(f.image)} className="w-6 h-6 grid place-items-center rounded text-pink-400 hover:text-pink-300" title="Убрать">
                    <Heart className="w-3 h-3 fill-current" />
                  </button>
                </figcaption>
              </figure>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
