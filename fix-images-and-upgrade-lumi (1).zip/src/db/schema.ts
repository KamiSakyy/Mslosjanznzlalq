import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";

export interface FailoverHop {
  providerSlug: string;
  providerName: string;
  modelId: string;
  status: "success" | "failed" | "skipped";
  statusCode?: number;
  latencyMs: number;
  error?: string;
}

export const aiProviders = pgTable("ai_providers", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  vendor: text("vendor").notNull(),
  gateway: text("gateway").notNull().default("pollinations"), // 'pollinations' | 'llm7' | 'kilo'
  modelId: text("model_id").notNull(),
  endpoint: text("endpoint").notNull(),
  publicKeyLabel: text("public_key_label").notNull(),
  category: text("category").notNull().default("universal"), // 'reasoning' | 'coding' | 'fast' | 'universal' | 'vision' | 'image'
  description: text("description").notNull(),
  badgeText: text("badge_text").notNull(),
  supportsVision: boolean("supports_vision").notNull().default(false),
  supportsStream: boolean("supports_stream").notNull().default(true),
  contextWindow: integer("context_window").notNull().default(32000),
  isEnabled: boolean("is_enabled").notNull().default(true),
  priority: integer("priority").notNull().default(1),
  avgLatencyMs: integer("avg_latency_ms").notNull().default(850),
  successRate: integer("success_rate").notNull().default(100),
  totalRequests: integer("total_requests").notNull().default(0),
  failedRequests: integer("failed_requests").notNull().default(0),
  lastStatus: text("last_status").notNull().default("online"), // 'online' | 'degraded' | 'offline'
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const chatSessions = pgTable("chat_sessions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  routingMode: text("routing_mode").notNull().default("auto"),
  systemPersona: text("system_persona").notNull().default("universal"),
  chatMode: text("chat_mode").notNull().default("chat"), // 'chat' | 'battle' | 'dialogue' | 'github'
  repoFullName: text("repo_full_name"),
  repoBranch: text("repo_branch"),
  messageCount: integer("message_count").notNull().default(0),
  totalTokens: integer("total_tokens").notNull().default(0),
  isPinned: boolean("is_pinned").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const githubTokens = pgTable("github_tokens", {
  id: integer("id").primaryKey(),
  token: text("token").notNull(),
  login: text("login").notNull(),
  name: text("name"),
  avatarUrl: text("avatar_url").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id")
    .notNull()
    .references(() => chatSessions.id, { onDelete: "cascade" }),
  role: text("role").notNull(), // 'user' | 'assistant'
  kind: text("kind").notNull().default("text"), // 'text' | 'image'
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  attachmentDataUrl: text("attachment_data_url"),
  groupKey: text("group_key"),
  reasoningTrace: text("reasoning_trace"),
  providerSlug: text("provider_slug"),
  providerName: text("provider_name"),
  modelId: text("model_id"),
  latencyMs: integer("latency_ms"),
  tokensPerSec: integer("tokens_per_sec"),
  tokenCount: integer("token_count"),
  routingReason: text("routing_reason"),
  failoverLog: jsonb("failover_log").$type<FailoverHop[]>().default([]),
  animeData: jsonb("anime_data").$type<AnimePayload>(),
  imagesData: jsonb("images_data").$type<ImageItem[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export interface AnimePayload {
  type: "cards" | "calendar";
  items: unknown[];
}

export interface ImageItem {
  image: string;
  thumbnail: string;
  title: string;
  source: string;
}
